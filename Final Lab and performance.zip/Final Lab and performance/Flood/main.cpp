#include <windows.h>
#include <GL/glut.h>
#include <math.h>
#include <ctime>
#include <cstdlib>
#include <vector>

using namespace std;

struct Raindrop {
   float x;
   float y;
   float length;
   float speed;
};

const int NUM_RAINDROPS = 200;
vector<Raindrop> raindrops(NUM_RAINDROPS);
float riverHeight = 0.0f;
float rainIntensity = 0.5f; // Rain intensity controls the amount of rain


void UpdateScene(int value) {
   // Update raindrops
   for (auto& drop : raindrops) {
       drop.y -= drop.speed;
       if (drop.y < -1.0) {
           drop.y = 1.0;
           drop.x = static_cast<float>(rand()) / RAND_MAX * 2.0 - 1.0;
       }
   }

   // Update river height based on rain intensity
   riverHeight += rainIntensity * 0.01f;
   if (riverHeight > 0.2) {
       riverHeight = 0.2; // Cap river height
   }

   glutPostRedisplay();
   glutTimerFunc(200, UpdateScene, 0); // Update every 25 milliseconds
}


void display()
{
   glClear(GL_COLOR_BUFFER_BIT);

   // Draw the sky
   glColor3f(0.529, 0.808, 0.922); // Day color
   glBegin(GL_QUADS);
   glVertex2f(-1.0, -1.0);
   glVertex2f(1.0, -1.0);
   glVertex2f(1.0, 1.0);
   glVertex2f(-1.0, 1.0);
   glEnd();

   // Draw the ground
   glColor3f(0.133, 0.545, 0.133);
   glBegin(GL_QUADS);
   glVertex2f(-1.0, -0.5);
   glVertex2f(1.0, -0.5);
   glVertex2f(1.0, -1.0);
   glVertex2f(-1.0, -1.0);
   glEnd();

   // Draw the sun
   glColor3f(1.0, 1.0, 0.0); // Sun color
   glBegin(GL_POLYGON);
   for (int i = 0; i < 360; i++) {
       float angle = i * 3.14159265 / 180;
       glVertex2f(0.2 * cos(angle), 0.2 * sin(angle) + 0.4);
   }
   glEnd();

   // Tree
   glColor3f(0.7, 0.5, 0.1);
   glBegin(GL_QUADS);
   glVertex2f(-0.45, -0.6);
   glVertex2f(-0.4, -0.6);
   glVertex2f(-0.4, -0.5);
   glVertex2f(-0.45, -0.5);
   glEnd();

   glColor3f(0.1, 0.4, 0.1);
   glBegin(GL_TRIANGLES);
   glVertex2f(-0.5, -0.5);
   glVertex2f(-0.35, -0.5);
   glVertex2f(-0.42, -0.35);
   glEnd();


   glColor3f(0.0, 0.2, 0.0);
   glBegin(GL_TRIANGLES);
   glVertex2f(1.0 - 0.2, -0.5);
   glVertex2f(0.9 - 0.2, -0.4);
   glVertex2f(0.8 - 0.2, -0.5);
   glEnd();


   // River
   glColor3f(0.0, 0.5, 1.0); // Blue color
   glBegin(GL_QUADS);
   glVertex2f(-1.0, -1.0);
   glVertex2f(1.0, -1.0);
   glVertex2f(1.0, -0.8);
   glVertex2f(-1.0, -0.8);
   glEnd();

   // Draw raindrops
   glColor3f(0.0, 0.0, 1.0); // Blue color
   glPointSize(2.0f);
   glBegin(GL_POINTS);
   for (const auto& drop : raindrops) {
       glVertex2f(drop.x, drop.y);
   }
   glEnd();

   // Simulate flooding
   glColor3f(0.0, 0.5, 1.0); // Blue color
   glBegin(GL_QUADS);
   glVertex2f(-1.0, -1.0);
   glVertex2f(1.0, -1.0);
   glVertex2f(1.0, -0.8 + riverHeight);
   glVertex2f(-1.0, -0.8 + riverHeight);
   glEnd();

   glFlush();
}


int main(int argc, char** argv) {

 glutInit(&argc, argv);          // Initialize GLUT

    glutInitWindowSize(600, 500);    // Initializes window size

    glutInitWindowPosition(500,200); // Position the window's initial top-left corner

    glutCreateWindow("FLOOD EFFECT");      // Create window with the given title

    glutDisplayFunc(display);       // Register callback handler for window re-paint event


   // Initialize raindrops
   srand(static_cast<unsigned int>(time(nullptr)));
   for (auto& drop : raindrops) {
       drop.x = static_cast<float>(rand()) / RAND_MAX * 2.0 - 1.0;
       drop.y = static_cast<float>(rand()) / RAND_MAX * 2.0 - 1.0;
       drop.length = static_cast<float>(rand()) / RAND_MAX * 0.05 + 0.01;
       drop.speed = static_cast<float>(rand()) / RAND_MAX * 0.05 + 0.01;
   }




//    glutTimerFunc(20, update, 0); //Add a timer






   // Set up update function
  glutTimerFunc(20, UpdateScene, 0);
   glutMainLoop();
   return 0;
}
