

#include<cstdio>
#include <GL/gl.h>
#include <GL/glut.h>
GLfloat position = 2.5f;
GLfloat speed = 0.2f;
GLfloat speed1 = 0.2f;
GLfloat speed2 = 0.2f;
GLfloat speed3 = 0.2f;
GLfloat position1 = -2.0f;
void dis();
void display();

void update(int value)
{
    if(position <-2)
        position = 2.0f;
    position -= speed;
    glutPostRedisplay();
    glutTimerFunc(150,update,0);
}

void update1(int value)
{
    if(position1 >2)
        position1 = -2.0f;
    position1+= speed1;
    glutPostRedisplay();
    glutTimerFunc(100,update1,0);
}


void update2(int value)
{
    if(position <-2)
        position = 2.0f;
    position -= speed2;
    glutPostRedisplay();
    glutTimerFunc(150,update,0);
}


void update3(int value)
{
    if(position1 >2)
        position1 = -2.0f;
    position1+= speed3;
    glutPostRedisplay();
    glutTimerFunc(100,update3,0);
}


void init()
{
    glClearColor(0.7f, 0.9f, 1.0f, 1.0f);
}
void callback(int val)
{
    glutDisplayFunc(display);
}
void display7()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(0,position1, 0.0f);
     glBegin(GL_POLYGON);
    glColor3ub(163, 1103, 573);
    glVertex2f(0,0);
    glVertex2f(0,-.20);
    glVertex2f(.20,-.20);
    glVertex2f(.20,.0);
    glEnd();
    glPopMatrix();
    glutTimerFunc(1500,callback,0);
    glFlush();

}
void display6(int m)
{
    glutDisplayFunc(display7);
}
void display5()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(0,position, 0.0f);
    glBegin(GL_POLYGON);
    glColor3ub(213, 1153, 623);
    glVertex2f(0,0);
    glVertex2f(0,.20);
    glVertex2f(.20,.20);
    glVertex2f(.20,.0);
    glEnd();
    glPopMatrix();
    glutTimerFunc(1500,display6,0);
    glFlush();

}
void display4(int m)
{
    glutDisplayFunc(display5);
}
void display3()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(position1,0.0f, 0.0f);
    glBegin(GL_POLYGON);
    glColor3ub(263, 1203, 673);
    glVertex2f(-1,.0);
    glVertex2f(-1,.20);
    glVertex2f(-.80,.20);
    glVertex2f(-.80,0);
    glEnd();
    glPopMatrix();
    glutTimerFunc(1500,display4,0);
    glFlush();

}

void display2(int m)
{
    glutDisplayFunc(display3);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(position,0.0f, 0.0f);
    glBegin(GL_POLYGON);
    glColor3b(193, 853, 723);
    glVertex2f(.80,0);
    glVertex2f(.80,.20);
    glVertex2f(1,.20);
    glVertex2f(1,.0);
    glEnd();
    glPopMatrix();
    glutTimerFunc(1500,display2,0);
    glFlush();

}

void dis()
{
    glutDisplayFunc(display);
}



void handleKeypress(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 'a':
        speed += 0.1f;
        break;
    case 'b':
        speed1+=0.1f;
        break;
    case 'c':
        speed2+=0.1f;
        break;
       case 'd':
        speed3+=0.1f;
        break;
        glutPostRedisplay();
    }
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(400, 420);
    glutInitWindowPosition(40, 60);
    glutCreateWindow("TRANSLATION ANIMATION");
    glutDisplayFunc(dis);
    init();
    glutTimerFunc(100, update, 0);
    glutTimerFunc(100, update1, 0);
    glutTimerFunc(100, update2, 0);
       glutTimerFunc(100, update3, 0);
    glutKeyboardFunc(handleKeypress);
    glutMainLoop();
    return 0;
}



