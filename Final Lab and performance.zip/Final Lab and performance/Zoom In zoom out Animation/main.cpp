//Zoom in and out animation

/*----  THESE ARE THE HEADER FILES  -----*/
#include<iostream>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <math.h>

using namespace std;

float scale1 = 1.0f;
bool isIncrementing = true;





void circle(float r, float g, float b, float rad, float x1,  float y1 )
{
    glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
    for(int i=0; i<200; i++)
    {
        glColor3f(r, g, b);
        float pi=3.1416;
        float A=(i*2*pi)/100;

        float x = rad * cos(A);
        float y = rad * sin(A);


        glVertex2f(x + x1, y+ y1 );
    }
    glEnd();
}





void obj()
{

    circle(0, 0, 0, 0.5, 0, 0);

}



/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */


void display()


{


   glClearColor(0.0f, 0.0f, 1.0f, 1.0f);; // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(1.0 + scale1, 1.0+scale1, 1.0);

    obj();

    glFlush();  // Render now
    glPopMatrix();


}







void update(int value) {


 // Loop continues until both limits are crossed
        if (isIncrementing )
            {
                scale1+=0.1;

                if (scale1 >4)
                    {
                        isIncrementing = false;
                    }
            }

        else
            {
                scale1-=0.1;

                if (scale1 < -4)
                    {
                        isIncrementing = true;
                    }
            }


glutPostRedisplay(); //Notify GLUT that the display has changed

glutTimerFunc(20, update, 0); //Notify GLUT to call update again in 25 milliseconds
}





/* Main function: GLUT runs as a console application starting at main()  */
int main(int argc, char** argv)

{
    glutInit(&argc, argv);          // Initialize GLUT

    glutInitWindowSize(400, 550);    // Initializes window size

    glutInitWindowPosition(300,100); // Position the window's initial top-left corner

    glutCreateWindow("Zoom in and out animation");      // Create window with the given title

    glutDisplayFunc(display);       // Register callback handler for window re-paint event

    glutTimerFunc(20, update, 0); //Add a timer

    glutMainLoop();                 // Enter the event-processing loop
    return 0;

}
