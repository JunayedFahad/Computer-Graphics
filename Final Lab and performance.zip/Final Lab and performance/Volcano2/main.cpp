

/*----  THESE ARE THE HEADER FILES  -----*/
#include<iostream>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <math.h>
using namespace std;

int dispcounter = 0;



/*---- THE FUNCTION TO DRAW A TRIANGLE -------- */

void triangle( float r, float g, float b, float x1, float y1, float x2, float y2, float x3, float y3 )  // red, green , blue, x axis, y axis coordinates
{

    glBegin(GL_TRIANGLES);  // Each set of 3 vertices forms a triangle

    glColor3f(r, g, b);      // Red , green, blue values

    glVertex2f( x1, y1);      // x, y
    glVertex2f( x2, y2);       // x, y
    glVertex2f( x3, y3);       // x, y

    glEnd();                 // the triangle has been assigned

}




/*---- THE FUNCTION TO DRAW A RECTANGLE/QUAD  -------- */

void quads( float r, float g, float b, float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4) // red, green, blue, x axis, y axis
{

    glBegin(GL_QUADS);         // Each set of 4 vertices forms a rectangle/quad

    glColor3f(r, g, b);         // Red , green, blue values
    glVertex2f( x1, y1  );      // x, y
    glVertex2f( x2, y2  );      // x, y
    glVertex2f( x3, y3  );      // x, y
    glVertex2f( x4, y4  );    // x, y


    glEnd();               // the rectangle/quad has been assigned

}





/*---- THE FUNCTION TO DRAW A POLYGON  -------- */


void polygon(float r, float g, float b, float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, float x5, float y5)  // red, green, blue, x axis, y axis
{


    glBegin(GL_POLYGON);   // Each set of 5/6 vertices forms a polygon
    glColor3f(r, g, b);    // Red , green, blue values

    glVertex2f( x1, y1  );   // x, y
    glVertex2f( x2, y2  );   // x, y
    glVertex2f( x3, y3  );    // x, y
    glVertex2f( x4, y4 );    // x, y
    glVertex2f( x5, y5  );   // x, y

    glEnd();                // the polygon has been assigned

}

void sun()
{

    circle(0.973, 0.678, 0.129,  0.12,    -0.6, 0.8   );

}



void river()
{
    quads(0.114, 0.761, 0.749,   -1, -1,  1, -1, 1 ,-0.5 , -1, -0.5);
}



void land()
{
    quads(0.541, 0.741, 0.396,    -1 ,-0.5 , 1, -0.5,  1, 0.4, -1, 0.4);
    line( 0.761, 0.478, 0.102,          -1 ,-0.5 , 1, -0.5, 2     );
}



void volcanobase()
{

    //quads(0.075, 0.082, 0.137, -1, -0.5, 1, -0.5, 0.55, 0.17, -0.46, 0.15);
    quads(0.075, 0.082, 0.137,-0.46, 0.15, 0.46, 0.15, 0.19, 0.75, -0.12, 0.75  );


}


void morningsky()
{

    quads(0.243, 0.647, 0.808,   -1, 0.4,  1, 0.4, 1 ,1 , -1, 1);

}






void lava1()
{
    triangle(0.98, 0.396, 0.106, -0.12, 0.64, -0.05, 0.77, -0.12, 0.77 );
    triangle(0.98, 0.396, 0.106, 0, 0.65, 0.05, 0.77, -0.05, 0.77 );
    triangle(0.98, 0.396, 0.106, 0.15, 0.65, 0.21, 0.76, 0.05, 0.77 );
    quads(0.98, 0.396, 0.106, -0.12, 0.75, 0.19, 0.75, 0.21, 0.76, -0.12, 0.77   );

}


void lava2()
{

    quads(0.941, 0.114, 0.114,-0.46,  0.15, 0.46, 0.15, 0.19, 0.75, -0.12, 0.75  );
    quads(0.941, 0.114, 0.114, -0.72, -0.11, -0.34, -0.26, -0.26, 0.15,  -0.46, 0.15  );
   triangle(0.941, 0.114, 0.114,  -0.67, -0.27  , -0.34, -0.26,-0.72, -0.11 );
   triangle(0.941, 0.114, 0.114, -0.38, -0.45, -0.18 , -0.02, -0.26, 0.15 );
   triangle(0.941, 0.114, 0.114, -0.46, 0.15, 0.06, -0.36, 0.1, 0.16 );
   triangle(0.941, 0.114, 0.114, -0.26, 0.15, 0.25, -0.19, 0.46, 0.17  );
   triangle(1, 0.5, 0, -0.26, 0.15, 0.25, -0.19, 0.46, 0.17  );
    quads(1, 0.5, 0, 0.1, 0.16, 0.6, -0.2, 0.76, -0.04, 0.39, 0.32  );



}


void lava3()
{
     triangle(1, 0.5, 0, -1, -0.5 , -0.56, 0.02, -0.68, 0.01 );
    polygon(1, 0.5, 0, -0.95, -0.66, -0.91, -0.77, -0.71, -0.66, -0.34, -0.26,  -0.45 ,-0.22  );
    polygon(1, 0.5, 0, -0.45, -0.76, -0.2, -0.8, 0, -0.6, 0.39, 0.32, -0.18, -0.02  );
    polygon(1, 0.5, 0, 0, -0.71, 0.13, -0.64, 0.27, -0.32, 0.31, -0.09,  0.16, -0.4 );
    polygon(0.941, 0.114, 0.114, 0.37, -0.65, 0.56, -0.81, 0.65, -0.45, 0.46, 0.17, 0.25, -0.19 );
    polygon(0.941, 0.114, 0.114, 0.75, -0.55, 0.93, -0.74, 0.94, -0.56, 0.76, -0.04, 0.66, -0.14 );




}

*/






/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */
void display1()
{


    glClearColor(0.471f, 0.847f, 0.878f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    volcanobase();
    river();
    land();
    sun:

    glFlush();  // Render now


}





void display2()
{


    glClearColor(0.471f, 0.847f, 0.878f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    volcanobase();
    river();
    land();
    lava1();
   lava2();


    glFlush();  // Render now


}





void display3()
{


    glClearColor(0.471f, 0.847f, 0.878f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color



    volcanobase();
    river();
    land();
    lava3();
    lava2();

    glFlush();  // Render now



}




void update(int value)


{


if(dispcounter == 0)
{
    glutDisplayFunc(display1);
}



if( dispcounter == 1)
{

    glutDisplayFunc(display2);
}



if(dispcounter == 2)
{

    glutDisplayFunc(display3);

}






dispcounter++;



glutPostRedisplay();
glutTimerFunc(1200, update, 0);
}




/* Main function: GLUT runs as a console application starting at main()  */
int main(int argc, char** argv)

{
    glutInit(&argc, argv);          // Initialize GLUT

    glutInitWindowSize(920, 920);    // Initializes window size

    glutInitWindowPosition(500,100); // Position the window's initial top-left corner

    glutCreateWindow("VOLCANO");      // Create window with the given title

    glutDisplayFunc(display1);       // Register callback handler for window re-paint event

    glutTimerFunc(1200, update, 0);

    glutMainLoop();                 // Enter the event-processing loop
    return 0;

}
