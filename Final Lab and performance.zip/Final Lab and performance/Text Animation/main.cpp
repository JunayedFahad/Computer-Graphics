#include<iostream>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <math.h>
#include<GL/freeglut.h>

using namespace std;


float move1 = 0.0f ;      // 0.0f;


/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */
void display()
{

 glColor3f(0.529, 0.808, 0.922); // Day color
   glBegin(GL_QUADS);
   glVertex2f(-1.0, -1.0);
   glVertex2f(1.0, -1.0);
   glVertex2f(1.0, 1.0);
   glVertex2f(-1.0, 1.0);
   glEnd();




   // Draw the ground
   glColor3f(0.133, 0.545, 0.133);
   glBegin(GL_QUADS);
   glVertex2f(-1.0, -0.5);
   glVertex2f(1.0, -0.5);
   glVertex2f(1.0, -1.0);
   glVertex2f(-1.0, -1.0);
   glEnd();

   // Draw the sun
   glColor3f(1.0, 1.0, 0.0); // Sun color
   glBegin(GL_POLYGON);
   for (int i = 0; i < 360; i++) {
       float angle = i * 3.14159265 / 180;
       glVertex2f(0.2 * cos(angle), 0.2 * sin(angle) + 0.4);
   }
   glEnd();

   // Tree
   glColor3f(0.7, 0.5, 0.1);
   glBegin(GL_QUADS);
   glVertex2f(-0.45, -0.6);
   glVertex2f(-0.4, -0.6);
   glVertex2f(-0.4, -0.5);
   glVertex2f(-0.45, -0.5);
   glEnd();

   glColor3f(0.1, 0.4, 0.1);
   glBegin(GL_TRIANGLES);
   glVertex2f(-0.5, -0.5);
   glVertex2f(-0.35, -0.5);
   glVertex2f(-0.42, -0.35);
   glEnd();


   glColor3f(0.0, 0.2, 0.0);
   glBegin(GL_TRIANGLES);
   glVertex2f(1.0 - 0.2, -0.5);
   glVertex2f(0.9 - 0.2, -0.4);
   glVertex2f(0.8 - 0.2, -0.5);
   glEnd();


   // River
   glColor3f(0.0, 0.5, 1.0); // Blue color
   glBegin(GL_QUADS);
   glVertex2f(-1.0, -1.0);
   glVertex2f(1.0, -1.0);
   glVertex2f(1.0, -0.8);
   glVertex2f(-1.0, -0.8);
   glEnd();



    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef( move1, 0.0f, 0.0f);

    //text
    glColor3f(0.280, 0.150, 0.2);
    glRasterPos2f(1.50, -0.68);
    glutBitmapString(GLUT_BITMAP_TIMES_ROMAN_24,(const unsigned char*) "Assalamualikum Sir,May Allah keep you healty");
glEnd();



    glPopMatrix();
   glFlush();

   glFlush();

}




void update(int value)
{






    if (-move1 < 1.5)
    {
        move1-=0.01f;
    }




    glutPostRedisplay(); //Notify GLUT that the display has changed

    glutTimerFunc(20, update, 0); //Notify GLUT to call update again in 25 milliseconds
}





/* Main function: GLUT runs as a console application starting at main()  */
int main(int argc, char** argv)

{
    glutInit(&argc, argv);          // Initialize GLUT

    glutInitWindowSize(1000,900);    // Initializes window size

    glutInitWindowPosition(500,200); // Position the window's initial top-left corner

    glutCreateWindow("Text Animation");      // Create window with the given title

    glutDisplayFunc(display);
     // Register callback handler for window re-paint event

    glutTimerFunc(200, update, 0); //Add a timer

    glutMainLoop();                 // Enter the event-processing loop
    return 0;

}
