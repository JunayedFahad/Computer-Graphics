#include <windows.h>  // for MS Windows
#include <GL/glut.h>
#include <math.h>

float timeOfDay = 0.0f;

void Circle(float radius, float xc, float yc, float r, float g, float b) {
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color to black and opaque
    //glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)
    glLineWidth(7.5);
    glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
    for (int i = 0; i < 200; i++) {
        glColor3ub(r, g, b);
        float pi = 3.1416;
        float A = (i * 2 * pi) / 200;
        float rad = radius;
        float x = rad * cos(A);
        float y = rad * sin(A);
        glVertex2f(x + xc, y + yc);
    }
    glEnd();
}

void CircleBorder(float radius, float xc, float yc, float width) {
    //glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Set background color to black and opaque
    //glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)
    glLineWidth(width);
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
    for (int i = 0; i < 200; i++) {
        glColor3ub(0, 0, 0);
        float pi = 3.1416;
        float A = (i * 2 * pi) / 200;
        float rad = radius;
        float x = rad * cos(A);
        float y = rad * sin(A);
        glVertex2f(x + xc, y + yc);
    }
    glEnd();
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
}

/* Initialize OpenGL Graphics */

/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */
void display() {
    glClearColor(0.65882f - timeOfDay, 0.8392157f - timeOfDay, 0.99607843f - timeOfDay, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color


    // Other shapes and scenarios here...

       Circle(0.3, 0.5, 0.65, 253, 225, 155); // Moon / Sun change this value; // Moon / Sun

    glFlush();  // Render now
}

/* Function to update the time of day (day to night transition) */
void updateTimeOfDay(int value) {
    timeOfDay += 0.001f; // Increment time of day for a smooth transition
    if (timeOfDay > 0.65882f) {
        timeOfDay = 0.0f; // Reset time of day after reaching night
    }

    glutPostRedisplay(); // Update the display with new time of day
    glutTimerFunc(25, updateTimeOfDay, 0); // Recall the function after 25 milliseconds
}

/* Main function: GLUT runs as a console application starting at main() */
int main(int argc, char** argv) {
    glutInit(&argc, argv);          // Initialize GLUT
    glutInitWindowSize(600, 500);   // Set the window's initial width & height
    glutInitWindowPosition(200, 0);  // Set the window's initial position according to the monitor
    glutCreateWindow("Day  Night Scenario");  // Create window with the given title
    glutDisplayFunc(display);       // Register callback handler for window re-paint event
                                    // Our own OpenGL initialization
    glutTimerFunc(25, updateTimeOfDay, 0); // Start the timer for day/night transition
    glutMainLoop();                 // Enter the event-processing loop
    return 0;
}
