#include <windows.h>
#include <GL/glut.h>
#include <math.h>


void display()

{


    glClearColor(0.0f,0.0f,0.0f,1.0f);
    glClear(GL_COLOR_BUFFER_BIT);





    glColor3f(0.0,0.5,0.0);
    glBegin(GL_POLYGON);
    glVertex2f(3.0,2.0);
    glVertex2f(-3.0,2.0);
    glVertex2f(-3.0,-2.0);
    glVertex2f(3.0,-2.0);
    glEnd();








    glColor3f(1.00, 0.00, 0.00);

 glBegin(GL_POLYGON);// Draw a Red 1x1 Square centered at origin
	for(int i=0;i<200;i++)
        {

            float pi=3.1416;
            float angle=(i*2*pi)/200;
            float radius=0.5;
            float x = radius* cos(angle);
            float y = radius * sin(angle);
            glVertex2f(x,y);
        }


    glEnd();
    glFlush();


}
int main (int argc, char** argv)

{


glutInit(&argc , argv);
glutCreateWindow("Bangladesh Flag");
glutInitWindowSize(600,400);
glutDisplayFunc(display);
glutMainLoop();





    return 0 ;

}
