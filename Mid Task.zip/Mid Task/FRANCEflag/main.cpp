#include <windows.h>
#include <GL/glut.h>  /

void display() {
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw blue stripe
    glColor3f(0.0, 0.0, 1.0);
    glBegin(GL_POLYGON);
    glVertex2f(-1.0, 1.0);
    glVertex2f(1.0, 1.0);
    glVertex2f(1.0, 0.33);
    glVertex2f(-1.0, 0.33);
    glEnd();


    glColor3f(1.0, 1.0, 1.0);
    glVertex2f(-1.0, 0.33);
    glVertex2f(1.0, 0.33);
    glVertex2f(1.0, -0.33);
    glVertex2f(-1.0, -0.33);
    glEnd();

    // Draw red stripe
    glColor3f(1.0, 0.0, 0.0); // Red color
    glBegin(GL_POLYGON);
    glVertex2f(-1.0, -0.33);
    glVertex2f(1.0, -0.33);
    glVertex2f(1.0, -1.0);
    glVertex2f(-1.0, -1.0);
    glEnd();

    glFlush();  // Render now
}

/* Main function: GLUT runs as a console application starting at main()  */
int main(int argc, char** argv) {
    glutInit(&argc, argv);                 // Initialize GLUT
    glutCreateWindow("France Flag");
    glutInitWindowSize(640, 480);          // Set the window's initial width & height
    glutDisplayFunc(display);              // Register display callback handler for window re-paint
    glutMainLoop();                        // Enter the event-processing loop
    return 0;
}

