#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h


void display() {
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);


    glColor3f(1.0, 1.0, 1.0); // White color
     glBegin(GL_POLYGON);
    glVertex2f(-1.20, 1.45);
    glVertex2f(1.20, 1.475);
    glVertex2f(1.20, 0.45);
    glVertex2f(-1.20, 0.45);
    glEnd();


    glColor3f(1.0, 0.0, 0.0); // Red color
    glBegin(GL_POLYGON);
    glVertex2f(-1.0, 0.0);
    glVertex2f(1.0, 0.0);
    glVertex2f(1.0, -1.0);
    glVertex2f(-1.0, -1.0);
    glEnd();

    glFlush();
}


int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutCreateWindow("Poland Flag");
    glutInitWindowSize(620, 420);
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
