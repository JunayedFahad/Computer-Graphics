#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <cmath>


void display() {
    glClearColor(0.0f, 0.5f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw yellow diamond
    glColor3f(1.0, 1.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(-0.10, 0.5);
    glVertex2f(0.5, 0.10);
    glVertex2f(0.10, 0.5);
    glVertex2f(0.5, -0.10);
    glEnd();

    // Draw blue circle
    glColor3f(0.0, 0.0, 1.0);
    glBegin(GL_POLYGON);
    float radius = 0.2;
    float angle;
    for (int i = 0; i < 360; i++) {
        angle = i * 3.14159 / 180;
        glVertex2f(0.0 + radius * cos(angle), 0.0 + radius * sin(angle));
    }
    glEnd();

    // Draw 27 white stars
    glColor3f(1.0, 1.0, 1.0); // White color
    float starRadius = 0.025; // Smaller star size
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 6; j++) {
            if (i * 6 + j < 27) {
                glBegin(GL_POLYGON);
                for (int k = 0; k < 10; k++) {
                    angle = k * 3.14159 / 5;
                    if (k % 2 == 0) {
                        glVertex2f(0.0 + starRadius * cos(angle), 0.0 + starRadius * sin(angle));
                    } else {
                        glVertex2f(0.0 + starRadius / 2 * cos(angle), 0.0 + starRadius / 2 * sin(angle));
                    }
                }
                glEnd();
                glTranslatef(0.1, 0.0, 0.0);
            }
        }
        glTranslatef(-0.5
                     , -0.1, 0.0);
    }

    glFlush();  // Render now
}


int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutCreateWindow("Flag of Brazil");
    glutInitWindowSize(640, 480);
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

