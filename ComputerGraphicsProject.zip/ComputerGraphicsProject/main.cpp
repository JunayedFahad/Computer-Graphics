#include<iostream>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <GL/gl.h>  // GLUT, include glu.h and gl.h
#include <math.h>
#include<cstdio>
#include<GL/freeglut.h>
using namespace std;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////**-------------- Defining position And Speed for Animations--------------**///////////////



bool animationIsOn = true;


//Position of SummerAutumnSpring Clouds
GLfloat Pos_SuAuSpMorCloud1 = 0.0f;
GLfloat Pos_SuAuSpMorCloud2 = 0.0f;
GLfloat Pos_SuAuSpMorCloud3 = 0.0f;
GLfloat Pos_SuAuSpMorCloud4 = 0.0f;
GLfloat Pos_SuAuSpMorCloud5 = 0.0f;
GLfloat Pos_SuAuSpMorCloud6 = 0.0f;

GLfloat Speed_SuAuSpMorCloud = 0.0001f; // Speed of AutumnSpring Clouds

//-------------------------------------------------------------------------

//Position of Boats
GLfloat Pos_Boat1 = 0.0f;
GLfloat Pos_Boat2 = 0.0f;

GLfloat Speed_Boat = 0.0005f; // Speed of Boats

//---------------------------------------------------------------------------

//Position of Cars
GLfloat Pos_Car1 = 0.0f;
GLfloat Pos_Car2 = 0.0f;
GLfloat Pos_Car3 = 0.0f;
GLfloat Pos_Car4 = 0.0f;
GLfloat Pos_Car5 = 0.0f;
GLfloat Pos_Car6 = 0.0f;
GLfloat Pos_Car7 = 0.0f;
GLfloat Pos_Car8 = 0.0f;


GLfloat Speed_Car = 0.005f; // Speed of Cars


//----------------------------------------------------------------------------

//scale for thunderstorm
GLfloat Scale_Thunderstorm = 0.01;

int stormIncrease = 0;

GLfloat ScaleDecrease_Thunderstorm = 0.01;

GLfloat ScaleIncrease_Thunderstorm = 1.0;


//----------------------------------------------------------------------------

//Position for rain

GLfloat Pos_Rain = 0.0f;
GLfloat Speed_Rain = 0.001f;


//----------------------------------------------------------------------------

//Position for snow

GLfloat Pos_snow_X = 0.0f;
GLfloat Pos_snow_Y = 0.0f;

GLfloat Speed_snow_X =  0.00001;
GLfloat Speed_snow_Y =  0.005;
















///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
///////////**-------------- FUNCTIONS TO DRAW REGULAR SHAPES --------------**///////////////





/*---- THE FUNCTION TO DRAW A POINT -------- */

void points( float r, float g, float b, float s, float x, float y    )
{
    glPointSize(s);        // Size of the point

    glBegin(GL_POINTS);    // The set of vertices form a point
    glColor3f(r, g, b);    // Red , Green , Blue color values
    glVertex2f(x, y);      // x, y

    glEnd();
}






/*---- THE FUNCTION TO DRAW A LINE -------- */

void line (  float r, float g, float b, float x1, float y1, float x2, float y2, int lw  )
{

    glLineWidth(lw);       // Width of the line

    glBegin(GL_LINES);     // Each set of 2 vertices form a line
    glColor3f(r, g, b);    // Red , Green , Blue color values
    glVertex2f(x1, y1);    // x, y
    glVertex2f(x2, y2);    // x, y

    glEnd();



}






/*---- THE FUNCTION TO DRAW A TRIANGLE -------- */

void triangle( float r, float g, float b, float x1, float y1, float x2, float y2, float x3, float y3 )
{

    glBegin(GL_TRIANGLES);  // Each set of 3 vertices form a trinagle
    glColor3f(r, g, b);     // Red , Green , Blue color values

    glVertex2f( x1, y1);    // x, y
    glVertex2f( x2, y2);    // x, y
    glVertex2f( x3, y3);    // x, y

    glEnd();

}





/*---- THE FUNCTION TO DRAW A RECTANGLE/QUAD  -------- */

void quads(  float r, float g, float b, float x1, float y1, float x2,  float y2, float x3, float y3, float x4,   float y4)
{

    glBegin(GL_QUADS);      // Each set of 4 vertices form a quad
    glColor3f(r, g, b);     // Red , Green , Blue color values

    glVertex2f( x1, y1  );  // x, y
    glVertex2f( x2, y2  );  // x, y
    glVertex2f( x3, y3  );  // x, y
    glVertex2f( x4, y4  );  // x, y


    glEnd();

}






/*---- THE FUNCTION TO DRAW A POLYGON  -------- */

void polygon(float r, float g, float b, float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, float x5, float y5)
{


    glBegin(GL_POLYGON);   // Each set of 5 vertices form a polygon
    glColor3f(r, g, b);    // Red , Green , Blue color values

    glVertex2f( x1, y1  );  // x, y
    glVertex2f( x2, y2  );  // x, y
    glVertex2f( x3, y3  );  // x, y
    glVertex2f( x4, y4  );  // x, y
    glVertex2f( x5, y5  );  // x, y


    glEnd();

}








/*---- THE FUNCTION TO DRAW A CIRCLE  -------- */

void circle(float r, float g, float b, float rad, float x1,  float y1 )
{
    glBegin(GL_POLYGON);

    for(int i=0; i<200; i++)
        {
            glColor3f(r, g, b);    // Red , Green , Blue color values
            float pi=3.1416;
            float A=(i*2*pi)/200;

            float x = rad * cos(A);
            float y = rad * sin(A);

            glVertex2f(x + x1, y+ y1 );  // x, y
        }

    glEnd();
}








/////////////////////////////////////////////////////////////////////////////////////////////
///////////**------- FUNCTIONS TO DRAW REGULAR SHAPES WITH GRADIENT COLORS ---------**///////






/*---- THE FUNCTION TO DRAW GRADIENT LINE -------- */

void linegrad (  float r, float g, float b, float x1, float y1, float x2, float y2, int lw , float r1, float g1, float b1 )
{

    glLineWidth(lw);    // line Width
    glBegin(GL_LINES);  // Each set of 2 vertices form a line

    glColor3f(r, g, b);  // color1
    glVertex2f(x1, y1);    // x, y

    glColor3f(r1, g1, b1); // color2
    glVertex2f(x2, y2);    // x, y

    glEnd();



}






/*---- THE FUNCTION TO DRAW GRADIENT TRINAGLE -------- */

void trianglegrad( float r, float g, float b, float x1, float y1, float x2, float y2, float x3, float y3, float r1, float g1, float b1 )
{

    glBegin(GL_TRIANGLES); // Each set of 2 vertices form a line
    glColor3f(r, g, b);     //color1

    glVertex2f( x1, y1  );   // x, y
    glVertex2f( x2, y2  );   // x, y

    glColor3f(r1, g1, b1); // color2
    glVertex2f( x3, y3  );   // x, y

    glEnd();

}








/*---- THE FUNCTION TO DRAW GRADIENT RECTANGLE/QUAD -------- */

void quadsgrad (float r, float g, float b, float x1, float y1, float x2,  float y2, float x3, float y3, float x4, float y4, float r1, float g1, float b1)
{

    glBegin(GL_QUADS);   // Each set of 2 vertices form a line
    glColor3f(r, g, b);    // color1

    glVertex2f( x1, y1  );  // x, y
    glVertex2f( x2, y2  );  // x, y

    glColor3f(r1, g1, b1);  //color2
    glVertex2f( x3, y3  );  // x, y
    glVertex2f( x4, y4  );  // x, y


    glEnd();

}








/*---- THE FUNCTION TO DRAW GRADIENT POLYGON -------- */

void polygongrad (float r, float g, float b, float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, float x5, float y5, float r1, float g1, float b1)
{


    glBegin(GL_POLYGON);   // Each set of 2 vertices form a line
    glColor3f(r, g, b);     //color1

    glVertex2f( x1, y1  );   // x, y
    glVertex2f( x2, y2  );   // x, y
    glVertex2f( x3, y3  );   // x, y

    glColor3f(r1, g1, b1);  //color2
    glVertex2f( x4, y4 );   // x, y
    glVertex2f( x5, y5  );   // x, y


    glEnd();

}


void quadsgradTransparent(float r, float g, float b, float a, float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, float r1, float g1, float b1, float a1)
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_QUADS);
    glColor4f(r, g, b, a);
    glVertex2f( x1, y1  );
    glVertex2f( x2, y2 );

    glColor4f(r1, g1, b1, a1);
    glVertex2f( x3, y3 );
    glVertex2f( x4, y4 );

    glDisable(GL_BLEND);
    glEnd();

}













///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////*---- THE FUNCTION FOR ALL THE OBJECTS IN THE PROJECT -------- *////////////////////////////////////////////





void skyAutumnMorning() //skyAutumnMorning
{

    quadsgrad(0.831, 0.922, 0.996, -1, 0.4, 1, 0.4,  1, 1, -1, 1, 0.525, 0.835, 1);

}






void sun()  //sun
{
    circle(1, 0.969, 0.098, 0.07, 0.34, 0.85);
}





void riverMorning() //riverMorning
{

    quadsgrad(0.047, 0.286, 0.871, -1, 0, 1, 0,  1, 0.4, -1, 0.4, 0.031, 0.408, 0.612);

}






void SuAuSpMorningCloud1()  //SuAuSpMorningCloud1
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_SuAuSpMorCloud1, 0.0f, 0.0f); // Translation Animation

    circle(1,1,1,0.04, -0.85, 0.8);
    circle(1,1,1,0.05, -0.8, 0.8);
    circle(1,1,1,0.04, -0.75, 0.8);

    glPopMatrix();

}





void SuAuSpMorningCloud2() //SuAuSpMorningCloud2
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_SuAuSpMorCloud2, 0.0f, 0.0f); // Translation Animation

    circle(1,1,1,0.03,-0.55, 0.9);
    circle(1,1,1,0.05,-0.5, 0.9);
    circle(1,1,1,0.03,-0.45, 0.9);

    glPopMatrix();

}





void SuAuSpMorningCloud3() //SuAuSpMorningCloud3
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_SuAuSpMorCloud3, 0.0f, 0.0f); // Translation Animation

    circle(1,1,1, 0.04,-0.25, 0.8);
    circle(1,1,1,0.05,-0.2, 0.8);
    circle(1,1,1, 0.04,-0.15, 0.8);

    glPopMatrix();

}




void SuAuSpMorningCloud4() //SuAuSpMorningCloud4
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_SuAuSpMorCloud4, 0.0f, 0.0f); // Translation Animation

    circle(1,1,1, 0.04,0.05, 0.9);
    circle(1,1,1, 0.05,0.1, 0.9);
    circle(1,1,1, 0.04,0.15, 0.9);

    glPopMatrix();
}




void SuAuSpMorningCloud5() //SuAuSpMorningCloud5
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_SuAuSpMorCloud5, 0.0f, 0.0f); // Translation Animation

    circle(1,1,1, 0.04,0.55, 0.8);
    circle(1,1,1, 0.05,0.6, 0.8);
    circle(1,1,1, 0.04,0.65, 0.8);

    glPopMatrix();

}




void SuAuSpMorningCloud6() //SuAuSpMorningCloud6
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_SuAuSpMorCloud6, 0.0f, 0.0f); // Translation Animation

    circle(1,1,1, 0.04,0.85, 0.9);
    circle(1,1,1, 0.05,0.9, 0.9);
    circle(1,1,1, 0.04,0.95, 0.9);

    glPopMatrix();

}











void landMorning() //landMorning
{

    quads(  0.922, 0.675, 0.051,  -1, 0.35, -0.5, 0.38, -0.5, 0.4, -1, 0.4);
    quads(  0.922, 0.675, 0.051, -0.5, 0.38,0, 0.36,   0, 0.4, -0.5, 0.4);
    quads(   0.922, 0.675, 0.051,  0, 0.36, 0.4, 0.38, 0.4, 0.4, 0, 0.4);
    triangle(  0.922, 0.675, 0.051,0.4, 0.38,  0.65, 0.4,  0.4, 0.4  );
    quads(   0.922, 0.675, 0.051, 0.65, 0.4, 0.62, 0.4,  1, 0.38,  1, 0.4);


}








void SummerAutumnMorningHill1() //SummerAutumnMorningHill1
{
    polygon(0.439, 0.757, 0.459, -1, 0.48,-1,0.4,-.58,0.4,-.7,0.53,-0.92,0.52);
    triangle(0.439, 0.757, 0.459,  -0.92, 0.52,-0.68, 0.52,-0.83, 0.57);
}






void SummerAutumnMorningHill2() //SummerAutumnMorningHill2
{
    quads(0.153, 0.471, 0.439,   -0.8, 0.5,-0.49, 0.45,-0.62, 0.6,-0.72, 0.6);
    triangle(0.153, 0.471, 0.439,   -0.72, 0.6,-0.62, 0.6,-0.67, 0.65);
}





void SummerAutumnMorningHill3() //SummerAutumnMorningHill3
{
    triangle(0.204, 0.639, 0.38,   -0.57, 0.54,-0.45, 0.54,-0.5, 0.57);
    polygon(0.204, 0.639, 0.38,   -0.67, 0.49, -0.58, 0.4,-0.25, 0.4,-0.45, 0.54,-0.57,0.54);
}







void SummerAutumnMorningHill4() //SummerAutumnMorningHill4
{
    quads(0.165, 0.427, 0.467,  -0.28, 0.55,-0.4, 0.5,-0.25, 0.4,-0.19, 0.52);
}





void SummerAutumnMorningHill5() //SummerAutumnMorningHill5
{
    quads(0.443, 0.761, 0.467,   -0.11, 0.52,-0.31, 0.44,-0.25, 0.4,0.12, 0.4);
}






void SummerAutumnMorningHill6() //SummerAutumnMorningHill6
{
    quads(0.314, 0.541, 0.329,   0.09, 0.61,-0.19, 0.52,-0.25, 0.4,0.3, 0.4);
}





void SummerAutumnMorningHill7() //SummerAutumnMorningHill7
{
    quads(0.157, 0.565, 0.42,  0.28, 0.69, 0.13, 0.57, 0.27, 0.43, 0.37, 0.53);
}






void SummerAutumnMorningHill8() //SummerAutumnMorningHill8
{
    triangle(0.118, 0.38, 0.271,  0.39, 0.68, 0.28, 0.54, 0.5, 0.48);
}







void SummerAutumnMorningHill9() //SummerAutumnMorningHill9
{
    quads(0.545, 0.769, 0.494,   0.52, 0.7, 0.27, 0.43, 0.3, 0.4, 0.61, 0.4);
}






void SummerAutumnMorningHill10() //SummerAutumnMorningHill10
{
    polygon(0.114, 0.561, 0.263, 0.64, 0.67,  0.5, 0.5,  0.61, 0.4, 1, 0.4, 1, 0.46);
}



void SummerAutumnMorningHill11() //SummerAutumnMorningHill11
{
    quads(0.157, 0.318, 0.396,  0.95, 0.64, 0.76, 0.59, 1, 0.46, 1, 0.6);

}








void SuAuMorningChrisTree1()  //SuAuMorningChrisTree1
{
    //leafs
    triangle(0, 0.9, 0, -0.9, 0.5 , -0.82, 0.5, -0.86, 0.54);
    quads(0, 0.7, 0,-0.9, 0.48, -0.82, 0.48, -0.84, 0.5, -0.88, 0.5);
    quads(0, 0.5, 0,-0.9, 0.46, -0.82, 0.46, -0.84, 0.48, -0.88, 0.48);

    //treelog
    quads(0.533, 0.361, 0.212, -0.87, 0.41, -0.85, 0.41,  -0.855, 0.46, -0.865, 0.46 );
    quads(0.533, 0.361, 0.212,  -0.88, 0.4, -0.84, 0.4,-0.85, 0.41 , -0.87, 0.41 );

}





void SuAuMorningChrisTree2() //SuAuMorningChrisTree2
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.77f, 0.0f, 0.0f);

    //leafs
    triangle(0, 0.9, 0, -0.9, 0.5 , -0.82, 0.5, -0.86, 0.54);
    quads(0, 0.7, 0,-0.9, 0.48, -0.82, 0.48, -0.84, 0.5, -0.88, 0.5);
    quads(0, 0.5, 0,-0.9, 0.46, -0.82, 0.46, -0.84, 0.48, -0.88, 0.48);

    //treelogs
    quads(0.533, 0.361, 0.212, -0.87, 0.41, -0.85, 0.41,  -0.855, 0.46, -0.865, 0.46 );
    quads(0.533, 0.361, 0.212,  -0.88, 0.4, -0.84, 0.4,-0.85, 0.41 , -0.87, 0.41 );

    glPopMatrix();

}





void SuAuMorningChrisTree3() //SuAuMorningChrisTree3
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.4f, 0.0f, 0.0f);

    //leafs
    triangle(0, 0.9, 0, -0.9, 0.5 , -0.82, 0.5, -0.86, 0.54);
    quads(0, 0.7, 0,-0.9, 0.48, -0.82, 0.48, -0.84, 0.5, -0.88, 0.5);
    quads(0, 0.5, 0,-0.9, 0.46, -0.82, 0.46, -0.84, 0.48, -0.88, 0.48);

    //treelogs
    quads(0.533, 0.361, 0.212, -0.87, 0.41, -0.85, 0.41,  -0.855, 0.46, -0.865, 0.46 );
    quads(0.533, 0.361, 0.212,  -0.88, 0.4, -0.84, 0.4,-0.85, 0.41 , -0.87, 0.41 );

    glPopMatrix();

}





void SuAuMorningChrisTree4() //SuAuMorningChrisTree4
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.5f, 0.0f, 0.0f);

    //leafs
    triangle(0, 0.9, 0, -0.9, 0.5 , -0.82, 0.5, -0.86, 0.54);
    quads(0, 0.7, 0,-0.9, 0.48, -0.82, 0.48, -0.84, 0.5, -0.88, 0.5);
    quads(0, 0.5, 0,-0.9, 0.46, -0.82, 0.46, -0.84, 0.48, -0.88, 0.48);

    //treelog
    quads(0.533, 0.361, 0.212, -0.87, 0.41, -0.85, 0.41,  -0.855, 0.46, -0.865, 0.46 );
    quads(0.533, 0.361, 0.212,  -0.88, 0.4, -0.84, 0.4,-0.85, 0.41 , -0.87, 0.41 );

    glPopMatrix();

}













void cocoTree1()  //cocoTree1
{
    //leafs
     triangle(0, 0.7, 0, -0.74, 0.48 , -0.69, 0.5, -0.68, 0.52);
     quads(0, 0.7, 0, -0.69, 0.5, -0.67, 0.5, -0.62, 0.48, -0.68, 0.52);

     triangle(0, 0.6, 0, -0.76, 0.5,  -0.68, 0.52, -0.68, 0.54);
     triangle(0, 0.6, 0, -0.68, 0.52,  -0.6, 0.5,  -0.68, 0.54);


     triangle(0, 0.7, 0, -0.7, 0.53, -0.68, 0.54, -0.74, 0.56);
     triangle(0, 0.7, 0, -0.68, 0.54, -0.66, 0.53, -0.62, 0.56);

     //treelogs
     quads(0.682, 0.337, 0.071, -0.7, 0.4, -0.66, 0.4, -0.67, 0.5, -0.69, 0.5 );

}





void cocoTree2() //cocoTree2
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.8f, 0.0f, 0.0f);

    //leafs
     triangle(0, 0.7, 0, -0.74, 0.48 , -0.69, 0.5, -0.68, 0.52);
     quads(0, 0.7, 0, -0.69, 0.5, -0.67, 0.5, -0.62, 0.48, -0.68, 0.52);

     triangle(0, 0.6, 0, -0.76, 0.5,  -0.68, 0.52, -0.68, 0.54);
     triangle(0, 0.6, 0, -0.68, 0.52,  -0.6, 0.5,  -0.68, 0.54);


     triangle(0, 0.7, 0, -0.7, 0.53, -0.68, 0.54, -0.74, 0.56);
     triangle(0, 0.7, 0, -0.68, 0.54, -0.66, 0.53, -0.62, 0.56);

     //treelog
     quads(0.682, 0.337, 0.071, -0.7, 0.4, -0.66, 0.4, -0.67, 0.5, -0.69, 0.5 );
     glPopMatrix();

}





void cocoTree3() //cocoTree1
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.6f, 0.0f, 0.0f);

    //leafs
     triangle(0, 0.7, 0, -0.74, 0.48 , -0.69, 0.5, -0.68, 0.52);
     quads(0, 0.7, 0, -0.69, 0.5, -0.67, 0.5, -0.62, 0.48, -0.68, 0.52);

     triangle(0, 0.6, 0, -0.76, 0.5,  -0.68, 0.52, -0.68, 0.54);
     triangle(0, 0.6, 0, -0.68, 0.52,  -0.6, 0.5,  -0.68, 0.54);


     triangle(0, 0.7, 0, -0.7, 0.53, -0.68, 0.54, -0.74, 0.56);
     triangle(0, 0.7, 0, -0.68, 0.54, -0.66, 0.53, -0.62, 0.56);

     //treelogs
     quads(0.682, 0.337, 0.071, -0.7, 0.4, -0.66, 0.4, -0.67, 0.5, -0.69, 0.5 );
     glPopMatrix();

}









void pineTree1() //pineTree1
{
    triangle (0, 0.6, 0, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   ); //leafs

    quads(0.78, 0.533, 0.306, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  ); //log

}






void pineTree2() //pineTree2
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.12f, 0.0f, 0.0f);


    triangle (0, 0.6, 0, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   ); //leafs
    quads(0.78, 0.533, 0.306, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  ); //log

    glPopMatrix();

}






void pineTree3() //pineTree3
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.6f, 0.0f, 0.0f);


    triangle (0, 0.6, 0, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   ); //leafs
    quads(0.78, 0.533, 0.306, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  ); //log

    glPopMatrix();


}








void boat1()  //boat1
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_Boat1, 0.12f, 0.0f); //Transition Animation


    //body
    quads(0.725, 0.725, 0.725, -0.92, 0.08, -0.88, 0.02, -0.72, 0.02, -0.64, 0.08 );
    quads(0.949, 0.867, 0.867,  -0.9, 0.08 , -0.76, 0.08  , -0.8, 0.14  , -0.91, 0.14  );

    //window
    quads(0.459, 0.914, 0.918,  -0.897, 0.1  , -0.78, 0.1  , -0.79, 0.12 , -0.9, 0.12 );
    line(0, 0, 0, -0.84, 0.12, -0.84, 0.1  , 2);

    //flag
    line(0, 0.3, 0.2, -0.68, 0.08  , -0.68, 0.19  , 3);
    triangle(1, 1, 1, -0.71, 0.18  , -0.68, 0.17  ,  -0.68, 0.19 );

    //waves
    line(1, 1, 1,  -0.72, 0.02 , -0.74, 0.01  ,  3);
    line(1, 1, 1, -0.74, 0.01  ,  -0.8, 0.01 ,  3);
    line(1, 1, 1, -0.88, 0.02  , -0.9, 0.03  ,  3);
    line(1, 1, 1, -0.9, 0.03  , -0.95, 0.03  ,  3);
    line(1, 1, 1, -0.88, 0.02  , -0.94, 0.02  ,  3);
    line(1, 1, 1, -0.88, 0.02  , -0.9, 0.01  ,  3);
    line(1, 1, 1,  -0.9, 0.01 ,  -0.95, 0.01 ,  3);


    glPopMatrix();


}







void boat2() //boat2
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-Pos_Boat2, 0.03f, 0.0f); //Transition Animation


    //body
    quads(0.855, 0.878, 0.89, 0.26, 0.28, 0.34, 0.22, 0.5, 0.22, 0.54, 0.28  );
    quads(0.522, 0.545, 0.659, 0.38, 0.28, 0.52, 0.28 , 0.53, 0.34  , 0.42, 0.34);

    //window
    quads(0.459, 0.914, 0.918,   0.4, 0.3, 0.517, 0.3 , 0.52, 0.32 , 0.415, 0.32 );
    line(0, 0, 0, 0.46, 0.32 ,0.46, 0.3  , 2);

    //flag
    line(0, 0.3, 0.2, 0.3, 0.28 , 0.3, 0.39  , 3);
    triangle(1, 1, 1, 0.3, 0.37, 0.33, 0.38, 0.3, 0.39 );

    //waves
    line(1, 1, 1, 0.34, 0.22 , 0.36, 0.21 ,  3);
    line(1, 1, 1, 0.36, 0.21 , 0.42, 0.21 ,  3);
    line(1, 1, 1, 0.5, 0.22 , 0.52, 0.23 ,  3);
    line(1, 1, 1, 0.52, 0.23 , 0.57, 0.23 ,  3);
    line(1, 1, 1, 0.5, 0.22 , 0.56, 0.22 ,  3);
    line(1, 1, 1, 0.5, 0.22 , 0.52, 0.21 ,  3);
    line(1, 1, 1, 0.52, 0.21 , 0.57, 0.21 ,  3);

    glPopMatrix();

}












void buildingBack() // buildingBack
{
    quadsgrad(0.573, 0.961, 0.518 , -1, -0.4   ,  1, -0.4  , 1, 0   ,  -1, 0 , 0.757, 0.949, 0.729 );
}




void building7() // layer1 1st cream color
{
    //building 7
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.2f, 1.0f);
    glTranslatef(0.115f, 0.217f, 0.0f);

    //body
    quads(0.914, 0.82, 0.718, -0.48, -0.16, -0.48, -0.4,-0.36, -0.4, -0.36, -0.16);

    //window
    line(0.329, 0.694, 0.871, -0.46, -0.18,  -0.43, -0.18  , 10);
    line(0.329, 0.694, 0.871, -0.41, -0.18,  -0.38, -0.18  , 10);

    line(0.329, 0.694, 0.871, -0.46, -0.2,  -0.43, -0.2  , 10);
    line(0.329, 0.694, 0.871, -0.41, -0.2,  -0.38, -0.2  , 10);




    glPopMatrix();

}





void building1() //Most left
{


    // 1st building
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.0f, 1.0f);
    glTranslatef(0.5f, 0.2f, 0.0f);



    //main structure
    quads(0.871, 0.847, 0.847, -1, -0.16,-1, -0.4,-0.97, -0.4,-0.97, -0.16);

    //windows
    line(0.2, 0.588, 0.929, -0.99, -0.18, -0.97, -0.18,  8);
    line(0.2, 0.588, 0.929, -0.99, -0.2, -0.97,  -0.2,   8);
    line(0.2, 0.588, 0.929, -0.99, -0.22, -0.97, -0.22 , 8);

    line(0.141, 0.412, 0.651, -0.99, -0.24, -0.97, -0.24,  8);
    line(0.141, 0.412, 0.651, -0.99, -0.26, -0.97, -0.26,  8);
    line(0.141, 0.412, 0.651, -0.99, -0.28, -0.97, -0.28,  8);

    line(0.086, 0.263, 0.42, -0.99, -0.3,  -0.97, -0.3,   8);
    line(0.086, 0.263, 0.42, -0.99, -0.32, -0.97, -0.32,  8);
    line(0.086, 0.263, 0.42, -0.99, -0.34, -0.97, -0.34,  8);
    line(0.086, 0.263, 0.42, -0.99, -0.36, -0.97, -0.36,  8);
    line(0.086, 0.263, 0.42, -0.99, -0.38, -0.97, -0.38,  8);

    glPopMatrix();

}





void building2() //left of cream building
{

    // 2nd building

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.1f, 1.0f);
    glTranslatef(0.5f, 0.21f, 0.0f);

    //main structure
    quads(0.965, 0.969, 0.988,  -0.97, -0.16,-0.97, -0.4,-0.86, -0.4,-0.86, -0.16);

    //windows
    glTranslatef(0.0f, -0.01f, 0.0f);

    quads(0.475, 0.718, 0.929,  -0.96, -0.17,  -0.96, -0.19,  -0.92, -0.19, -0.92, -0.17);
    quads(0.475, 0.718, 0.929,  -0.91, -0.17,  -0.91, -0.19,  -0.87, -0.19, -0.87, -0.17);

    quads(0.376, 0.58, 0.761,  -0.96, -0.21,  -0.96, -0.23,  -0.92, -0.23, -0.92, -0.21);
    quads(0.376, 0.58, 0.761,  -0.91, -0.21,  -0.91, -0.23,  -0.87, -0.23, -0.87, -0.21);

    quads(0.282, 0.431, 0.561,  -0.96, -0.25,  -0.96, -0.27,  -0.92, -0.27, -0.92, -0.25);
    quads(0.282, 0.431, 0.561,  -0.91, -0.25,  -0.91, -0.27,  -0.87, -0.27, -0.87, -0.25);

    quads(0.184, 0.29, 0.38,  -0.96, -0.29,  -0.96, -0.31,  -0.92, -0.31, -0.92, -0.29);
    quads(0.184, 0.29, 0.38,  -0.91, -0.29,  -0.91, -0.31,  -0.87, -0.31, -0.87, -0.29);

    quads(0.078, 0.122, 0.161,  -0.96, -0.33,  -0.96, -0.35,  -0.92, -0.35, -0.92, -0.33);
    quads(0.078, 0.122, 0.161,  -0.91, -0.33,  -0.91, -0.35,  -0.87, -0.35, -0.87, -0.33);

    glPopMatrix();

}





void building3() // in front of cream building
{
    // 3rd building
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.2f, 1.0f);
    glTranslatef(0.5f, 0.21f, 0.0f);


    //main structure
    quads(0.804, 0.831, 0.878,  -0.85, -0.19,-0.85, -0.4,-0.76, -0.4,-0.76, -0.19);


    //windows
    quads(0.663, 0.875, 1,  -0.84,   -0.2, -0.84, -0.21,-0.81, -0.21,-0.81, -0.2);
    quads(0.663, 0.875, 1,  -0.8 ,   -0.2, -0.8, -0.21,-0.77, -0.21,-0.77, -0.2);
    quads(0.663, 0.875, 1,  -0.84,   -0.22, -0.84, -0.23,-0.81, -0.23,-0.81, -0.22);
    quads(0.663, 0.875, 1,  -0.8 ,   -0.22, -0.8, -0.23,-0.77, -0.23,-0.77, -0.22);

    quads(0.463, 0.624, 0.722,  -0.84,   -0.24,-0.84, -0.25,-0.81, -0.25,-0.81, -0.24);
    quads(0.463, 0.624, 0.722,  -0.8 ,   -0.24,-0.8, -0.25,-0.77, -0.25,-0.77, -0.24);
    quads(0.463, 0.624, 0.722,  -0.84,   -0.26,-0.84, -0.27,-0.81, -0.27,-0.81, -0.26);
    quads(0.463, 0.624, 0.722,  -0.8 ,   -0.26,-0.8, -0.27,-0.77, -0.27,-0.77, -0.26);

    quads(0.29, 0.396, 0.459,  -0.84,   -0.28,-0.84, -0.29,-0.81, -0.29,-0.81, -0.28);
    quads(0.29, 0.396, 0.459,  -0.8 ,   -0.28,-0.8, -0.29,-0.77, -0.29,-0.77, -0.28);
    quads(0.29, 0.396, 0.459,  -0.84,   -0.3,-0.84, -0.31,-0.81, -0.31,-0.81, -0.3);
    quads(0.29, 0.396, 0.459,  -0.8 ,   -0.3,-0.8, -0.31,-0.77, -0.31,-0.77, -0.3);

    quads(0.3, 0.4, 0.46,  -0.84,   -0.32,-0.84, -0.33,-0.81, -0.33,-0.81, -0.32);
    quads(0.3, 0.4, 0.46,  -0.8 ,   -0.32,-0.8, -0.33,-0.77, -0.33,-0.77, -0.32);

    quads(0.125, 0.173, 0.2,  -0.84,   -0.34,-0.84, -0.35,-0.81, -0.35,-0.81, -0.34);
    quads(0.125, 0.173, 0.2,  -0.8 ,   -0.34,-0.8, -0.35,-0.77, -0.35,-0.77, -0.34);
    quads(0.125, 0.173, 0.2,  -0.84,   -0.36,-0.84, -0.37,-0.81, -0.37,-0.81, -0.36);
    quads(0.125, 0.173, 0.2,  -0.8 ,   -0.36,-0.8, -0.37,-0.77, -0.37,-0.77, -0.36);

    glPopMatrix();

}





void building8() // layer1 dark color
{

    //building 8
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.2f, 1.0f);
    glTranslatef(0.21f, 0.22f, 0.0f);

    //main structure
    quads(0.239, 0.196, 0.169, -0.45, -0.02, -0.45, -0.4,-0.37, -0.4,-0.37, -0.02);


    //windows
    glTranslatef(0.0f, -0.01f, 0.0f);


    line(0.651, 0.8, 0.941,  -0.44,  -0.03, -0.42, -0.03, 8);
    line(0.651, 0.8, 0.941,  -0.4,  -0.03,  -0.38, -0.03, 8);
    line(0.651, 0.8, 0.941,  -0.44,  -0.06, -0.42, -0.06, 8);
    line(0.651, 0.8, 0.941,  -0.4,  -0.06,  -0.38, -0.06, 8);
    line(0.651, 0.8, 0.941,  -0.44,  -0.09, -0.42, -0.09, 8);
    line(0.651, 0.8, 0.941,  -0.4,  -0.09,  -0.38, -0.09, 8);

    line(0.243, 0.522, 0.78,  -0.44,  -0.12, -0.42, -0.12, 8);
    line(0.243, 0.522, 0.78,  -0.4,  -0.12,  -0.38, -0.12, 8);
    line(0.243, 0.522, 0.78,  -0.44,  -0.15, -0.42, -0.15, 8);
    line(0.243, 0.522, 0.78,  -0.4,  -0.15,  -0.38, -0.15, 8);
    line(0.243, 0.522, 0.78,  -0.44,  -0.18, -0.42, -0.18, 8);
    line(0.243, 0.522, 0.78,  -0.4,  -0.18,  -0.38, -0.18, 8);

    line(0.098, 0.318, 0.522,  -0.44, -0.21, -0.42, -0.21, 8);
    line(0.098, 0.318, 0.522,  -0.4,  -0.21,  -0.38, -0.21, 8);
    line(0.098, 0.318, 0.522,  -0.44, -0.24, -0.42, -0.24, 8);
    line(0.098, 0.318, 0.522,  -0.4,  -0.24,  -0.38, -0.24, 8);
    line(0.098, 0.318, 0.522,  -0.44, -0.27, -0.42, -0.27, 8);
    line(0.098, 0.318, 0.522,  -0.4,  -0.27,  -0.38, -0.27, 8);

    line(0.027, 0.153, 0.271,  -0.44, -0.3,  -0.42, -0.3,  8);
    line(0.027, 0.153, 0.271,  -0.4,  -0.3,   -0.38, -0.3,  8);
    line(0.027, 0.153, 0.271,  -0.44, -0.33, -0.42, -0.33, 8);
    line(0.027, 0.153, 0.271,  -0.4,  -0.33,  -0.38, -0.33, 8);
    line(0.027, 0.153, 0.271,  -0.44, -0.36, -0.42, -0.36, 8);
    line(0.027, 0.153, 0.271,  -0.4,  -0.36,  -0.38, -0.36, 8);

    glPopMatrix();


}





void building5() // in front of dark building
{
    // building 5
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.0f, 1.0f);
    glTranslatef(0.45f, 0.2f, 0.0f);



    //main structure
    quads(0.784, 0.855, 0.871, -0.7, -0.2,-0.7, -0.4,-0.6, -0.4,-0.6, -0.2);

    //windows
    glTranslatef(0.0f, -0.01f, 0.0f);

    line(0.176, 0.776, 0.91,  -0.69, -0.21,-0.66, -0.21,10);
    line(0.176, 0.776, 0.91,  -0.64, -0.21,-0.61, -0.21,10);
    line(0.176, 0.776, 0.91,  -0.69, -0.24,-0.66, -0.24,10);
    line(0.176, 0.776, 0.91,  -0.64, -0.24,-0.61, -0.24,10);

    line(0.129, 0.545, 0.639,  -0.69, -0.27,-0.66, -0.27,10);
    line(0.129, 0.545, 0.639,  -0.64, -0.27,-0.61, -0.27,10);
    line(0.129, 0.545, 0.639,  -0.69, -0.3,-0.66, -0.3,  10);
    line(0.129, 0.545, 0.639,  -0.64, -0.3,-0.61, -0.3,  10);

    line(0.067, 0.282, 0.329,  -0.69, -0.33,-0.66, -0.33,10);
    line(0.067, 0.282, 0.329,  -0.64, -0.33,-0.61, -0.33,10);
    line(0.067, 0.282, 0.329,  -0.69, -0.36,-0.66, -0.36,10);
    line(0.067, 0.282, 0.329,  -0.64, -0.36,-0.61, -0.36,10);

    glPopMatrix();

}







void building9() //behind layer2 cream
{
    //building 9
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.0f, 1.0f);
    glTranslatef(0.2f, 0.2f, 0.0f);


    //main structure
    quads(1, 0.655, 0.569,  -0.35, -0.02,-0.35, -0.4,-0.27, -0.4,-0.27, -0.02);

    //windows
    glTranslatef(0.0f, -0.01f, 0.0f);

    line(0.408, 0.494, 0.741,  -0.34, -0.04,-0.32, -0.04,  10);
    line(0.408, 0.494, 0.741,  -0.3, -0.04,-0.28, -0.04,   10);
    line(0.408, 0.494, 0.741,  -0.34, -0.08,-0.32, -0.08,  10);
    line(0.408, 0.494, 0.741,  -0.3, -0.08,-0.28, -0.08,   10);
    line(0.408, 0.494, 0.741,  -0.34, -0.12,-0.32, -0.12,  10);
    line(0.408, 0.494, 0.741,  -0.3, -0.12,-0.28, -0.12,   10);

    line(0.114, 0.247, 0.612,  -0.34, -0.16,-0.32, -0.16,  10);
    line(0.114, 0.247, 0.612,  -0.3, -0.16,-0.28, -0.16,   10);
    line(0.114, 0.247, 0.612,  -0.34, -0.2,-0.32, -0.2,    10);
    line(0.114, 0.247, 0.612,  -0.3, -0.2,-0.28, -0.2,     10);
    line(0.114, 0.247, 0.612,  -0.34, -0.24,-0.32, -0.24,  10);
    line(0.114, 0.247, 0.612,  -0.3, -0.24,-0.28, -0.24,   10);

    line(0.118, 0.161, 0.278,  -0.34, -0.28,-0.32, -0.28,  10);
    line(0.118, 0.161, 0.278,  -0.3, -0.28,-0.28, -0.28,   10);
    line(0.118, 0.161, 0.278,  -0.34, -0.32,-0.32, -0.32,  10);
    line(0.118, 0.161, 0.278,  -0.3, -0.32,-0.28, -0.32,   10);
    line(0.118, 0.161, 0.278,  -0.34, -0.36,-0.32, -0.36,  10);
    line(0.118, 0.161, 0.278,  -0.3, -0.36,-0.28, -0.36,   10);

    glPopMatrix();

}






void building10() //pink color
{
    //building 10
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(1.25f, 1.5f, 1.0f);
    glTranslatef(0.15f, 0.133f, 0.0f);


    //main structure
    quads(0.8, 0.373, 0.396, -0.25, 0.03,-0.25, -0.4,-0.1, -0.4,-0.1, 0.03);

    //windows
    glTranslatef(0.001f, -0.01f, 0.0f);

    line(0.612, 0.796, 0.949,  -0.24, 0,-0.2, 0,10);
    line(0.612, 0.796, 0.949,  -0.16, 0,-0.12, 0,10);
    line(0.612, 0.796, 0.949,  -0.24, -0.08,-0.2, -0.08,10);
    line(0.612, 0.796, 0.949,  -0.16, -0.08,-0.12, -0.08,10);

    line(0.086, 0.439, 0.729,  -0.24, -0.16,-0.2, -0.16,10);
    line(0.086, 0.439, 0.729,  -0.16, -0.16,-0.12, -0.16,10);
    line(0.086, 0.439, 0.729,  -0.24, -0.24,-0.2, -0.24,10);
    line(0.086, 0.439, 0.729,  -0.16, -0.24,-0.12, -0.24,10);
    line(0.086, 0.439, 0.729,  -0.24, -0.32,-0.2, -0.32,10);
    line(0.086, 0.439, 0.729,  -0.16, -0.32,-0.12, -0.32,10);

    glPopMatrix();


}










void building6() //layer2 cream color
{
    //building 6
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.0f, 1.0f);
    glTranslatef(0.45f, 0.2f, 0.0f);


    //main structure

    quads(0.882, 0.78, 0.698, -0.59, -0.15,-0.59, -0.4,-0.5, -0.4, -0.5, -0.15);

    //windows
    glTranslatef(0.0f, -0.01f, 0.0f);

    line(0.498, 0.58, 0.949,  -0.58, -0.16, -0.55, -0.16, 10);
    line(0.498, 0.58, 0.949,  -0.54, -0.16, -0.51, -0.16, 10);
    line(0.498, 0.58, 0.949,  -0.58, -0.19, -0.55, -0.19, 10);
    line(0.498, 0.58, 0.949,  -0.54, -0.19, -0.51, -0.19, 10);

    line(0.329, 0.416, 0.788,  -0.58, -0.22, -0.55, -0.22, 10);
    line(0.329, 0.416, 0.788,  -0.54, -0.22, -0.51, -0.22, 10);
    line(0.329, 0.416, 0.788,  -0.58, -0.25, -0.55, -0.25, 10);
    line(0.329, 0.416, 0.788,  -0.54, -0.25, -0.51, -0.25, 10);

    line(0.09, 0.184, 0.588,  -0.58, -0.28, -0.55, -0.28, 10);
    line(0.09, 0.184, 0.588,  -0.54, -0.28, -0.51, -0.28, 10);
    line(0.09, 0.184, 0.588,  -0.58, -0.31, -0.55, -0.31, 10);
    line(0.09, 0.184, 0.588,  -0.54, -0.31, -0.51, -0.31, 10);

    line(0.004, 0.071, 0.369,  -0.58, -0.34, -0.55, -0.34, 10);
    line(0.004, 0.071, 0.369,  -0.54, -0.34, -0.51, -0.34, 10);
    line(0.004, 0.071, 0.369,  -0.58, -0.37, -0.55, -0.37, 10);
    line(0.004, 0.071, 0.369,  -0.54, -0.37, -0.51, -0.37, 10);

    glPopMatrix();


}










void building11() //white color
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 1.8f, 1.0f);
    glTranslatef(-0.05f, 0.177f, 0.0f);

    //main structure
    quads(0.969, 0.961, 0.953,  0.09, -0.06,0.09, -0.4,0.2, -0.4,0.2, -0.06);

    //window
    line(0.475, 0.725, 0.824,  0.11, -0.1,  0.18, -0.1,   10);
    line(0.475, 0.725, 0.824,  0.11, -0.14, 0.18, -0.14,  10);

    line(0.2, 0.2, 0.9,  0.11, -0.18, 0.18, -0.18,  10);
    line(0.2, 0.2, 0.9,  0.11, -0.22, 0.18, -0.22,  10);

    line(0.2, 0.2, 0.3,  0.11, -0.26, 0.18, -0.26,  10);
    line(0.2, 0.2, 0.3,  0.11, -0.3,  0.18, -0.3,   10);
    line(0.2, 0.2, 0.3,  0.11, -0.34, 0.18, -0.34,  10);

    glPopMatrix();
}


////////////////////////////////////////////////////////////////





void building12() //red color
{


    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.5f, 1.0f);
    glTranslatef(-0.22f, 0.24f, 0.0f);

    //main structure
    quads(0.62, 0.196, 0,  0.21, -0.22,0.21, -0.4,0.31, -0.4,0.31, -0.22);

    //window
    line(0.471, 0.937, 0.941, 0.23, -0.24, 0.29, -0.24, 10);
    line(0.388, 0.69, 0.69, 0.23, -0.28, 0.29, -0.28, 10);
    line(0.141, 0.439, 0.439, 0.23, -0.32, 0.29, -0.32, 10);
    line(0.11, 0.231, 0.231, 0.23, -0.36, 0.29, -0.36, 10);

    glPopMatrix();

}









void building16() // big right cream building
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(3.0f, 2.2f, 1.0f);
    glTranslatef(-0.56f, 0.217f, 0.0f);




    //body
    quads(0.886, 0.82, 0.718, 0.74, -0.14,0.74, -0.4,0.88, -0.4,0.88, -0.14);

    //windows
    glTranslatef(0.0f, -0.01f, 0.0f);

    quads(0.004, 0.678, 0.969, 0.76, -0.16, 0.8, -0.16,  0.8, -0.18, 0.76, -0.18 );
    quads(0.004, 0.678, 0.969, 0.82, -0.16, 0.86, -0.16, 0.86, -0.18, 0.82, -0.18);

    quads(0.216, 0.514, 0.639, 0.76, -0.24,0.8, -0.24, 0.8, -0.26, 0.76, -0.26 );
    quads(0.216, 0.514, 0.639, 0.82, -0.24,0.86, -0.24, 0.86, -0.26, 0.82, -0.26);

    quads(0.173, 0.247, 0.278, 0.76, -0.32,0.8, -0.32,  0.8, -0.34, 0.76, -0.34);
    quads(0.173, 0.247, 0.278, 0.82, -0.32,0.86, -0.32, 0.86, -0.34, 0.82, -0.34);

    glPopMatrix();

}







void building15() //dark drown
{


    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.2f, 1.0f);
    glTranslatef(-0.22f, 0.218f, 0.0f);

    //body
    quads(0.451, 0.365, 0.329, 0.37, -0.2,0.37, -0.4,0.5, -0.4,0.5, -0.2);


    //windows
    glTranslatef(0.005f, 0.0f, 0.0f);

    line(0.529, 0.878, 0.788,  0.38, -0.22,0.42, -0.22, 8);
    line(0.529, 0.878, 0.788,  0.44, -0.22,0.48, -0.22, 8);
    line(0.529, 0.878, 0.788,  0.38, -0.26,0.42, -0.26, 8);
    line(0.529, 0.878, 0.788,  0.44, -0.26,0.48, -0.26, 8);

    line(0.184, 0.631, 0.51,  0.38, -0.3,0.42, -0.3,   8);
    line(0.184, 0.631, 0.51,  0.44, -0.3,0.48, -0.3,   8);
    line(0.184, 0.631, 0.51,  0.38, -0.34,0.42, -0.34, 8);
    line(0.184, 0.631, 0.51,  0.44, -0.34,0.48, -0.34, 8);

    line(0.047, 0.369, 0.282,  0.38, -0.38,0.42, -0.38, 8);
    line(0.047, 0.369, 0.282,  0.44, -0.38,0.48, -0.38, 8);

    glPopMatrix();

}







void building17() //most right
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.8f, 1.0f);
    glTranslatef(-0.48f, 0.257f, 0.0f);

    //body
    quads(0.827, 0.851, 0.784, 0.92, -0.26,0.92, -0.4,1, -0.4,1, -0.26);

    //window
    line(0.075, 0.949, 0.863,  0.94, -0.28,0.98, -0.28,10);
    line(0.09, 0.71, 0.647,  0.94, -0.32,0.98, -0.32,10);
    line(0.122, 0.569, 0.525,  0.94, -0.36,0.98, -0.36,10);

    glPopMatrix();
}








void MorningRoad ()
{
    //Main road
    quads(0.388, 0.42, 0.455, -1, -0.8, 1, -0.8, 1, -0.4, -1, -0.4 );

    //side lines
    line(1, 1, 1, -1, -0.42,  1, -0.42 , 3);
    line(1, 1, 1, -1, -0.78,  1, -0.78 , 3);


    //middle lines
    line(1, 1, 1, -1, -0.595,  1, -0.595 , 2);
    line(1, 1, 1, -1, -0.605,  1, -0.605 , 2);


}





//----------- Cars Left to Right --------------------//


void MorningCar1() //blue car
{

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

   // glScalef(1.2, 1.2, 1.0);
    glTranslatef(-Pos_Car1, 0.05f, 0.0f);


    //body
    quads  (0.286, 0.294, 0.557,    -0.86, -0.44,-0.94, -0.52,-0.64, -0.52,-0.66, -0.44); //upper
    polygon(0.286, 0.294, 0.557,  -0.94, -0.52, -0.98, -0.53,-0.98, -0.56,-0.64, -0.56, -0.64, -0.52);  //lower


    //wheel
    circle(0, 0, 0,  0.03,  -0.9, -0.56);//wheel
    circle(0, 0, 0,  0.03,  -0.7, -0.56);//wheel

    circle(0.451, 0.478, 0.475,  0.02,  -0.9, -0.56);//wheel rim
    circle(0.451, 0.478, 0.475,  0.02,  -0.7, -0.56);//wheel rim

    //light
    quads(0.8, 0.467, 0.047, -0.98, -0.53,-0.98, -0.54,-0.94, -0.54,-0.94, -0.53);
    quads(0.8, 0.467, 0.047, -0.64, -0.53, -0.65, -0.54, -0.64, -0.54,-0.64, -0.54);


    //window
    quads(0.027, 0.678, 0.769, -0.85, -0.45,-0.89, -0.5,-0.77, -0.5,-0.77, -0.45);
    quads(0.027, 0.678, 0.769, -0.76, -0.45,-0.76, -0.5,-0.67, -0.5,-0.67, -0.45);

    glPopMatrix();


}





void MorningCar2() //white cybertruck
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //glScalef(0.9, 0.9, 1.0);
    glTranslatef(-Pos_Car2, 0.05f, 0.0f);






    //body
    polygon(0.592, 0.604, 0.631,   0.39, -0.57, 0.9, -0.57,  0.91, -0.47,  0.41, -0.5,   0.38,  -0.52); //main body
    triangle(0.91, 0.91, 0.933, 0.61, -0.43,0.41, -0.5,0.91, -0.47);//upper body

    //window
    quads(0.286, 0.345, 0.502, 0.62, -0.44,0.55, -0.46,0.55, -0.47,0.62, -0.47);//window
    quads(0.286, 0.345, 0.502, 0.63, -0.44,0.63, -0.47,0.71, -0.46,0.71, -0.45);//window

    //lights
    line(1, 0, 0,  0.38, -0.52, 0.43, -0.505 , 9);
    line(1, 0, 0,  0.905, -0.5, 0.88, -0.5 , 9);

    //wheels
    circle(0,0,0,  0.037,  0.46, -0.56);
    circle(0,0,0,  0.037,  0.81, -0.56);

    circle(0.451, 0.478, 0.475,  0.023,  0.46, -0.56);
    circle(0.451, 0.478, 0.475,  0.023,  0.81, -0.56);

    glPopMatrix();

}







void MorningCar3() //orange car
{

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //glScalef(0.9, 0.9, 1.0);
    glTranslatef(-Pos_Car3, 0.05f, 0.0f);

    //body
    quads(0.882, 0.506, 0.059,   2.79, -0.39,2.68, -0.5,3.09, -0.5,3.06, -0.39);//upper body
    quads(0.882, 0.506, 0.059,  2.65, -0.5,2.65, -0.55,3.09, -0.55,3.09, -0.5);//lower body

    //windows
    quads(0.192, 0.239, 0.529,     2.8 ,  -0.41,2.74, -0.48,2.9, -0.48,2.9, -0.41);//window body
    quads(0.192, 0.239, 0.529,    2.92,  -0.41,2.92, -0.48,3.04, -0.48,3.04, -0.41);//window body

    //wheels
    circle(0, 0, 0,  0.03, 2.73, -0.55);//wheel
    circle(0, 0, 0,  0.03, 3.02, -0.55);//wheel

    circle(0.451, 0.478, 0.475,  0.02, 2.73, -0.55);//wheel rim
    circle(0.451, 0.478, 0.475,  0.02, 3.02, -0.55);//wheel rim

    //lights
    quads(1, 1, 0, 2.67, -0.51, 2.65, -0.51, 2.65, -0.52, 2.67, -0.52);//front light
    quads(1,0, 0 , 3.09, -0.5, 3.07, -0.5, 3.07, -0.52, 3.09, -0.52);//back light

    glPopMatrix();

}






void MorningCar4() //Yellow Truck
{

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(0.9, 0.9, 1.0);
    glTranslatef(-Pos_Car4 - 0.2, 0.0f, 0.0f);

    //body
    quads(1 ,0.9,0.1,  5, -0.2,5, -0.5,5.64, -0.5,5.64, -0.2);//back upper body
    quads(0.714, 0.761, 0.753,  4.98, -0.5,4.98, -0.54,5.64, -0.54,5.64, -0.5);//rim
    polygon(0.9,0.8,0.2,  4.68, -0.54,4.98, -0.54,4.98, -0.24,4.86, -0.24,4.68, -0.42);//front body

    //window
    quads(0.196, 0.788, 0.702,   4.86, -0.28,4.75, -0.4,4.96, -0.4,4.96, -0.28);//window


    // wheel
    circle(0,0,0,  0.045, 4.8, -0.54);
    circle(0,0,0,  0.045, 5.3, -0.54);
    circle(0,0,0,  0.045, 5.42, -0.54);

    circle(0.451, 0.478, 0.475,  0.03, 4.8, -0.54);
    circle(0.451, 0.478, 0.475,  0.03, 5.3, -0.54);
    circle(0.451, 0.478, 0.475,  0.03, 5.42, -0.54);

    //lights
    quads(1,0,0,  4.71, -0.44,4.68, -0.44,4.68, -0.46,4.71, -0.46);//front light
    quads(1,0,0,  5.64, -0.46,  5.62,-0.46, 5.62, -0.49,  5.64, -0.49);//back light


    glPopMatrix();

}





//----------- Cars Right to Left --------------------//


void MorningCar5() //violet car
{

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(1.4, 1.4, 1.0);
    glTranslatef(Pos_Car5, 0.25f, 0.0f);


    //body
    quads(0.325, 0.157, 0.529,  0.06, -0.64, 0.04, -0.72,  0.3,  -0.72,    0.23, -0.64);//upper part
    quads(0.325, 0.157, 0.529,  0.04, -0.72, 0.04, -0.76,  0.32, -0.76,  0.32, -0.72);//lower part

    //windows
    quads(0.682, 0.91, 0.922,  0.07, -0.66, 0.06, -0.71,0.15, -0.71, 0.15, -0.66);//window part
    quads(0.682, 0.91, 0.922,  0.16, -0.66, 0.16, -0.71,0.27, -0.71, 0.23, -0.66);//window part

    // wheel
    circle(0, 0, 0, 0.025,0.1, -0.76);
    circle(0, 0, 0, 0.025,0.24, -0.76);

    circle(0.451, 0.478, 0.475, 0.015, 0.1, -0.76);
    circle(0.451, 0.478, 0.475, 0.015, 0.24, -0.76);

    // lights
    quads(1,0,0,0.06,   -0.73,0.04, -0.73,0.04, -0.75,0.05, -0.75);//back
    quads(1,0,0,0.32,   -0.73,0.3, -0.73,0.31, -0.75,0.32, -0.75);//front

    glPopMatrix();


}





void MorningCar6()  // red car
{

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(1.2, 1.2, 1.0);
    glTranslatef(Pos_Car6, 0.17f, 0.0f);

    //body
    quads(0.82, 0.184, 0.208,   -0.79, -0.63,-0.82, -0.72,-0.5, -0.72,-0.58, -0.63);//upper part
    quads(0.82, 0.184, 0.208, -0.82, -0.72,-0.82, -0.76,-0.47, -0.76,-0.47, -0.72);//lower part

    //windows
    quads(0.224, 0.376, 0.588, -0.78, -0.65,-0.78, -0.7,-0.69, -0.7,-0.69, -0.65);//window part
    quads(0.224, 0.376, 0.588, -0.67, -0.65,-0.67, -0.7,-0.55, -0.7,-0.6, -0.65);//window part

    //wheel
    circle(0, 0, 0, 0.03, -0.76, -0.76);
    circle(0, 0, 0, 0.03, -0.54, -0.76);

    circle(0.451, 0.478, 0.475, 0.02, -0.76, -0.76);
    circle(0.451, 0.478, 0.475, 0.02, -0.54, -0.76);

    // lights
    quads(0.969, 0.839, 0.443, -0.81, -0.73,-0.82, -0.73,-0.82, -0.75,-0.81, -0.75);// back light
    quads(0.969, 0.839, 0.443, -0.47, -0.73,-0.48, -0.73,-0.48, -0.75,-0.47, -0.75);//front light

    glPopMatrix();

}





void MorningCar7()//cargo van
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(1.4, 1.4, 1.0);
    glTranslatef(Pos_Car7 - 0.4 , 0.26f, 0.0f);


    //body
    quads  (0.737, 0.812, 0.663,      -1.74, -0.56,-1.74, -0.76,-1.5, -0.76,-1.5, -0.56);// cargo

    polygon(0.361, 0.541, 0.184,  -1.5, -0.6,-1.5, -0.76,-1.38, -0.76,-1.38, -0.68,-1.42, -0.6);//front
    quads  (0.361, 0.541, 0.184,    -1.38, -0.68,-1.38, -0.76,-1.34, -0.76,-1.34, -0.7);//front

    quads(0.612, 0.596, 0.565,  -1.75, -0.74,-1.75, -0.76,-1.7, -0.76,-1.7, -0.74);//back rim
    quads(0.612, 0.596, 0.565,  -1.33, -0.74,-1.38, -0.74,-1.38, -0.76,-1.33, -0.76);//front rim


    //wheel
    circle(0,0,0,  0.03, -1.64, -0.75);//wheel
    circle(0,0,0,  0.03, -1.45, -0.75);//wheel

    circle(0.451, 0.478, 0.475,  0.02, -1.64, -0.75);//wheel rim
    circle(0.451, 0.478, 0.475,  0.02, -1.45, -0.75);//wheel rim



    //window
    quads(0.184, 0.51, 0.922,  -1.48, -0.62,-1.48, -0.68,-1.38, -0.68,-1.41, -0.62);//window

    //light
    quads(0.949, 0.761, 0.337, -1.36, -0.7,-1.36, -0.72,-1.34, -0.72,-1.34, -0.7);//front light up

    glPopMatrix();


}





void MorningCar8() //lower cybertruck
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_Car8 -0.4, 0.05f, 0.0f);


    //body
    triangle(0.086, 0.102, 0.122,  -2.82, -0.6,-3.18, -0.65,-2.58, -0.68);//upper body
    polygon (0.271, 0.306, 0.349,   -3.18, -0.65,-3.17, -0.74,-2.57, -0.76,-2.56, -0.69,-2.58, -0.68); //lower body


    //window
    quads(0.518, 0.859, 0.961,  -2.85, -0.61,-2.94, -0.63,-2.94, -0.64,-2.85, -0.65);
    quads(0.518, 0.859, 0.961,  -2.83, -0.61,-2.83, -0.65,-2.74, -0.66,-2.75, -0.64);


    //lights
    line (0.929, 0.745, 0.314, -2.56, -0.7, -2.59, -0.69 , 6);
    quads(0.929, 0.745, 0.314, -3.17, -0.72,  -3.17, -0.74,  -3.12, -0.74,  -3.12, -0.72);


    // wheels
    circle(0, 0, 0,  0.04,-3.05, -0.75);
    circle(0, 0, 0,  0.04,-2.65, -0.75);

    circle(0.451, 0.478, 0.475,  0.025, -3.05, -0.75); // wheel rim
    circle(0.451, 0.478, 0.475,  0.025, -2.65, -0.75); // wheel rim

    glPopMatrix();



}




void MorningRoadside ()
{
    quads(0.4, 0.7, 0.04, -1, -1,  1, -1,  1, -0.8,  -1, -0.8 );

}



void MorningRoadsideGrass ()
{
   // 1
    circle(0.298, 0.549, 0.275,   0.11  ,  -1.02, -0.98);


    //2
    circle(0, 0.3, 0,   0.1  ,  -0.8, -1);

    //3
    circle(0.298, 0.6, 0.275, 0.06  ,  -0.9, -1);

    //4
    circle(0.471, 0.612, 0.149 ,   0.02  ,  -0.68, -0.97 );
    circle(0.471, 0.612, 0.149 ,   0.03  ,  -0.7, -1);
    circle(0.471, 0.612, 0.149 ,   0.03  ,  -0.65, -1);


    //5
    polygon(0.047, 0.6, 0,   -0.62, -1 , -0.45, -1 ,  -0.4, -0.9  , -0.5, -0.95  , -0.5, -0.9);


   //-----------------------------------------------------------------------

   //Grass layer1
    polygon(0.671, 0.89, 0.38,    0.3, -1 , 0.5, -1 , 0.53, -0.87 , 0.45, -0.99 ,  0.46, -0.87);
    polygon(0.671, 0.89, 0.38,    0.5, -1 ,0.7, -1  , 0.73, -0.89 , 0.65, -0.94 ,0.64, -0.89  );
    polygon(0.671, 0.89, 0.38,    0.7, -1 , 0.9, -1 ,0.95, -0.9   ,0.86, -0.94  ,0.86, -0.87  );
    polygon(0.671, 0.89, 0.38,    0.9, -1 , 1, -1, 1.05, -0.9 , 0.98, -0.95 , 0.99, -0.89 );

    //Grass layer2
    polygon(0.05, 0.6, 0,    0.46, -1 , 0.58, -1 , 0.63, -0.91 , 0.55, -0.94 ,0.56, -0.87  );
    polygon(0.05, 0.6, 0,    0.66, -1 , 0.78, -1 , 0.82, -0.91 , 0.75, -0.97 ,0.75, -0.91  );



   //--------------------------------------------------------------------------

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.7, 0.0f, 0.0f);

    //Grass layer1
    polygon(0.671, 0.89, 0.38,    0.3, -1 , 0.5, -1 , 0.53, -0.87 , 0.45, -0.99 ,  0.46, -0.87);
    polygon(0.671, 0.89, 0.38,    0.5, -1 ,0.7, -1  , 0.73, -0.89 , 0.65, -0.94 ,0.64, -0.89  );
    polygon(0.671, 0.89, 0.38,    0.7, -1 , 0.9, -1 ,0.95, -0.9   ,0.86, -0.94  ,0.86, -0.87  );
    polygon(0.671, 0.89, 0.38,    0.9, -1 , 1, -1, 1.05, -0.9 , 0.98, -0.95 , 0.99, -0.89 );

    //Grass layer2
    polygon(0.047, 0.6, 0,    0.46, -1 , 0.58, -1 , 0.63, -0.91 , 0.55, -0.94 ,0.56, -0.87  );
    polygon(0.047, 0.6, 0,    0.66, -1 , 0.78, -1 , 0.82, -0.91 , 0.75, -0.97 ,0.75, -0.91  );


    glPopMatrix();




}


void kashful1()
{
    //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);




}



void kashful2 ()
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.1, 0.0f, 0.0f);


        //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);

    glPopMatrix();
}


void kashful3 ()
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.3, 0.0f, 0.0f);


        //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);

    glPopMatrix();
}


void kashful4 ()
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.4, 0.0f, 0.0f);


        //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);

    glPopMatrix();
}


void kashful5 ()
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.6, 0.0f, 0.0f);


        //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);

    glPopMatrix();
}

void kashful6 ()
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.7, 0.0f, 0.0f);


        //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);

    glPopMatrix();
}


void kashful7 ()
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.2, 0.0f, 0.0f);


        //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);

    glPopMatrix();
}


void kashful8 ()
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.3, 0.0f, 0.0f);


        //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);

    glPopMatrix();
}


void kashful9 ()
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.5, 0.0f, 0.0f);


        //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);

    glPopMatrix();
}


void kashful10 ()
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.6, 0.0f, 0.0f);


        //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);

    glPopMatrix();
}


void kashful11 ()
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.8, 0.0f, 0.0f);


        //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);

    glPopMatrix();
}


void kashful12 ()
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.9, 0.0f, 0.0f);


        //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);

    glPopMatrix();
}



void kashful13 () //far left
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.9, 0.0f, 0.0f);


        //stem
    line(0,0,0,   -0.15, -1,0.05, -0.8,     2);

    //brunche
    line(0,0,0,   -0.1, -0.95,-0.05, -0.95, 2);
    line(0,0,0,   -0.1, -0.95,-0.1, -0.9,   2);
    line(0,0,0,   -0.05, -0.9,0, -0.9,      2);
    line(0,0,0,   -0.05, -0.9,-0.05, -0.85, 2);
    line(0,0,0,   0, -0.85,0, -0.8,         2);
    line(0,0,0,   0, -0.85,0.05, -0.85,     2);

    //fluffs
    circle(1,1, 1,  .02,-0.1, -0.9);
    circle(1,1, 1,  .02,-0.05, -0.95);
    circle(1,1, 1,  .02,-0.05, -0.85);
    circle(1,1, 1,  .02,0, -0.9);
    circle(1,1, 1,  .02,0.05, -0.8);
    circle(1,1, 1,  .02,0, -0.8);
    circle(1,1, 1,  .02,0.05, -0.85);

    glPopMatrix();
}











void  DisplayAutumnMorning()  //#########################################################################################################################
{

    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    skyAutumnMorning();
    sun();

    //Clouds
    SuAuSpMorningCloud1();
    SuAuSpMorningCloud2();
    SuAuSpMorningCloud3();
    SuAuSpMorningCloud4();
    SuAuSpMorningCloud5();
    SuAuSpMorningCloud6();



    riverMorning();



    landMorning();



    SummerAutumnMorningHill2(); // in the back of hill 1 and 3
    SummerAutumnMorningHill1();
    SummerAutumnMorningHill3();

    SummerAutumnMorningHill4();
    SummerAutumnMorningHill6(); // behind hill 5
    SummerAutumnMorningHill5();

    SummerAutumnMorningHill8(); // behind hill 9
    SummerAutumnMorningHill7();

    SummerAutumnMorningHill11(); // behind hill 10
    SummerAutumnMorningHill10(); // behind hill 9


    SummerAutumnMorningHill9();









    SuAuMorningChrisTree1();
    SuAuMorningChrisTree2();
    SuAuMorningChrisTree3();
    SuAuMorningChrisTree4();

    cocoTree1();
    cocoTree2();
    cocoTree3();

    pineTree1();
    pineTree2();
    pineTree3();


    boat2();
    boat1();

    buildingBack();

    building7(); // behind building 1 and 2
    building1();
    building2();
    building3();



    building8(); // behind building 5
    building5();



    building9(); // behind building 6
    building10(); //behind building 6
    building6();

    building11();
    building12();



    building16(); //behind building 15 and 17
    building15();
    building17();





    //line( 0, 0, 0, -1, -0.4, 1, -0.4, 1 );

    MorningRoad();

    // car Right to Left
    MorningCar1();
    MorningCar2();
    MorningCar3();
    MorningCar4();




    // car Left to Right
     MorningCar5();
     MorningCar6();
     MorningCar7();
     MorningCar8();


     MorningRoadside();


     kashful1();
     kashful2();
     kashful3();
     kashful4();
     kashful5();
     kashful6();
     kashful7();
     kashful8();
     kashful9();
     kashful10();
     kashful11();
     kashful12();
     kashful13();


     MorningRoadsideGrass();





    glFlush();  // Render now

    glPopMatrix();

}



////**************************************************************************************************************************
////**************************************************************************************************************************
////**************************************************************************************************************************
////**************************************************************************************************************************







void skyAutumnNight()
{

    quadsgrad(0.282, 0.341, 0.361, -1, 0.4, 1, 0.4,  1, 1, -1, 1, 0.016, 0.4, 0.541);

}




void moonfull()
{

    circle(0.863, 0.914, 0.922, 0.07, -0.6, 0.85);
}





void riverNight()
{

    quadsgrad(0.004, 0.043, 0.718, -1, 0, 1, 0,  1, 0.4, -1, 0.4, 0, 0.063, 0.212);

}




void AutumnSpringNightCloud1()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_SuAuSpMorCloud1, 0.0f, 0.0f); // Translation Animation

    circle(0.839, 0.839, 0.827,0.04,-0.85, 0.8);
    circle(0.839, 0.839, 0.827,0.05,-0.8, 0.8);
    circle(0.839, 0.839, 0.827,0.04,-0.75, 0.8);

    glPopMatrix();

}





void AutumnSpringNightCloud2()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_SuAuSpMorCloud2, 0.0f, 0.0f); // Translation Animation

    circle(0.839, 0.839, 0.827,0.03,-0.55, 0.9);
    circle(0.839, 0.839, 0.827,0.05,-0.5, 0.9);
    circle(0.839, 0.839, 0.827,0.03,-0.45, 0.9);

    glPopMatrix();

}





void AutumnSpringNightCloud3()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_SuAuSpMorCloud3, 0.0f, 0.0f); // Translation Animation

    circle(0.839, 0.839, 0.827, 0.04,-0.25, 0.8);
    circle(0.839, 0.839, 0.827,0.05,-0.2, 0.8);
    circle(0.839, 0.839, 0.827, 0.04,-0.15, 0.8);

    glPopMatrix();

}




void AutumnSpringNightCloud4()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_SuAuSpMorCloud4, 0.0f, 0.0f); // Translation Animation

    circle(0.839, 0.839, 0.827, 0.04,0.05, 0.9);
    circle(0.839, 0.839, 0.827, 0.05,0.1, 0.9);
    circle(0.839, 0.839, 0.827, 0.04,0.15, 0.9);

    glPopMatrix();
}




void AutumnSpringNightCloud5()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_SuAuSpMorCloud5, 0.0f, 0.0f); // Translation Animation

    circle(0.839, 0.839, 0.827, 0.04,0.55, 0.8);
    circle(0.839, 0.839, 0.827, 0.05,0.6, 0.8);
    circle(0.839, 0.839, 0.827, 0.04,0.65, 0.8);

    glPopMatrix();

}




void AutumnSpringNightCloud6()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_SuAuSpMorCloud6, 0.0f, 0.0f); // Translation Animation

    circle(0.839, 0.839, 0.827, 0.04,0.85, 0.9);
    circle(0.839, 0.839, 0.827, 0.05,0.9, 0.9);
    circle(0.839, 0.839, 0.827, 0.04,0.95, 0.9);

    glPopMatrix();

}








void landNight()
{

    quads(   0.659, 0.369, 0.016,  -1, 0.35, -0.5, 0.38, -0.5, 0.4, -1, 0.4);
    quads(   0.659, 0.369, 0.016, -0.5, 0.38,0, 0.36,   0, 0.4, -0.5, 0.4);
    quads(   0.659, 0.369, 0.016,  0, 0.36, 0.4, 0.38, 0.4, 0.4, 0, 0.4);
    triangle(0.659, 0.369, 0.016, 0.4, 0.38,  0.65, 0.4,  0.4, 0.4  );
    quads(   0.659, 0.369, 0.016, 0.65, 0.4, 0.62, 0.4,  1, 0.38,  1, 0.4);


}








void SummerAutumnNightHill1()
{
    polygon (0.161, 0.561, 0.173,  -1, 0.48,-1,0.4,-.58,0.4,-.7,0.53,-0.92,0.52);
    triangle(0.161, 0.561, 0.173,  -0.92, 0.52,-0.68, 0.52,-0.83, 0.57);
}






void SummerAutumnNightHill2()
{
    quads   (0, 0.365, 0.086,   -0.8, 0.5,-0.49, 0.45,-0.62, 0.6,-0.72, 0.6);
    triangle(0, 0.365, 0.086,   -0.72, 0.6,-0.62, 0.6,-0.67, 0.65);
}





void SummerAutumnNightHill3()
{
    triangle(0.02, 0.239, 0.196,   -0.57, 0.54,-0.45, 0.54,-0.5, 0.57);
    polygon (0.02, 0.239, 0.196,   -0.67, 0.49, -0.58, 0.4,-0.25, 0.4,-0.45, 0.54,-0.57,0.54);
}







void SummerAutumnNightHill4()
{
    quads(0, 0.118, 0.149,  -0.28, 0.55,-0.4, 0.5,-0.25, 0.4,-0.19, 0.52);
}





void SummerAutumnNightHill5()
{
    quads(0.169, 0.561, 0.18,   -0.11, 0.52,-0.31, 0.44,-0.25, 0.4,0.12, 0.4);
}






void SummerAutumnNightHill6()
{
    quads(0.059, 0.341, 0.075,   0.09, 0.61,-0.19, 0.52,-0.25, 0.4,0.3, 0.4);
}





void SummerAutumnNightHill7()
{
    quads(0.098, 0.412, 0.306,  0.28, 0.69, 0.13, 0.57, 0.27, 0.43, 0.37, 0.53);
}






void SummerAutumnNightHill8()
{
    triangle(0, 0.075, 0,  0.39, 0.68, 0.28, 0.54, 0.5, 0.48);
}







void SummerAutumnNightHill9()
{
    quads(0.255, 0.549, 0.204,   0.52, 0.7, 0.27, 0.43, 0.3, 0.4, 0.61, 0.4);
}






void SummerAutumnNightHill10()
{
    polygon(0, 0.255, 0.004, 0.64, 0.67,  0.5, 0.5,  0.61, 0.4, 1, 0.4, 1, 0.46);
}



void SummerAutumnNightHill11()
{
    quads(0.004, 0.039, 0.098,  0.95, 0.64, 0.76, 0.59, 1, 0.46, 1, 0.6);

}








void NightchrisTree1()
{
    triangle(0.012, 0.71, 0.02,  -0.9, 0.5 , -0.82, 0.5, -0.86, 0.54);
    quads(0.02, 0.478, 0.027,  -0.9,  0.48, -0.82, 0.48, -0.84, 0.5, -0.88, 0.5);
    quads(0.004, 0.145, 0.004, -0.9, 0.46, -0.82, 0.46, -0.84, 0.48, -0.88, 0.48);

    quads(0.31, 0.094, 0.02, -0.87, 0.41, -0.85, 0.41,  -0.855, 0.46, -0.865, 0.46 );
    quads(0.31, 0.094, 0.02,  -0.88, 0.4, -0.84, 0.4,-0.85, 0.41 , -0.87, 0.41 );

}





void NightchrisTree2()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.77f, 0.0f, 0.0f);


    triangle(0.012, 0.71, 0.02,  -0.9, 0.5 , -0.82, 0.5, -0.86, 0.54);
    quads(0.02, 0.478, 0.027,  -0.9,  0.48, -0.82, 0.48, -0.84, 0.5, -0.88, 0.5);
    quads(0.004, 0.145, 0.004, -0.9, 0.46, -0.82, 0.46, -0.84, 0.48, -0.88, 0.48);

    quads(0.31, 0.094, 0.02, -0.87, 0.41, -0.85, 0.41,  -0.855, 0.46, -0.865, 0.46 );
    quads(0.31, 0.094, 0.02,  -0.88, 0.4, -0.84, 0.4,-0.85, 0.41 , -0.87, 0.41 );

    glPopMatrix();

}





void NightchrisTree3()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.4f, 0.0f, 0.0f);

   triangle(0.012, 0.71, 0.02,  -0.9, 0.5 , -0.82, 0.5, -0.86, 0.54);
    quads(0.02, 0.478, 0.027,  -0.9,  0.48, -0.82, 0.48, -0.84, 0.5, -0.88, 0.5);
    quads(0.004, 0.145, 0.004, -0.9, 0.46, -0.82, 0.46, -0.84, 0.48, -0.88, 0.48);

    quads(0.31, 0.094, 0.02, -0.87, 0.41, -0.85, 0.41,  -0.855, 0.46, -0.865, 0.46 );
    quads(0.31, 0.094, 0.02,  -0.88, 0.4, -0.84, 0.4,-0.85, 0.41 , -0.87, 0.41 );


    glPopMatrix();

}





void NightchrisTree4()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    triangle(0.012, 0.71, 0.02,  -0.9, 0.5 , -0.82, 0.5, -0.86, 0.54);
    quads(0.02, 0.478, 0.027,  -0.9,  0.48, -0.82, 0.48, -0.84, 0.5, -0.88, 0.5);
    quads(0.004, 0.145, 0.004, -0.9, 0.46, -0.82, 0.46, -0.84, 0.48, -0.88, 0.48);

    quads(0.31, 0.094, 0.02, -0.87, 0.41, -0.85, 0.41,  -0.855, 0.46, -0.865, 0.46 );
    quads(0.31, 0.094, 0.02,  -0.88, 0.4, -0.84, 0.4,-0.85, 0.41 , -0.87, 0.41 );


    glTranslatef(1.5f, 0.0f, 0.0f);



    glPopMatrix();

}








void NightcocoTree1()
{

    //leafs
     triangle(0.024, 0.459, 0.071, -0.74, 0.48 , -0.69, 0.5, -0.68, 0.52);
     quads(0.024, 0.459, 0.071, -0.69, 0.5, -0.67, 0.5, -0.62, 0.48, -0.68, 0.52);

     triangle(0.165, 0.31, 0.173, -0.76, 0.5,  -0.68, 0.52, -0.68, 0.54);
     triangle(0.165, 0.31, 0.173, -0.68, 0.52,  -0.6, 0.5,  -0.68, 0.54);


     triangle(0.024, 0.459, 0.071, -0.7, 0.53, -0.68, 0.54, -0.74, 0.56);
     triangle(0.024, 0.459, 0.071, -0.68, 0.54, -0.66, 0.53, -0.62, 0.56);

     //treelogs
     quads(0.424, 0.059, 0, -0.7, 0.4, -0.66, 0.4, -0.67, 0.5, -0.69, 0.5 );



}





void NightcocoTree2()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.8f, 0.0f, 0.0f);


    //leafs
     triangle(0.024, 0.459, 0.071, -0.74, 0.48 , -0.69, 0.5, -0.68, 0.52);
     quads(0.024, 0.459, 0.071, -0.69, 0.5, -0.67, 0.5, -0.62, 0.48, -0.68, 0.52);

     triangle(0.165, 0.31, 0.173, -0.76, 0.5,  -0.68, 0.52, -0.68, 0.54);
     triangle(0.165, 0.31, 0.173, -0.68, 0.52,  -0.6, 0.5,  -0.68, 0.54);


     triangle(0.024, 0.459, 0.071, -0.7, 0.53, -0.68, 0.54, -0.74, 0.56);
     triangle(0.024, 0.459, 0.071, -0.68, 0.54, -0.66, 0.53, -0.62, 0.56);

     //treelogs
     quads(0.424, 0.059, 0, -0.7, 0.4, -0.66, 0.4, -0.67, 0.5, -0.69, 0.5 );




     glPopMatrix();

}





void NightcocoTree3()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.6f, 0.0f, 0.0f);

    //leafs
     triangle(0.024, 0.459, 0.071, -0.74, 0.48 , -0.69, 0.5, -0.68, 0.52);
     quads(0.024, 0.459, 0.071, -0.69, 0.5, -0.67, 0.5, -0.62, 0.48, -0.68, 0.52);

     triangle(0.165, 0.31, 0.173, -0.76, 0.5,  -0.68, 0.52, -0.68, 0.54);
     triangle(0.165, 0.31, 0.173, -0.68, 0.52,  -0.6, 0.5,  -0.68, 0.54);


     triangle(0.024, 0.459, 0.071, -0.7, 0.53, -0.68, 0.54, -0.74, 0.56);
     triangle(0.024, 0.459, 0.071, -0.68, 0.54, -0.66, 0.53, -0.62, 0.56);

     //treelogs
     quads(0.424, 0.059, 0, -0.7, 0.4, -0.66, 0.4, -0.67, 0.5, -0.69, 0.5 );



     glPopMatrix();

}





void NightpineTree1()
{
    //leafs
    triangle (0.271, 0.561, 0.271, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   );

    //log
    quads(0.525, 0.271, 0.059, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  );

}






void NightpineTree2()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.12f, 0.0f, 0.0f);


    //leafs
    triangle (0.271, 0.561, 0.271, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   );

    //log
    quads(0.525, 0.271, 0.059, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  );



    glPopMatrix();

}






void NightpineTree3()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.6f, 0.0f, 0.0f);

    //leafs
    triangle (0.271, 0.561, 0.271, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   );

    //log
    quads(0.525, 0.271, 0.059, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  );



    glPopMatrix();


}









void Nightboat1()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_Boat1, 0.12f, 0.0f); //Transition Animation


    //body
    quads(0.49, 0.49, 0.475, -0.92, 0.08, -0.88, 0.02, -0.72, 0.02, -0.64, 0.08 );
    quads(0.788, 0.682, 0.678,  -0.9, 0.08 , -0.76, 0.08  , -0.8, 0.14  , -0.91, 0.14  );

    //window
    quads(0.824, 0.878, 0.008,  -0.897, 0.1  , -0.78, 0.1  , -0.79, 0.12 , -0.9, 0.12 );
    line(0, 0, 0, -0.84, 0.12, -0.84, 0.1  , 2);

    //flag
    line(0, 0.3, 0.2, -0.68, 0.08  , -0.68, 0.19  , 3);
    triangle(1, 1, 1, -0.71, 0.18  , -0.68, 0.17  ,  -0.68, 0.19 );

    //waves
    line(1, 1, 1,  -0.72, 0.02 , -0.74, 0.01  ,  3);
    line(1, 1, 1, -0.74, 0.01  ,  -0.8, 0.01 ,  3);
    line(1, 1, 1, -0.88, 0.02  , -0.9, 0.03  ,  3);
    line(1, 1, 1, -0.9, 0.03  , -0.95, 0.03  ,  3);
    line(1, 1, 1, -0.88, 0.02  , -0.94, 0.02  ,  3);
    line(1, 1, 1, -0.88, 0.02  , -0.9, 0.01  ,  3);
    line(1, 1, 1,  -0.9, 0.01 ,  -0.95, 0.01 ,  3);


    glPopMatrix();


}







void Nightboat2()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-Pos_Boat2, 0.03f, 0.0f); //Transition Animation


    //body
    quads(0.804, 0.855, 0.886, 0.26, 0.28, 0.34, 0.22, 0.5, 0.22, 0.54, 0.28  );
    quads(0.31, 0.361, 0.561, 0.38, 0.28, 0.52, 0.28 , 0.53, 0.34  , 0.42, 0.34);

    //window
    quads(0.824, 0.878, 0.008,   0.4, 0.3, 0.517, 0.3 , 0.52, 0.32 , 0.415, 0.32 );
    line(0, 0, 0, 0.46, 0.32 ,0.46, 0.3  , 2);

    //flag
    line(0, 0.3, 0.2, 0.3, 0.28 , 0.3, 0.39  , 3);
    triangle(1, 1, 1, 0.3, 0.37, 0.33, 0.38, 0.3, 0.39 );

    //waves
    line(1, 1, 1, 0.34, 0.22 , 0.36, 0.21 ,  3);
    line(1, 1, 1, 0.36, 0.21 , 0.42, 0.21 ,  3);
    line(1, 1, 1, 0.5, 0.22 , 0.52, 0.23 ,  3);
    line(1, 1, 1, 0.52, 0.23 , 0.57, 0.23 ,  3);
    line(1, 1, 1, 0.5, 0.22 , 0.56, 0.22 ,  3);
    line(1, 1, 1, 0.5, 0.22 , 0.52, 0.21 ,  3);
    line(1, 1, 1, 0.52, 0.21 , 0.57, 0.21 ,  3);

    glPopMatrix();

}






void buildingBack1()
{
    quadsgrad(0.573, 0.961, 0.518 , -1, -0.4   ,  1, -0.4  , 1, 0   ,  -1, 0 , 0.757, 0.949, 0.729 );
}




void buildingNight7() // layer1 1st cream color
{
    //building 7
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.2f, 1.0f);
    glTranslatef(0.115f, 0.217f, 0.0f);

    //body
    quads(0.894, 0.722, 0.549, -0.48, -0.16, -0.48, -0.4,-0.36, -0.4, -0.36, -0.16);

    //window
    line(0.929, 0.949, 0.004, -0.46, -0.18,  -0.43, -0.18  , 10);
    line(0.929, 0.949, 0.004, -0.41, -0.18,  -0.38, -0.18  , 10);
    line(0.929, 0.949, 0.004, -0.46, -0.2,  -0.43, -0.2  , 10);
    line(0.929, 0.949, 0.004, -0.41, -0.2,  -0.38, -0.2  , 10);




    glPopMatrix();

}





void buildingNight1() //Most left
{


    // 1st building
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.0f, 1.0f);
    glTranslatef(0.5f, 0.2f, 0.0f);



    //main structure
    quads(0.847, 0.788, 0.761, -1, -0.16,-1, -0.4,-0.97, -0.4,-0.97, -0.16);

    //windows
    line(0.929, 0.949, 0.004, -0.99, -0.18, -0.97, -0.18,  8);
    line(0.929, 0.949, 0.004, -0.99, -0.2, -0.97,  -0.2,   8);
    line(0.929, 0.949, 0.004, -0.99, -0.22, -0.97, -0.22 , 8);
    line(0.929, 0.949, 0.004, -0.99, -0.24, -0.97, -0.24,  8);
    line(0.929, 0.949, 0.004, -0.99, -0.26, -0.97, -0.26,  8);
    line(0.929, 0.949, 0.004, -0.99, -0.28, -0.97, -0.28,  8);
    line(0.929, 0.949, 0.004, -0.99, -0.3,  -0.97, -0.3,   8);
    line(0.929, 0.949, 0.004, -0.99, -0.32, -0.97, -0.32,  8);
    line(0.929, 0.949, 0.004, -0.99, -0.34, -0.97, -0.34,  8);
    line(0.929, 0.949, 0.004, -0.99, -0.36, -0.97, -0.36,  8);
    line(0.929, 0.949, 0.004, -0.99, -0.38, -0.97, -0.38,  8);

    glPopMatrix();

}





void buildingNight2() //left of cream building
{

    // 2nd building

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.1f, 1.0f);
    glTranslatef(0.5f, 0.21f, 0.0f);

    //main structure
    quads(0.91, 0.91, 0.91,  -0.97, -0.16,-0.97, -0.4,-0.86, -0.4,-0.86, -0.16);

    //windows
    glTranslatef(0.0f, -0.01f, 0.0f);

    quads(0.851, 0.663, 0.271,  -0.96, -0.17,  -0.96, -0.19,  -0.92, -0.19, -0.92, -0.17);
    quads(0.851, 0.663, 0.271,  -0.91, -0.17,  -0.91, -0.19,  -0.87, -0.19, -0.87, -0.17);
    quads(0.851, 0.663, 0.271,  -0.96, -0.21,  -0.96, -0.23,  -0.92, -0.23, -0.92, -0.21);
    quads(0.851, 0.663, 0.271,  -0.91, -0.21,  -0.91, -0.23,  -0.87, -0.23, -0.87, -0.21);
    quads(0.851, 0.663, 0.271,  -0.96, -0.25,  -0.96, -0.27,  -0.92, -0.27, -0.92, -0.25);
    quads(0.851, 0.663, 0.271,  -0.91, -0.25,  -0.91, -0.27,  -0.87, -0.27, -0.87, -0.25);
    quads(0.851, 0.663, 0.271,  -0.96, -0.29,  -0.96, -0.31,  -0.92, -0.31, -0.92, -0.29);
    quads(0.851, 0.663, 0.271,  -0.91, -0.29,  -0.91, -0.31,  -0.87, -0.31, -0.87, -0.29);
    quads(0.851, 0.663, 0.271,  -0.96, -0.33,  -0.96, -0.35,  -0.92, -0.35, -0.92, -0.33);
    quads(0.851, 0.663, 0.271,  -0.91, -0.33,  -0.91, -0.35,  -0.87, -0.35, -0.87, -0.33);

    glPopMatrix();



}





void buildingNight3() // in front of cream building
{
    // 3rd building
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.2f, 1.0f);
    glTranslatef(0.5f, 0.21f, 0.0f);


    //main structure
    quads(0.678, 0.718, 0.816,  -0.85, -0.19,-0.85, -0.4,-0.76, -0.4,-0.76, -0.19);


    //windows
    quads(0.941, 0.82, 0.545,  -0.84,   -0.2, -0.84, -0.21,-0.81, -0.21,-0.81, -0.2);
    quads(0.941, 0.82, 0.545,  -0.8 ,   -0.2, -0.8, -0.21,-0.77, -0.21,-0.77, -0.2);
    quads(0.941, 0.82, 0.545,  -0.84,   -0.22, -0.84, -0.23,-0.81, -0.23,-0.81, -0.22);
    quads(0.941, 0.82, 0.545,  -0.8 ,   -0.22, -0.8, -0.23,-0.77, -0.23,-0.77, -0.22);
    quads(0.941, 0.82, 0.545,  -0.84,   -0.24,-0.84, -0.25,-0.81, -0.25,-0.81, -0.24);
    quads(0.941, 0.82, 0.545,  -0.8 ,   -0.24,-0.8, -0.25,-0.77, -0.25,-0.77, -0.24);
    quads(0.941, 0.82, 0.545,  -0.84,   -0.26,-0.84, -0.27,-0.81, -0.27,-0.81, -0.26);
    quads(0.941, 0.82, 0.545,  -0.8 ,   -0.26,-0.8, -0.27,-0.77, -0.27,-0.77, -0.26);
    quads(0.941, 0.82, 0.545,  -0.84,   -0.28,-0.84, -0.29,-0.81, -0.29,-0.81, -0.28);
    quads(0.941, 0.82, 0.545,  -0.8 ,   -0.28,-0.8, -0.29,-0.77, -0.29,-0.77, -0.28);
    quads(0.941, 0.82, 0.545,  -0.84,   -0.3,-0.84, -0.31,-0.81, -0.31,-0.81, -0.3);
    quads(0.941, 0.82, 0.545,  -0.8 ,   -0.3,-0.8, -0.31,-0.77, -0.31,-0.77, -0.3);
    quads(0.941, 0.82, 0.545,  -0.84,   -0.32,-0.84, -0.33,-0.81, -0.33,-0.81, -0.32);
    quads(0.941, 0.82, 0.545,  -0.8 ,   -0.32,-0.8, -0.33,-0.77, -0.33,-0.77, -0.32);
    quads(0.941, 0.82, 0.545,  -0.84,   -0.34,-0.84, -0.35,-0.81, -0.35,-0.81, -0.34);
    quads(0.941, 0.82, 0.545,  -0.8 ,   -0.34,-0.8, -0.35,-0.77, -0.35,-0.77, -0.34);
    quads(0.941, 0.82, 0.545,  -0.84,   -0.36,-0.84, -0.37,-0.81, -0.37,-0.81, -0.36);
    quads(0.941, 0.82, 0.545,  -0.8 ,   -0.36,-0.8, -0.37,-0.77, -0.37,-0.77, -0.36);

    glPopMatrix();

}





void buildingNight8() // layer1 dark color
{

    //building 8
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.2f, 1.0f);
    glTranslatef(0.21f, 0.22f, 0.0f);

    //main structure
    quads(0.012, 0.031, 0.09, -0.45, -0.02, -0.45, -0.4,-0.37, -0.4,-0.37, -0.02);


    //windows
    glTranslatef(0.0f, -0.01f, 0.0f);


    line(0.055, 0.224, 0.49,  -0.44,  -0.03, -0.42, -0.03, 8);
    line(0.055, 0.224, 0.49,  -0.4,  -0.03,  -0.38, -0.03, 8);
    line(0.055, 0.224, 0.49,  -0.44,  -0.06, -0.42, -0.06, 8);
    line(0.055, 0.224, 0.49,  -0.4,  -0.06,  -0.38, -0.06, 8);
    line(0.055, 0.224, 0.49,  -0.44,  -0.09, -0.42, -0.09, 8);
    line(0.055, 0.224, 0.49,  -0.4,  -0.09,  -0.38, -0.09, 8);
    line(0.055, 0.224, 0.49,  -0.44,  -0.12, -0.42, -0.12, 8);
    line(0.055, 0.224, 0.49,  -0.4,  -0.12,  -0.38, -0.12, 8);
    line(0.055, 0.224, 0.49,  -0.44,  -0.15, -0.42, -0.15, 8);
    line(0.055, 0.224, 0.49,  -0.4,  -0.15,  -0.38, -0.15, 8);
    line(0.055, 0.224, 0.49,  -0.44,  -0.18, -0.42, -0.18, 8);
    line(0.055, 0.224, 0.49,  -0.4,  -0.18,  -0.38, -0.18, 8);
    line(0.055, 0.224, 0.49,  -0.44, -0.21, -0.42, -0.21, 8);
    line(0.055, 0.224, 0.49,  -0.4,  -0.21,  -0.38, -0.21, 8);
    line(0.055, 0.224, 0.49,  -0.44, -0.24, -0.42, -0.24, 8);
    line(0.055, 0.224, 0.49,  -0.4,  -0.24,  -0.38, -0.24, 8);
    line(0.055, 0.224, 0.49,  -0.44, -0.27, -0.42, -0.27, 8);
    line(0.055, 0.224, 0.49,  -0.4,  -0.27,  -0.38, -0.27, 8);
    line(0.055, 0.224, 0.49,  -0.44, -0.3,  -0.42, -0.3,  8);
    line(0.055, 0.224, 0.49,  -0.4,  -0.3,   -0.38, -0.3,  8);
    line(0.055, 0.224, 0.49,  -0.44, -0.33, -0.42, -0.33, 8);
    line(0.055, 0.224, 0.49,  -0.4,  -0.33,  -0.38, -0.33, 8);
    line(0.055, 0.224, 0.49,  -0.44, -0.36, -0.42, -0.36, 8);
    line(0.055, 0.224, 0.49,  -0.4,  -0.36,  -0.38, -0.36, 8);

    glPopMatrix();


}





void buildingNight5() // in front of dark building
{
    // building 5
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.0f, 1.0f);
    glTranslatef(0.45f, 0.2f, 0.0f);



    //main structure
    quads(0.639, 0.788, 0.808, -0.7, -0.2,-0.7, -0.4,-0.6, -0.4,-0.6, -0.2);

    //windows
    glTranslatef(0.0f, -0.01f, 0.0f);

    line(0.941, 0.82, 0.545,  -0.69, -0.21,-0.66, -0.21,10);
    line(0.941, 0.82, 0.545,  -0.64, -0.21,-0.61, -0.21,10);
    line(0.941, 0.82, 0.545,  -0.69, -0.24,-0.66, -0.24,10);
    line(0.941, 0.82, 0.545,  -0.64, -0.24,-0.61, -0.24,10);
    line(0.941, 0.82, 0.545,  -0.69, -0.27,-0.66, -0.27,10);
    line(0.941, 0.82, 0.545,  -0.64, -0.27,-0.61, -0.27,10);
    line(0.941, 0.82, 0.545,  -0.69, -0.3,-0.66, -0.3,  10);
    line(0.941, 0.82, 0.545,  -0.64, -0.3,-0.61, -0.3,  10);
    line(0.941, 0.82, 0.545,  -0.69, -0.33,-0.66, -0.33,10);
    line(0.941, 0.82, 0.545,  -0.64, -0.33,-0.61, -0.33,10);
    line(0.941, 0.82, 0.545,  -0.69, -0.36,-0.66, -0.36,10);
    line(0.941, 0.82, 0.545,  -0.64, -0.36,-0.61, -0.36,10);

    glPopMatrix();

}







void buildingNight9() //behind layer2 cream
{
    //building 9
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.0f, 1.0f);
    glTranslatef(0.2f, 0.2f, 0.0f);


    //main structure
    quads(1, 0.435, 0.314,  -0.35, -0.02,-0.35, -0.4,-0.27, -0.4,-0.27, -0.02);

    //windows
    glTranslatef(0.0f, -0.01f, 0.0f);

    line(0.9, 0.8, 0.1,  -0.34, -0.04,-0.32, -0.04,  10);
    line(0.9, 0.8, 0.1,  -0.3, -0.04,-0.28, -0.04,   10);
    line(0.9, 0.8, 0.1,  -0.34, -0.08,-0.32, -0.08,  10);
    line(0.9, 0.8, 0.1,  -0.3, -0.08,-0.28, -0.08,   10);
    line(0.9, 0.8, 0.1,  -0.34, -0.12,-0.32, -0.12,  10);
    line(0.9, 0.8, 0.1,  -0.3, -0.12,-0.28, -0.12,   10);
    line(0.9, 0.8, 0.1,  -0.34, -0.16,-0.32, -0.16,  10);
    line(0.9, 0.8, 0.1,  -0.3, -0.16,-0.28, -0.16,   10);
    line(0.9, 0.8, 0.1,  -0.34, -0.2,-0.32, -0.2,    10);
    line(0.9, 0.8, 0.1,  -0.3, -0.2,-0.28, -0.2,     10);
    line(0.9, 0.8, 0.1,  -0.34, -0.24,-0.32, -0.24,  10);
    line(0.9, 0.8, 0.1,  -0.3, -0.24,-0.28, -0.24,   10);
    line(0.9, 0.8, 0.1,  -0.34, -0.28,-0.32, -0.28,  10);
    line(0.9, 0.8, 0.1,  -0.3, -0.28,-0.28, -0.28,   10);
    line(0.9, 0.8, 0.1,  -0.34, -0.32,-0.32, -0.32,  10);
    line(0.9, 0.8, 0.1,  -0.3, -0.32,-0.28, -0.32,   10);
    line(0.9, 0.8, 0.1,  -0.34, -0.36,-0.32, -0.36,  10);
    line(0.9, 0.8, 0.1,  -0.3, -0.36,-0.28, -0.36,   10);

    glPopMatrix();

}






void buildingNight10() //pink color
{
    //building 10
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(1.25f, 1.5f, 1.0f);
    glTranslatef(0.15f, 0.133f, 0.0f);


    //main structure
    quads(0.639, 0.275, 0.294, -0.25, 0.03,-0.25, -0.4,-0.1, -0.4,-0.1, 0.03);

    //windows
    glTranslatef(0.001f, -0.01f, 0.0f);

    line(0.8, 0.8, 0.01,  -0.24, 0,-0.2, 0,10);
    line(0.8, 0.8, 0.01,  -0.16, 0,-0.12, 0,10);
    line(0.8, 0.8, 0.01,  -0.24, -0.08,-0.2, -0.08,10);
    line(0.8, 0.8, 0.01,  -0.16, -0.08,-0.12, -0.08,10);
    line(0.8, 0.8, 0.01,  -0.24, -0.16,-0.2, -0.16,10);
    line(0.8, 0.8, 0.01,  -0.16, -0.16,-0.12, -0.16,10);
    line(0.8, 0.8, 0.01,  -0.24, -0.24,-0.2, -0.24,10);
    line(0.8, 0.8, 0.01,  -0.16, -0.24,-0.12, -0.24,10);
    line(0.8, 0.8, 0.01,  -0.24, -0.32,-0.2, -0.32,10);
    line(0.8, 0.8, 0.01,  -0.16, -0.32,-0.12, -0.32,10);

    glPopMatrix();


}










void buildingNight6() //layer2 cream color
{
    //building 6
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.0f, 1.0f);
    glTranslatef(0.45f, 0.2f, 0.0f);


    //main structure

    quads(0.843, 0.631, 0.49, -0.59, -0.15,-0.59, -0.4,-0.5, -0.4, -0.5, -0.15);

    //windows
    glTranslatef(0.0f, -0.01f, 0.0f);

    line(0.859, 0.678, 0.318,  -0.58, -0.16, -0.55, -0.16, 10);
    line(0.859, 0.678, 0.318,  -0.54, -0.16, -0.51, -0.16, 10);
    line(0.859, 0.678, 0.318,  -0.58, -0.19, -0.55, -0.19, 10);
    line(0.859, 0.678, 0.318,  -0.54, -0.19, -0.51, -0.19, 10);
    line(0.859, 0.678, 0.318,  -0.58, -0.22, -0.55, -0.22, 10);
    line(0.859, 0.678, 0.318,  -0.54, -0.22, -0.51, -0.22, 10);
    line(0.859, 0.678, 0.318,  -0.58, -0.25, -0.55, -0.25, 10);
    line(0.859, 0.678, 0.318,  -0.54, -0.25, -0.51, -0.25, 10);
    line(0.859, 0.678, 0.318,  -0.58, -0.28, -0.55, -0.28, 10);
    line(0.859, 0.678, 0.318,  -0.54, -0.28, -0.51, -0.28, 10);
    line(0.859, 0.678, 0.318,  -0.58, -0.31, -0.55, -0.31, 10);
    line(0.859, 0.678, 0.318,  -0.54, -0.31, -0.51, -0.31, 10);
    line(0.859, 0.678, 0.318,  -0.58, -0.34, -0.55, -0.34, 10);
    line(0.859, 0.678, 0.318,  -0.54, -0.34, -0.51, -0.34, 10);
    line(0.859, 0.678, 0.318,  -0.58, -0.37, -0.55, -0.37, 10);
    line(0.859, 0.678, 0.318,  -0.54, -0.37, -0.51, -0.37, 10);

    glPopMatrix();


}










void buildingNight11() //white color
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 1.8f, 1.0f);
    glTranslatef(-0.05f, 0.177f, 0.0f);

    //main structure
    quads(0.933, 0.953, 0.969,  0.09, -0.06,0.09, -0.4,0.2, -0.4,0.2, -0.06);

    //window
    line(0.475, 0.725, 0.824,  0.11, -0.1,  0.18, -0.1,   10);
    line(0.475, 0.725, 0.824,  0.11, -0.14, 0.18, -0.14,  10);
    line(0.2, 0.2, 0.9,  0.11, -0.18, 0.18, -0.18,  10);
    line(0.2, 0.2, 0.9,  0.11, -0.22, 0.18, -0.22,  10);
    line(0.2, 0.2, 0.3,  0.11, -0.26, 0.18, -0.26,  10);
    line(0.2, 0.2, 0.3,  0.11, -0.3,  0.18, -0.3,   10);
    line(0.2, 0.2, 0.3,  0.11, -0.34, 0.18, -0.34,  10);

    glPopMatrix();
}


////////////////////////////////////////////////////////////////





void buildingNight12() //red color
{


    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.5f, 1.0f);
    glTranslatef(-0.22f, 0.24f, 0.0f);

    //main structure
    quads(0.62, 0.196, 0,  0.21, -0.22,0.21, -0.4,0.31, -0.4,0.31, -0.22);

    //window
    line(0.941, 0.824, 0.357, 0.23, -0.24, 0.29, -0.24, 10);
    line(0.941, 0.824, 0.357, 0.23, -0.28, 0.29, -0.28, 10);
    line(0.941, 0.824, 0.357, 0.23, -0.32, 0.29, -0.32, 10);
    line(0.941, 0.824, 0.357, 0.23, -0.36, 0.29, -0.36, 10);

    glPopMatrix();

}









void buildingNight16() // big right cream building
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(3.0f, 2.2f, 1.0f);
    glTranslatef(-0.56f, 0.217f, 0.0f);

    //body
    quads(0.851, 0.718, 0.529, 0.74, -0.14,0.74, -0.4,0.88, -0.4,0.88, -0.14);

    //windows
    glTranslatef(0.0f, -0.01f, 0.0f);

    quads(0.8, 0.569, 0.447, 0.76, -0.16, 0.8, -0.16,  0.8, -0.18, 0.76, -0.18 );
    quads(0.8, 0.569, 0.447, 0.82, -0.16, 0.86, -0.16, 0.86, -0.18, 0.82, -0.18);
    quads(0.8, 0.569, 0.447, 0.76, -0.24,0.8, -0.24, 0.8, -0.26, 0.76, -0.26 );
    quads(0.8, 0.569, 0.447, 0.82, -0.24,0.86, -0.24, 0.86, -0.26, 0.82, -0.26);
    quads(0.8, 0.569, 0.447, 0.76, -0.32,0.8, -0.32,  0.8, -0.34, 0.76, -0.34);
    quads(0.8, 0.569, 0.447, 0.82, -0.32,0.86, -0.32, 0.86, -0.34, 0.82, -0.34);

    glPopMatrix();

}







void buildingNight15() //dark drown
{


    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.2f, 1.0f);
    glTranslatef(-0.22f, 0.218f, 0.0f);

    //body
    quads(0.22, 0.118, 0.086, 0.37, -0.2,0.37, -0.4,0.5, -0.4,0.5, -0.2);


    //windows
    glTranslatef(0.005f, 0.0f, 0.0f);

    line(0.882, 0.765, 0.435,  0.38, -0.22,0.42, -0.22, 8);
    line(0.882, 0.765, 0.435,  0.44, -0.22,0.48, -0.22, 8);
    line(0.882, 0.765, 0.435,  0.38, -0.26,0.42, -0.26, 8);
    line(0.882, 0.765, 0.435,  0.44, -0.26,0.48, -0.26, 8);
    line(0.882, 0.765, 0.435,  0.38, -0.3,0.42, -0.3,   8);
    line(0.882, 0.765, 0.435,  0.44, -0.3,0.48, -0.3,   8);
    line(0.882, 0.765, 0.435,  0.38, -0.34,0.42, -0.34, 8);
    line(0.882, 0.765, 0.435,  0.44, -0.34,0.48, -0.34, 8);
    line(0.882, 0.765, 0.435,  0.38, -0.38,0.42, -0.38, 8);
    line(0.882, 0.765, 0.435,  0.44, -0.38,0.48, -0.38, 8);

    glPopMatrix();

}







void buildingNight17() //most right
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(2.0f, 2.8f, 1.0f);
    glTranslatef(-0.48f, 0.257f, 0.0f);

    //body
    quads(0.725, 0.788, 0.647, 0.92, -0.26,0.92, -0.4,1, -0.4,1, -0.26);

    //window
    line(1, 1, 0,  0.94, -0.28,0.98, -0.28,10);
    line(1, 1, 0,  0.94, -0.32,0.98, -0.32,10);
    line(1, 1, 0,  0.94, -0.36,0.98, -0.36,10);

    glPopMatrix();
}







void NightRoad ()
{
    //Main road
    quads(0.098, 0.133, 0.161, -1, -0.8, 1, -0.8, 1, -0.4, -1, -0.4 );

    //side lines
    line(1, 1, 1, -1, -0.42,  1, -0.42 , 3);
    line(1, 1, 1, -1, -0.78,  1, -0.78 , 3);


    //middle lines
    line(1, 1, 1, -1, -0.595,  1, -0.595 , 2);
    line(1, 1, 1, -1, -0.605,  1, -0.605 , 2);


}





//----------- Cars Left to Right --------------------//


void NightCar1() //blue car
{

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

   // glScalef(1.2, 1.2, 1.0);
    glTranslatef(-Pos_Car1, 0.05f, 0.0f);


    //body
    quads  (0, 0.392, 0.525,    -0.86, -0.44,-0.94, -0.52,-0.64, -0.52,-0.66, -0.44); //upper
    polygon(0, 0.392, 0.525,  -0.94, -0.52, -0.98, -0.53,-0.98, -0.56,-0.64, -0.56, -0.64, -0.52);  //lower


    //wheel
    circle(0, 0, 0,  0.03,  -0.9, -0.56);//wheel
    circle(0, 0, 0,  0.03,  -0.7, -0.56);//wheel

    circle(0.451, 0.478, 0.475,  0.02,  -0.9, -0.56);//wheel rim
    circle(0.451, 0.478, 0.475,  0.02,  -0.7, -0.56);//wheel rim

    //light
    quads(0.8, 0.467, 0.047, -0.98, -0.53,-0.98, -0.54,-0.94, -0.54,-0.94, -0.53);
    quads(0.8, 0.467, 0.047, -0.64, -0.53, -0.65, -0.54, -0.64, -0.54,-0.64, -0.54);


    //window
    quads(0.027, 0.678, 0.769, -0.85, -0.45,-0.89, -0.5,-0.77, -0.5,-0.77, -0.45);
    quads(0.027, 0.678, 0.769, -0.76, -0.45, -0.76, -0.5,-0.67, -0.5,-0.67, -0.45);

    glPopMatrix();


}





void NightCar2() //white cybertruck
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //glScalef(0.9, 0.9, 1.0);
    glTranslatef(-Pos_Car2, 0.05f, 0.0f);




    //body
    polygon(0.592, 0.604, 0.631,   0.39, -0.57, 0.9, -0.57,  0.91, -0.47,  0.41, -0.5,   0.38,  -0.52); //main body
    triangle(0.91, 0.91, 0.933, 0.61, -0.43,0.41, -0.5,0.91, -0.47);//upper body

    //window
    quads(0.286, 0.345, 0.502, 0.62, -0.44,0.55, -0.46,0.55, -0.47,0.62, -0.47);//window
    quads(0.286, 0.345, 0.502, 0.63, -0.44,0.63, -0.47,0.71, -0.46,0.71, -0.45);//window

    //lights
    line(1, 0, 0,  0.38, -0.52, 0.43, -0.505 , 9);
    line(1, 0, 0,  0.905, -0.5, 0.88, -0.5 , 9);

    //wheels
    circle(0,0,0,  0.037,  0.46, -0.56);
    circle(0,0,0,  0.037,  0.81, -0.56);

    circle(0.451, 0.478, 0.475,  0.023,  0.46, -0.56);
    circle(0.451, 0.478, 0.475,  0.023,  0.81, -0.56);

    glPopMatrix();

}







void NightCar3() //orange car
{

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //glScalef(0.9, 0.9, 1.0);
    glTranslatef(-Pos_Car3, 0.05f, 0.0f);

    //body
    quads(0.882, 0.506, 0.059,   2.79, -0.39,2.68, -0.5,3.09, -0.5,3.06, -0.39);//upper body
    quads(0.882, 0.506, 0.059,  2.65, -0.5,2.65, -0.55,3.09, -0.55,3.09, -0.5);//lower body

    //windows
    quads(0.192, 0.239, 0.529,     2.8 ,  -0.41,2.74, -0.48,2.9, -0.48,2.9, -0.41);//window body
    quads(0.192, 0.239, 0.529,    2.92,  -0.41,2.92, -0.48,3.04, -0.48,3.04, -0.41);//window body

    //wheels
    circle(0, 0, 0,  0.03, 2.73, -0.55);//wheel
    circle(0, 0, 0,  0.03, 3.02, -0.55);//wheel

    circle(0.451, 0.478, 0.475,  0.02, 2.73, -0.55);//wheel rim
    circle(0.451, 0.478, 0.475,  0.02, 3.02, -0.55);//wheel rim

    //lights
    quads(1, 1, 0, 2.67, -0.51, 2.65, -0.51, 2.65, -0.52, 2.67, -0.52);//front light
    quads(1,0, 0 , 3.09, -0.5, 3.07, -0.5, 3.07, -0.52, 3.09, -0.52);//back light

    glPopMatrix();

}






void NightCar4() //Yellow Truck
{

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(0.9, 0.9, 1.0);
    glTranslatef(-Pos_Car4 - 0.2, 0.0f, 0.0f);

    //body
    quads(1 ,0.9,0.1,  5, -0.2,5, -0.5,5.64, -0.5,5.64, -0.2);//back upper body
    quads(0.714, 0.761, 0.753,  4.98, -0.5,4.98, -0.54,5.64, -0.54,5.64, -0.5);//rim
    polygon(0.9,0.8,0.2,  4.68, -0.54,4.98, -0.54,4.98, -0.24,4.86, -0.24,4.68, -0.42);//front body

    //window
    quads(0.196, 0.788, 0.702,   4.86, -0.28,4.75, -0.4,4.96, -0.4,4.96, -0.28);//window


    // wheel
    circle(0,0,0,  0.045, 4.8, -0.54);
    circle(0,0,0,  0.045, 5.3, -0.54);
    circle(0,0,0,  0.045, 5.42, -0.54);

    circle(0.451, 0.478, 0.475,  0.03, 4.8, -0.54);
    circle(0.451, 0.478, 0.475,  0.03, 5.3, -0.54);
    circle(0.451, 0.478, 0.475,  0.03, 5.42, -0.54);

    //lights
    quads(1,0,0,  4.71, -0.44,4.68, -0.44,4.68, -0.46,4.71, -0.46);//front light
    quads(1,0,0,  5.64, -0.46,  5.62,-0.46, 5.62, -0.49,  5.64, -0.49);//back light


    glPopMatrix();

}





//----------- Cars Right to Left --------------------//


void NightCar5() //violet car
{

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(1.4, 1.4, 1.0);
    glTranslatef(Pos_Car5, 0.25f, 0.0f);


    //body
    quads(0.325, 0.157, 0.529,  0.06, -0.64, 0.04, -0.72,  0.3,  -0.72,    0.23, -0.64);//upper part
    quads(0.325, 0.157, 0.529,  0.04, -0.72, 0.04, -0.76,  0.32, -0.76,  0.32, -0.72);//lower part

    //windows
    quads(0.682, 0.91, 0.922,  0.07, -0.66, 0.06, -0.71,0.15, -0.71, 0.15, -0.66);//window part
    quads(0.682, 0.91, 0.922,  0.16, -0.66, 0.16, -0.71,0.27, -0.71, 0.23, -0.66);//window part

    // wheel
    circle(0, 0, 0, 0.025,0.1, -0.76);
    circle(0, 0, 0, 0.025,0.24, -0.76);

    circle(0.451, 0.478, 0.475, 0.015, 0.1, -0.76);
    circle(0.451, 0.478, 0.475, 0.015, 0.24, -0.76);

    // lights
    quads(1,0,0,0.06,   -0.73,0.04, -0.73,0.04, -0.75,0.05, -0.75);//back
    quads(1,0,0,0.32,   -0.73,0.3, -0.73,0.31, -0.75,0.32, -0.75);//front

    glPopMatrix();


}





void NightCar6()  // red car
{

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(1.2, 1.2, 1.0);
    glTranslatef(Pos_Car6, 0.17f, 0.0f);

    //body
    quads(0.678, 0.004, 0.004,   -0.79, -0.63,-0.82, -0.72,-0.5, -0.72,-0.58, -0.63);//upper part
    quads(0.678, 0.004, 0.004, -0.82, -0.72,-0.82, -0.76,-0.47, -0.76,-0.47, -0.72);//lower part

    //windows
    quads(0.224, 0.376, 0.588, -0.78, -0.65,-0.78, -0.7,-0.69, -0.7,-0.69, -0.65);//window part
    quads(0.224, 0.376, 0.588, -0.67, -0.65,-0.67, -0.7,-0.55, -0.7,-0.6, -0.65);//window part

    //wheel
    circle(0, 0, 0, 0.03, -0.76, -0.76);
    circle(0, 0, 0, 0.03, -0.54, -0.76);

    circle(0.451, 0.478, 0.475, 0.02, -0.76, -0.76);
    circle(0.451, 0.478, 0.475, 0.02, -0.54, -0.76);

    // lights
    quads(0.969, 0.839, 0.443, -0.81, -0.73,-0.82, -0.73,-0.82, -0.75,-0.81, -0.75);// back light
    quads(0.969, 0.839, 0.443, -0.47, -0.73,-0.48, -0.73,-0.48, -0.75,-0.47, -0.75);//front light

    glPopMatrix();

}





void NightCar7()//cargo van
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(1.4, 1.4, 1.0);
    glTranslatef(Pos_Car7 - 0.4 , 0.26f, 0.0f);


    //body
    quads  (0.737, 0.812, 0.663,      -1.74, -0.56,-1.74, -0.76,-1.5, -0.76,-1.5, -0.56);// cargo

    polygon(0.361, 0.541, 0.184,  -1.5, -0.6,-1.5, -0.76,-1.38, -0.76,-1.38, -0.68,-1.42, -0.6);//front
    quads  (0.361, 0.541, 0.184,    -1.38, -0.68,-1.38, -0.76,-1.34, -0.76,-1.34, -0.7);//front

    quads(0.612, 0.596, 0.565,  -1.75, -0.74,-1.75, -0.76,-1.7, -0.76,-1.7, -0.74);//back rim
    quads(0.612, 0.596, 0.565,  -1.33, -0.74,-1.38, -0.74,-1.38, -0.76,-1.33, -0.76);//front rim


    //wheel
    circle(0,0,0,  0.03, -1.64, -0.75);//wheel
    circle(0,0,0,  0.03, -1.45, -0.75);//wheel

    circle(0.451, 0.478, 0.475,  0.02, -1.64, -0.75);//wheel rim
    circle(0.451, 0.478, 0.475,  0.02, -1.45, -0.75);//wheel rim



    //window
    quads(0.184, 0.51, 0.922,  -1.48, -0.62,-1.48, -0.68,-1.38, -0.68,-1.41, -0.62);//window

    //light
    quads(0.949, 0.761, 0.337, -1.36, -0.7,-1.36, -0.72,-1.34, -0.72,-1.34, -0.7);//front light up

    glPopMatrix();


}





void NightCar8() //lower cybertruck
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_Car8 -0.4, 0.05f, 0.0f);


    //body
    triangle(0.086, 0.102, 0.122,  -2.82, -0.6,-3.18, -0.65,-2.58, -0.68);//upper body
    polygon (0.271, 0.306, 0.349,   -3.18, -0.65,-3.17, -0.74,-2.57, -0.76,-2.56, -0.69,-2.58, -0.68); //lower body


    //window
    quads(0.518, 0.859, 0.961,  -2.85, -0.61,-2.94, -0.63,-2.94, -0.64,-2.85, -0.65);
    quads(0.518, 0.859, 0.961,  -2.83, -0.61,-2.83, -0.65,-2.74, -0.66,-2.75, -0.64);


    //lights
    line (0.929, 0.745, 0.314, -2.56, -0.7, -2.59, -0.69 , 6);
    quads(0.929, 0.745, 0.314, -3.17, -0.72,  -3.17, -0.74,  -3.12, -0.74,  -3.12, -0.72);


    // wheels
    circle(0, 0, 0,  0.04,-3.05, -0.75);
    circle(0, 0, 0,  0.04,-2.65, -0.75);

    circle(0.451, 0.478, 0.475,  0.025, -3.05, -0.75); // wheel rim
    circle(0.451, 0.478, 0.475,  0.025, -2.65, -0.75); // wheel rim

    glPopMatrix();



}




void NightRoadside ()
{
    quads(0.094, 0.392, 0, -1, -1,  1, -1,  1, -0.8,  -1, -0.8 );

}





void NightRoadsideGrass ()
{
   // 1
    circle(0.298, 0.549, 0.275,   0.11  ,  -1.02, -0.98);


    //2
    circle(0, 0.3, 0,   0.1  ,  -0.8, -1);

    //3
    circle(0.298, 0.6, 0.275, 0.06  ,  -0.9, -1);

    //4
    circle(0.471, 0.612, 0.149 ,   0.02  ,  -0.68, -0.97 );
    circle(0.471, 0.612, 0.149 ,   0.03  ,  -0.7, -1);
    circle(0.471, 0.612, 0.149 ,   0.03  ,  -0.65, -1);


    //5
    polygon(0.047, 0.6, 0,   -0.62, -1 , -0.45, -1 ,  -0.4, -0.9  , -0.5, -0.95  , -0.5, -0.9);


   //-----------------------------------------------------------------------

   //Grass layer1
    polygon(0.671, 0.79, 0.38,    0.3, -1 , 0.5, -1 , 0.53, -0.87 , 0.45, -0.99 ,  0.46, -0.87);
    polygon(0.671, 0.79, 0.38,    0.5, -1 ,0.7, -1  , 0.73, -0.89 , 0.65, -0.94 ,0.64, -0.89  );
    polygon(0.671, 0.79, 0.38,    0.7, -1 , 0.9, -1 ,0.95, -0.9   ,0.86, -0.94  ,0.86, -0.87  );
    polygon(0.671, 0.79, 0.38,    0.9, -1 , 1, -1, 1.05, -0.9 , 0.98, -0.95 , 0.99, -0.89 );

    //Grass layer2
    polygon(0, 0.251, 0.008,    0.46, -1 , 0.58, -1 , 0.63, -0.91 , 0.55, -0.94 ,0.56, -0.87  );
    polygon(0, 0.251, 0.008,    0.66, -1 , 0.78, -1 , 0.82, -0.91 , 0.75, -0.97 ,0.75, -0.91  );



   //--------------------------------------------------------------------------

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.7, 0.0f, 0.0f);

    //Grass layer1
    polygon(0.671, 0.79, 0.38,    0.3, -1 , 0.5, -1 , 0.53, -0.87 , 0.45, -0.99 ,  0.46, -0.87);
    polygon(0.671, 0.79, 0.38,    0.5, -1 ,0.7, -1  , 0.73, -0.89 , 0.65, -0.94 ,0.64, -0.89  );
    polygon(0.671, 0.79, 0.38,    0.7, -1 , 0.9, -1 ,0.95, -0.9   ,0.86, -0.94  ,0.86, -0.87  );
    polygon(0.671, 0.79, 0.38,    0.9, -1 , 1, -1, 1.05, -0.9 , 0.98, -0.95 , 0.99, -0.89 );

    //Grass layer2
    polygon(0, 0.251, 0.008,    0.46, -1 , 0.58, -1 , 0.63, -0.91 , 0.55, -0.94 ,0.56, -0.87  );
    polygon(0, 0.251, 0.008,    0.66, -1 , 0.78, -1 , 0.82, -0.91 , 0.75, -0.97 ,0.75, -0.91  );


    glPopMatrix();




}







void DisplayAutumnNight()  //############################################################################################
{

    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    skyAutumnNight();
    riverNight();

    moonfull();

    AutumnSpringNightCloud1();
    AutumnSpringNightCloud2();
    AutumnSpringNightCloud3();
    AutumnSpringNightCloud4();
    AutumnSpringNightCloud5();
    AutumnSpringNightCloud6();



    riverNight();



    landNight();



    SummerAutumnNightHill2(); // in the back of hill 1 and 3
    SummerAutumnNightHill1();
    SummerAutumnNightHill3();

    SummerAutumnNightHill4();
    SummerAutumnNightHill6(); // behind hill 5
    SummerAutumnNightHill5();

    SummerAutumnNightHill8(); // behind hill 9
    SummerAutumnNightHill7();

    SummerAutumnNightHill11(); // behind hill 10
    SummerAutumnNightHill10(); // behind hill 9

    SummerAutumnNightHill9();









    NightchrisTree1();
    NightchrisTree2();
    NightchrisTree3();
    NightchrisTree4();



    NightcocoTree1();
    NightcocoTree2();
    NightcocoTree3();


   NightpineTree1();
   NightpineTree2();
   NightpineTree3();



    Nightboat2();
    Nightboat1();


    buildingBack();



    buildingNight7(); // behind building 1 and 2
    buildingNight1();
    buildingNight2();
    buildingNight3();

    buildingNight8(); // behind building 5
    buildingNight5();

    buildingNight9(); // behind building 6
    buildingNight10(); //behind building 6
    buildingNight6();

    buildingNight11();
    buildingNight12();

    buildingNight16(); //behind building 15 and 17
    buildingNight15();
    buildingNight17();





    //line( 0, 0, 0, -1, -0.4, 1, -0.4, 1 );

    NightRoad();

    // car Right to Left
    NightCar1();
    NightCar2();
    NightCar3();
    NightCar4();




    // car Left to Right
     NightCar5();
     NightCar6();
     NightCar7();
     NightCar8();


     NightRoadside();


     kashful1();
     kashful2();
     kashful3();
     kashful4();
     kashful5();
     kashful6();
     kashful7();
     kashful8();
     kashful9();
     kashful10();
     kashful11();
     kashful12();
     kashful13();


     NightRoadsideGrass();







    glFlush();  // Render now

    glPopMatrix();

}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//***************************************************************************************************************************





void skySummerMorning()
{

    quadsgrad(0.686, 0.871, 0.98, -1, 0.4, 1, 0.4,  1, 1, -1, 1, 0.463, 0.737, 0.922);

}



void SummerHeatwave()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef( 0.0f, 0.0f, 0.0f);

    quadsgradTransparent(1, 1, 1, 0.05, -1.5, -1.5, 1.5, -1.5, 1.5, 1.5, -1.5, 1.5  ,1, 0, 0, 0.5);

    glPopMatrix();
}




void skySummerNight()
{

    quadsgrad(0.486, 0.427, 0.384, -1, 0.4, 1, 0.4,  1, 1, -1, 1, 0.11, 0.125, 0.22);

}






void DisplaySummerMorning () //###################################################################################################
{


    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    skySummerMorning();
    sun();

    //Clouds
    SuAuSpMorningCloud1();
    SuAuSpMorningCloud2();
    SuAuSpMorningCloud3();
    SuAuSpMorningCloud4();
    SuAuSpMorningCloud5();
    SuAuSpMorningCloud6();



    riverMorning();



    landMorning();



    SummerAutumnMorningHill2(); // in the back of hill 1 and 3
    SummerAutumnMorningHill1();
    SummerAutumnMorningHill3();

    SummerAutumnMorningHill4();
    SummerAutumnMorningHill6(); // behind hill 5
    SummerAutumnMorningHill5();

    SummerAutumnMorningHill8(); // behind hill 9
    SummerAutumnMorningHill7();

    SummerAutumnMorningHill11(); // behind hill 10
    SummerAutumnMorningHill10(); // behind hill 9


    SummerAutumnMorningHill9();









    SuAuMorningChrisTree1();
    SuAuMorningChrisTree2();
    SuAuMorningChrisTree3();
    SuAuMorningChrisTree4();

    cocoTree1();
    cocoTree2();
    cocoTree3();

    pineTree1();
    pineTree2();
    pineTree3();


    boat2();
    boat1();

    buildingBack();

    building7(); // behind building 1 and 2
    building1();
    building2();
    building3();



    building8(); // behind building 5
    building5();



    building9(); // behind building 6
    building10(); //behind building 6
    building6();

    building11();
    building12();



    building16(); //behind building 15 and 17
    building15();
    building17();







    MorningRoad();

    // car Right to Left
    MorningCar1();
    MorningCar2();
    MorningCar3();
    MorningCar4();




    // car Left to Right
     MorningCar5();
     MorningCar6();
     MorningCar7();
     MorningCar8();


     MorningRoadside();

     MorningRoadsideGrass();


    SummerHeatwave();





    glFlush();  // Render now

    glPopMatrix();



}




void DisplaySummerNight()   //####################################################################################################
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    skySummerNight();
    riverNight();

    moonfull();

    AutumnSpringNightCloud1();
    AutumnSpringNightCloud2();
    AutumnSpringNightCloud3();
    AutumnSpringNightCloud4();
    AutumnSpringNightCloud5();
    AutumnSpringNightCloud6();



    riverNight();



    landNight();



    SummerAutumnNightHill2(); // in the back of hill 1 and 3
    SummerAutumnNightHill1();
    SummerAutumnNightHill3();

    SummerAutumnNightHill4();
    SummerAutumnNightHill6(); // behind hill 5
    SummerAutumnNightHill5();

    SummerAutumnNightHill8(); // behind hill 9
    SummerAutumnNightHill7();

    SummerAutumnNightHill11(); // behind hill 10
    SummerAutumnNightHill10(); // behind hill 9

    SummerAutumnNightHill9();









    NightchrisTree1();
    NightchrisTree2();
    NightchrisTree3();
    NightchrisTree4();



    NightcocoTree1();
    NightcocoTree2();
    NightcocoTree3();


   NightpineTree1();
   NightpineTree2();
   NightpineTree3();



    Nightboat2();
    Nightboat1();


    buildingBack();



    buildingNight7(); // behind building 1 and 2
    buildingNight1();
    buildingNight2();
    buildingNight3();

    buildingNight8(); // behind building 5
    buildingNight5();

    buildingNight9(); // behind building 6
    buildingNight10(); //behind building 6
    buildingNight6();

    buildingNight11();
    buildingNight12();

    buildingNight16(); //behind building 15 and 17
    buildingNight15();
    buildingNight17();




    NightRoad();

    // car Right to Left
    NightCar1();
    NightCar2();
    NightCar3();
    NightCar4();




    // car Left to Right
     NightCar5();
     NightCar6();
     NightCar7();
     NightCar8();


     NightRoadside();


     NightRoadsideGrass();







    glFlush();  // Render now

    glPopMatrix();

}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





void skyRainyMorning()
{
    quadsgrad(0.337, 0.349, 0.369, -1, 0.4, 1, 0.4,  1, 1, -1, 1, 0.898, 0.898, 0.902);

}


void skyRainyNight()
{
    quadsgrad(0.031, 0.031, 0.153, -1, 0.4, 1, 0.4,  1, 1, -1, 1, 0.306, 0.365, 0.443);

}


void rainCloud1 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05,  -0.86, 0.88 );
    circle(0.792, 0.8, 0.804, 0.03, -0.82, 0.87  );
    circle(0.792, 0.8, 0.804, 0.03, -0.91, 0.87  );

    glPopMatrix();
}


void rainCloud2 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05,  -0.83, 0.71 );
    circle(0.792, 0.8, 0.804, 0.03,  -0.79, 0.7 );
    circle(0.792, 0.8, 0.804, 0.03,   -0.88, 0.7);


    glPopMatrix();
}


void rainCloud3 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05, -0.66, 0.79  );
    circle(0.792, 0.8, 0.804, 0.03,  -0.61, 0.78 );
    circle(0.792, 0.8, 0.804, 0.03, -0.7, 0.78  );

    glPopMatrix();
}


void rainCloud4 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05, -0.54, 0.92  );
    circle(0.792, 0.8, 0.804, 0.03, -0.5, 0.91  );
    circle(0.792, 0.8, 0.804, 0.03,  -0.59, 0.91 );

    glPopMatrix();

}


void rainCloud5 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05,  -0.42, 0.77 );
    circle(0.792, 0.8, 0.804, 0.03, -0.37, 0.76  );
    circle(0.792, 0.8, 0.804, 0.03, -0.46, 0.76  );

    glPopMatrix();

}


void rainCloud6 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05, -0.3, 0.87  );
    circle(0.792, 0.8, 0.804, 0.03, -0.25, 0.86  );
    circle(0.792, 0.8, 0.804, 0.03, -0.34, 0.86  );

    glPopMatrix();

}


void rainCloud7 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05,  -0.19, 0.75 );
    circle(0.792, 0.8, 0.804, 0.03, -0.15, 0.74  );
    circle(0.792, 0.8, 0.804, 0.03, -0.23, 0.74  );

    glPopMatrix();

}


void rainCloud8 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05, -0.09, 0.92  );
    circle(0.792, 0.8, 0.804, 0.03,  -0.04, 0.91 );
    circle(0.792, 0.8, 0.804, 0.03, -0.13, 0.91  );

    glPopMatrix();


}


void rainCloud9 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05, 0.07, 0.81  );
    circle(0.792, 0.8, 0.804, 0.03, 0.11, 0.8  );
    circle(0.792, 0.8, 0.804, 0.03,  0.02, 0.79 );

    glPopMatrix();

}


void rainCloud10 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05, 0.19, 0.92  );
    circle(0.792, 0.8, 0.804, 0.03, 0.23, 0.9  );
    circle(0.792, 0.8, 0.804, 0.03,  0.14, 0.91 );

    glPopMatrix();


}




void rainCloud11 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05,0.23, 0.7   );
    circle(0.792, 0.8, 0.804, 0.03, 0.275, 0.695  );
    circle(0.792, 0.8, 0.804, 0.03,  0.19, 0.695 );

    glPopMatrix();
}


void rainCloud12 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05, 0.41, 0.88  );
    circle(0.792, 0.8, 0.804, 0.03,0.46, 0.87   );
    circle(0.792, 0.8, 0.804, 0.03, 0.37, 0.87  );

    glPopMatrix();

}


void rainCloud13 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05,0.54, 0.75   );
    circle(0.792, 0.8, 0.804, 0.03, 0.58, 0.74  );
    circle(0.792, 0.8, 0.804, 0.03, 0.49, 0.74  );

    glPopMatrix();

}


void rainCloud14 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05, 0.65, 0.91  );
    circle(0.792, 0.8, 0.804, 0.03, 0.69, 0.9  );
    circle(0.792, 0.8, 0.804, 0.03,  0.6, 0.9 );

    glPopMatrix();

}


void rainCloud15 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05, 0.8, 0.77  );
    circle(0.792, 0.8, 0.804, 0.03, 0.84, 0.76  );
    circle(0.792, 0.8, 0.804, 0.03, 0.75, 0.76  );

    glPopMatrix();

}


void rainCloud16 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05,  0.89, 0.91 );
    circle(0.792, 0.8, 0.804, 0.03, 0.93, 0.9  );
    circle(0.792, 0.8, 0.804, 0.03, 0.84, 0.9  );

    glPopMatrix();

}


void rainCloud17 ()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(0.0f, 0.0f , 0.0f);

    circle(0.792, 0.8, 0.804, 0.05,0.97, 0.69   );
    circle(0.792, 0.8, 0.804, 0.03, 1.02, 0.68  );
    circle(0.792, 0.8, 0.804, 0.03,  0.93, 0.68 );

    glPopMatrix();

}




void thunderStormDay()

{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(Scale_Thunderstorm, Scale_Thunderstorm ,1.0f);


   line(1, 0.894, 0.945, -0.77, 0.83  ,  -0.84, 0.8  , 2);
   line(1, 0.894, 0.945,  -0.84, 0.8 , -0.89, 0.79  , 2);
   line(1, 0.894, 0.945,  -0.77, 0.83 ,-0.8, 0.8   , 2);
   line(1, 0.894, 0.945,  -0.8, 0.8 , -0.83, 0.76  , 2);
   line(1, 0.894, 0.945, -0.8, 0.8  , -0.78, 0.77  , 2);
   line(1, 0.894, 0.945, -0.78, 0.77  , -0.76, 0.74  , 2);

   line(1, 0.894, 0.945, -0.44, 0.86  ,  -0.42, 0.82 , 2);
   line(1, 0.894, 0.945, -0.44, 0.86  ,  -0.5, 0.8 , 2);
   line(1, 0.894, 0.945, -0.5, 0.8  , -0.56, 0.76  , 2);
   line(1, 0.894, 0.945, -0.56, 0.76  , -0.62, 0.73  , 2);
   line(1, 0.894, 0.945,  -0.5, 0.8 ,  -0.48, 0.76 , 2);
   line(1, 0.894, 0.945,  -0.48, 0.76 , -0.53, 0.7  , 2);
   line(1, 0.894, 0.945, -0.53, 0.7  , -0.5, 0.6  , 2);
   line(1, 0.894, 0.945, -0.53, 0.7  , -0.58, 0.7  , 2);
   line(1, 0.894, 0.945, -0.58, 0.7  , -0.59, 0.65  , 2);
   line(1, 0.894, 0.945, -0.48, 0.76  , -0.46, 0.68  , 2);
   line(1, 0.894, 0.945, -0.46, 0.68  ,  -0.4, 0.6 , 2);

   line(1, 0.894, 0.945,-0.17, 0.9   , -0.22, 0.82  , 2);
   line(1, 0.894, 0.945, -0.19, 0.87  , -0.14, 0.69  , 2);
   line(1, 0.894, 0.945, -0.17, 0.78  , -0.23, 0.73  , 2);
   line(1, 0.894, 0.945, -0.19, 0.87  , -0.15, 0.85   , 2);

   line(1, 0.894, 0.945, 0.02, 0.86  , 0, 0.8  , 2);
   line(1, 0.894, 0.945, 0, 0.8  ,  0.01, 0.76 , 2);
   line(1, 0.894, 0.945, 0.01, 0.76  , 0, 0.7  , 2);
   line(1, 0.894, 0.945, 0, 0.7  , 0.03, 0.63  , 2);
   line(1, 0.894, 0.945, 0, 0.7  , -0.06, 0.64  , 2);

   line(1, 0.894, 0.945, 0.25, 0.91  , 0.21, 0.85  , 2);
   line(1, 0.894, 0.945,  0.21, 0.85 , 0.15, 0.8  , 2);
   line(1, 0.894, 0.945, 0.21, 0.85  , 0.21, 0.76  , 2);
   line(1, 0.894, 0.945, 0.21, 0.76  , 0.22, 0.66  , 2);
   line(1, 0.894, 0.945, 0.21, 0.76  ,  0.26, 0.72 , 2);

   line(1, 0.894, 0.945, 0.55, 0.71  , 0.55, 0.68  , 2);
   line(1, 0.894, 0.945, 0.55, 0.71  , 0.6, 0.67  , 2);
   line(1, 0.894, 0.945, 0.6, 0.67  , 0.63, 0.66  , 2);
   line(1, 0.894, 0.945,  0.55, 0.71 , 0.57, 0.66   , 2);
   line(1, 0.894, 0.945, 0.57, 0.66  ,  0.54, 0.61  , 2);
   line(1, 0.894, 0.945,  0.57, 0.66 ,  0.6, 0.63 , 2);

   line(1, 0.894, 0.945, 0.63, 0.89  ,  0.73, 0.92 , 2);
   line(1, 0.894, 0.945, 0.63, 0.89  , 0.67, 0.81  , 2);
   line(1, 0.894, 0.945, 0.63, 0.89  , 0.71, 0.86  , 2);
   line(1, 0.894, 0.945, 0.71, 0.86  ,  0.77, 0.82 , 2);
   line(1, 0.894, 0.945, 0.77, 0.82  , 0.87, 0.82  , 2);
   line(1, 0.894, 0.945, 0.77, 0.82  , 0.8, 0.8  , 2);
   line(1, 0.894, 0.945,  0.63, 0.89 ,  0.74, 0.77 , 2);
   line(1, 0.894, 0.945, 0.74, 0.77  , 0.73, 0.75  , 2);
   line(1, 0.894, 0.945,  0.74, 0.77 , 0.8, 0.7  , 2);
   line(1, 0.894, 0.945, 0.8, 0.7  ,  0.83, 0.66 , 2);


   glPopMatrix();

}


void thunderStormNight()

{

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glScalef(Scale_Thunderstorm,Scale_Thunderstorm ,1.0f);


   line(0.788, 0.412, 0.427, -0.77, 0.83  ,  -0.84, 0.8  , 2);
   line(0.788, 0.412, 0.427,  -0.84, 0.8 , -0.89, 0.79  , 2);
   line(0.788, 0.412, 0.427,  -0.77, 0.83 ,-0.8, 0.8   , 2);
   line(0.788, 0.412, 0.427,  -0.8, 0.8 , -0.83, 0.76  , 2);
   line(0.788, 0.412, 0.427, -0.8, 0.8  , -0.78, 0.77  , 2);
   line(0.788, 0.412, 0.427, -0.78, 0.77  , -0.76, 0.74  , 2);

   line(0.788, 0.412, 0.427, -0.44, 0.86  ,  -0.42, 0.82 , 2);
   line(0.788, 0.412, 0.427, -0.44, 0.86  ,  -0.5, 0.8 , 2);
   line(0.788, 0.412, 0.427, -0.5, 0.8  , -0.56, 0.76  , 2);
   line(0.788, 0.412, 0.427, -0.56, 0.76  , -0.62, 0.73  , 2);
   line(0.788, 0.412, 0.427,  -0.5, 0.8 ,  -0.48, 0.76 , 2);
   line(0.788, 0.412, 0.427,  -0.48, 0.76 , -0.53, 0.7  , 2);
   line(0.788, 0.412, 0.427, -0.53, 0.7  , -0.5, 0.6  , 2);
   line(0.788, 0.412, 0.427, -0.53, 0.7  , -0.58, 0.7  , 2);
   line(0.788, 0.412, 0.427, -0.58, 0.7  , -0.59, 0.65  , 2);
   line(0.788, 0.412, 0.427, -0.48, 0.76  , -0.46, 0.68  , 2);
   line(0.788, 0.412, 0.427, -0.46, 0.68  ,  -0.4, 0.6 , 2);

   line(0.788, 0.412, 0.427,-0.17, 0.9   , -0.22, 0.82  , 2);
   line(0.788, 0.412, 0.427, -0.19, 0.87  , -0.14, 0.69  , 2);
   line(0.788, 0.412, 0.427, -0.17, 0.78  , -0.23, 0.73  , 2);
   line(0.788, 0.412, 0.427, -0.19, 0.87  , -0.15, 0.85   , 2);

   line(0.788, 0.412, 0.427, 0.02, 0.86  , 0, 0.8  , 2);
   line(0.788, 0.412, 0.427, 0, 0.8  ,  0.01, 0.76 , 2);
   line(0.788, 0.412, 0.427, 0.01, 0.76  , 0, 0.7  , 2);
   line(0.788, 0.412, 0.427, 0, 0.7  , 0.03, 0.63  , 2);
   line(0.788, 0.412, 0.427, 0, 0.7  , -0.06, 0.64  , 2);

   line(0.788, 0.412, 0.427, 0.25, 0.91  , 0.21, 0.85  , 2);
   line(0.788, 0.412, 0.427,  0.21, 0.85 , 0.15, 0.8  , 2);
   line(0.788, 0.412, 0.427, 0.21, 0.85  , 0.21, 0.76  , 2);
   line(0.788, 0.412, 0.427, 0.21, 0.76  , 0.22, 0.66  , 2);
   line(0.788, 0.412, 0.427, 0.21, 0.76  ,  0.26, 0.72 , 2);

   line(0.788, 0.412, 0.427, 0.55, 0.71  , 0.55, 0.68  , 2);
   line(0.788, 0.412, 0.427, 0.55, 0.71  , 0.6, 0.67  , 2);
   line(0.788, 0.412, 0.427, 0.6, 0.67  , 0.63, 0.66  , 2);
   line(0.788, 0.412, 0.427,  0.55, 0.71 , 0.57, 0.66   , 2);
   line(0.788, 0.412, 0.427, 0.57, 0.66  ,  0.54, 0.61  , 2);
   line(0.788, 0.412, 0.427,  0.57, 0.66 ,  0.6, 0.63 , 2);

   line(0.788, 0.412, 0.427, 0.63, 0.89  ,  0.73, 0.92 , 2);
   line(0.788, 0.412, 0.427, 0.63, 0.89  , 0.67, 0.81  , 2);
   line(0.788, 0.412, 0.427, 0.63, 0.89  , 0.71, 0.86  , 2);
   line(0.788, 0.412, 0.427, 0.71, 0.86  ,  0.77, 0.82 , 2);
   line(0.788, 0.412, 0.427, 0.77, 0.82  , 0.87, 0.82  , 2);
   line(0.788, 0.412, 0.427, 0.77, 0.82  , 0.8, 0.8  , 2);
   line(0.788, 0.412, 0.427,  0.63, 0.89 ,  0.74, 0.77 , 2);
   line(0.788, 0.412, 0.427, 0.74, 0.77  , 0.73, 0.75  , 2);
   line(0.788, 0.412, 0.427,  0.74, 0.77 , 0.8, 0.7  , 2);
   line(0.788, 0.412, 0.427, 0.8, 0.7  ,  0.83, 0.66 , 2);

   glPopMatrix();

}




void rain()
{
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(Pos_Rain, Pos_Rain, 0.0);



    line(0.129, 0.412, 0.839,-0.95, 0.75,-1, 0.7,    2 );
    line(0.129, 0.412, 0.839, -0.9, 0.95,-0.95, 0.9, 2);
    line(0.129, 0.412, 0.839, -0.6, 0.95,-0.65, 0.9, 2);
    line(0.129, 0.412, 0.839, -0.4, 1,-0.45, 0.95,   2);
    line(0.129, 0.412, 0.839, -0.55, 0.85,-0.6, 0.8, 2);
    line(0.129, 0.412, 0.839,-0.74, 0.81,-0.79, 0.76,2 );
    line(0.129, 0.412, 0.839,-0.25, 0.95,-0.3, 0.9,  2 );
    line(0.129, 0.412, 0.839,-0.4, 0.8,-0.45, 0.75,  2 );
    line(0.129, 0.412, 0.839, -0.85, 0.55,-0.9, 0.5, 2);
    line(0.129, 0.412, 0.839,-0.95, 0.45,-1, 0.4,    2 );
    line(0.129, 0.412, 0.839, -0.15, 0.85,-0.2, 0.8, 2);
    line(0.129, 0.412, 0.839,-0.35, 0.65,-0.4, 0.6,  2 );
    line(0.129, 0.412, 0.839,-0.7, 0.5,-0.75, 0.45,  2 );
    line(0.129, 0.412, 0.839,0.05, 0.5,0, 0.45,      2);
    line(0.129, 0.412, 0.839,-0.85, 0.35,-0.9, 0.3,  2 );
    line(0.129, 0.412, 0.839,0.05, 0.85,0, 0.8,      2 );
    line(0.129, 0.412, 0.839,-0.1, 0.7,-.15,.65,     2 );
    line(0.129, 0.412, 0.839,-0.65, 0.35,-0.7, 0.3,  2 );
    line(0.129, 0.412, 0.839,-0.75, 0.25,-0.8, 0.2,  2 );
    line(0.129, 0.412, 0.839,-0.9, 0.1,-0.95, 0.05,  2 );
    line(0.129, 0.412, 0.839,-0.25, 0.2,-0.3, 0.15,  2 );
    line(0.129, 0.412, 0.839,0.2, 0.65,0.15, 0.6,    2 );
    line(0.129, 0.412, 0.839,-0.25, 0.55,-0.3, 0.5,  2 );
    line(0.129, 0.412, 0.839,-0.4, 0.4,-0.45, 0.35,  2 );
    line(0.129, 0.412, 0.839,-0.55, 0.25,-0.6, 0.2,  2 );
    line(0.129, 0.412, 0.839,-0.85, -0.05,-0.9, -0.1,2 );
    line(0.129, 0.412, 0.839,-0.1, 0.35,-0.15, 0.3,  2 );
    line(0.129, 0.412, 0.839,0.25, 0.9,0.2, 0.85,    2 );
    line(0.129, 0.412, 0.839,0.1, 0.75,0.05, 0.7,    2 );
    line(0.129, 0.412, 0.839,-0.05, 0.6,-0.1, 0.55,  2 );
    line(0.129, 0.412, 0.839,-0.2, 0.45, -0.25, 0.4, 2);
    line(0.129, 0.412, 0.839,-0.4, 0.25,-0.45, 0.2,  2 );
    line(0.129, 0.412, 0.839,-0.55, 0.1,-0.6, 0.05,  2 );
    line(0.129, 0.412, 0.839,-0.15, 0.1,-0.2, 0.05,  2 );
    line(0.129, 0.412, 0.839, 0, 0.25,-0.05, 0.2,    2);
    line(0.129, 0.412, 0.839,-0.4, 0.05,-0.45, 0,    2 );
    line(0.129, 0.412, 0.839,0.5, 0.95,0.45, 0.9,    2 );
    line(0.129, 0.412, 0.839,0.75, 1,0.7, 0.95,      2 );
    line(0.129, 0.412, 0.839,0.45, 0.7,0.4, 0.65,    2 );
    line(0.129, 0.412, 0.839,0.3, 0.55,0.25, 0.5,    2 );
    line(0.129, 0.412, 0.839,0.15, 0.4, 0.1, 0.35,   2);
    line(0.129, 0.412, 0.839, 0.35, 0.8,0.3, 0.75,   2);
    line(0.129, 0.412, 0.839,0.85, 0.95,0.8, 0.9,    2 );
    line(0.129, 0.412, 0.839,0.7, 0.8,0.65, 0.75,    2 );
    line(0.129, 0.412, 0.839,0.55, 0.65,0.5, 0.6,    2 );
    line(0.129, 0.412, 0.839,0.4, 0.5,0.35, 0.45,    2 );
    line(0.129, 0.412, 0.839,0.1, 0.2,0.05, 0.15,    2 );
    line(0.129, 0.412, 0.839,0.6, 0.85,0.55, 0.8,    2 );
    line(0.129, 0.412, 0.839, 1, 0.95,0.95, 0.9,     2);
    line(0.129, 0.412, 0.839,0.75, 0.5,0.7, 0.45,    2 );
    line(0.129, 0.412, 0.839,0.9, 0.85,0.85, 0.8,    2 );
    line(0.129, 0.412, 0.839,0.75, 0.35,0.7, 0.3,    2 );
    line(0.129, 0.412, 0.839,0.3, 0.25,0.25, 0.2,    2 );
    line(0.129, 0.412, 0.839,0, -0.05,-0.05, -0.1,   2 );
    line(0.129, 0.412, 0.839,0.75, 0.7,0.7, 0.65,    2 );
    line(0.129, 0.412, 0.839,0.6, 0.55, 0.55, 0.5,   2);
    line(0.129, 0.412, 0.839,0.6, 0.35,0.55, 0.3    ,2 );
    line(0.129, 0.412, 0.839,-0.2, -0.1,-0.25, -0.15,2 );
    line(0.129, 0.412, 0.839, 0.25, 0.35,0.2, 0.3,   2);
    line(0.129, 0.412, 0.839,0.15, -0.1,0.1, -0.15,  2 );
    line(0.129, 0.412, 0.839, 0.9, 0.5,0.85, 0.45,   2);
    line(0.129, 0.412, 0.839,0.45, 0.05, 0.4, 0,     2);
    line(0.129, 0.412, 0.839,0.45, 0.2,0.4, 0.15,    2 );
    line(0.129, 0.412, 0.839,0.45, 0.4, 0.4, 0.35,   2);
    line(0.129, 0.412, 0.839,0.75, 0.2,0.7, 0.15,    2 );
    line(0.129, 0.412, 0.839,0.45, -0.1,0.4, -0.15,  2 );
    line(0.129, 0.412, 0.839,0.9, 0.35,0.85, 0.3,    2 );
    line(0.129, 0.412, 0.839,0.9, 0.65,0.85, 0.6,    2 );
    line(0.129, 0.412, 0.839,1, 0.3, 0.95, 0.25,     2);
    line(0.129, 0.412, 0.839,0.6, 0.2,0.55, 0.15,    2 );
    line(0.129, 0.412, 0.839,0.75, 0.05,0.7, 0,      2 );
    line(0.129, 0.412, 0.839,0.9, 0.05,0.85, 0,      2 );
    line(0.129, 0.412, 0.839,1, 0.15,0.95, 0.1,      2 );
    line(0.129, 0.412, 0.839,0.9, 0.2,0.85, 0.15,    2 );
    line(0.129, 0.412, 0.839,-0.7, -0.05,-0.75, -0.1,2 );
    line(0.129, 0.412, 0.839,-0.7, -0.25,-0.75, -0.3,2 );
    line(0.129, 0.412, 0.839,-0.85, -0.2,-0.9, -0.25,2 );
    line(0.129, 0.412, 0.839,-0.95, -0.15,-1, -0.2,  2 );
    line(0.129, 0.412, 0.839,-0.7, 0.1,-0.75, 0.05,  2 );
    line(0.129, 0.412, 0.839,-0.85, -0.4, -0.9,-0.45,2);
    line(0.129, 0.412, 0.839,-0.95, -0.5,-1, -0.55,  2 );
    line(0.129, 0.412, 0.839,-0.3, -0.05,-0.35, -0.1,2 );
    line(0.129, 0.412, 0.839,-0.45,-0.2, -0.5, -0.25,2);
    line(0.129, 0.412, 0.839,-0.6, -0.35,-0.65, -0.4,2 );
    line(0.129, 0.412, 0.839,-0.75, -0.5,-0.8, -0.55,2 );
    line(0.129, 0.412, 0.839,-0.9, -0.65,-0.95, -0.7,2 );
    line(0.129, 0.412, 0.839,-0.55, -0.1,-0.6, -0.15,2 );
    line(0.129, 0.412, 0.839,-0.35, -0.25,-0.4, -0.3,2 );
    line(0.129, 0.412, 0.839,-0.65, -0.55,-0.7, -0.6,2 );
    line(0.129, 0.412, 0.839,-0.05, 0.05,-0.1, 0,    2 );
    line(0.129, 0.412, 0.839,-0.95, -0.85,-1, -0.9,  2 );
    line(0.129, 0.412, 0.839,-0.5, -0.4,-0.55, -0.45,2 );
    line(0.129, 0.412, 0.839, -0.8, -0.7,-0.85,-0.75,2);
    line(0.129, 0.412, 0.839,-0.15, -0.2,-0.2, -0.25,2 );
    line(0.129, 0.412, 0.839,-0.3, -0.35,-0.35, -0.4,2 );
    line(0.129, 0.412, 0.839,-0.45, -0.5,-0.5, -0.55,2 );
    line(0.129, 0.412, 0.839,-0.6, -0.65, -0.65,-0.7,2);
    line(0.129, 0.412, 0.839,-0.75, -0.8,-0.8, -0.85,2 );
    line(0.129, 0.412, 0.839,-0.9, -0.95,-0.95, -1,  2 );
    line(0.129, 0.412, 0.839,0.15, 0.1,0.1, 0.05,    2 );
    line(0.129, 0.412, 0.839,0, -0.25, -0.05, -0.3,  2);
    line(0.129, 0.412, 0.839,-0.3, -0.55, -0.35,-0.6,2);
    line(0.129, 0.412, 0.839,0.3, 0.05,0.25, 0,      2 );
    line(0.129, 0.412, 0.839,-0.45, -0.7,-0.5, -0.75,2 );
    line(0.129, 0.412, 0.839,-0.45, -0.85,-0.5, -0.9,2 );
    line(0.129, 0.412, 0.839,-0.3, -0.7,-0.35, -0.75,2 );
    line(0.129, 0.412, 0.839,0, -0.4,-0.05, -0.45,   2 );
    line(0.129, 0.412, 0.839,-0.7, -0.95,-0.75, -1,  2 );
    line(0.129, 0.412, 0.839,0.15, -0.25,0.1, -0.3,  2 );
    line(0.129, 0.412, 0.839,-0.6, -0.85,-0.65, -0.9,2 );
    line(0.129, 0.412, 0.839,-0.15, -0.55,-0.2, -0.6,2 );
    line(0.129, 0.412, 0.839,0.3, -0.1,0.25, -0.15,  2 );
    line(0.129, 0.412, 0.839,-0.15, -0.4,-0.2, -0.45,2 );
    line(0.129, 0.412, 0.839,0.3, -0.26, 0.25, -0.31,2);
    line(0.129, 0.412, 0.839,0.16, -0.39,0.11, -0.44,2 );
    line(0.129, 0.412, 0.839,0, -0.55, -0.05, -0.6,  2);
    line(0.129, 0.412, 0.839,-0.3, -0.85,-0.35, -0.9,2 );
    line(0.129, 0.412, 0.839,0.6, 0.05,0.55, 0,      2 );
    line(0.129, 0.412, 0.839,-0.4, -0.95,-0.45, -1,  2 );
    line(0.129, 0.412, 0.839,0.45, -0.25,0.4, -0.3,  2 );
    line(0.129, 0.412, 0.839,-0.15, -0.7,-0.2, -0.75,2 );
    line(0.129, 0.412, 0.839,0.3, -0.4,0.25, -0.45,  2 );
    line(0.129, 0.412, 0.839,0, -0.7,-0.05, -0.75,   2 );
    line(0.129, 0.412, 0.839,0.6, -0.1,0.55, -0.15,  2);
    line(0.129, 0.412, 0.839,-0.15, -0.85,-0.2, -0.9,2 );
    line(0.129, 0.412, 0.839,0.75, -0.1,0.7, -0.15,  2 );
    line(0.129, 0.412, 0.839,-0.25, -0.95,-0.3, -1,  2 );
    line(0.129, 0.412, 0.839,0.45, -0.4,0.4, -0.45,  2 );
    line(0.129, 0.412, 0.839, 0.15, -0.55,0.1, -0.6, 2);
    line(0.129, 0.412, 0.839, 0.3, -0.55,0.25, -0.6, 2);
    line(0.129, 0.412, 0.839,0, -0.85, -0.05, -0.9,  2);
    line(0.129, 0.412, 0.839,0.6, -0.25,0.55, -0.3,  2 );
    line(0.129, 0.412, 0.839,-0.1, -0.95,-0.15, -1,  2);
    line(0.129, 0.412, 0.839,0.85, -0.2,0.8, -0.25,  2 );
    line(0.129, 0.412, 0.839,0.15, -0.7,0.1, -0.75,  2 );
    line(0.129, 0.412, 0.839,0.55, -0.5,0.5, -0.55,  2 );
    line(0.129, 0.412, 0.839,1, -0.05,0.95, -0.1,    2 );
    line(0.129, 0.412, 0.839,0.4, -0.65,0.35, -0.7,  2 );
    line(0.129, 0.412, 0.839,0.25, -0.8,0.2, -0.85,  2 );
    line(0.129, 0.412, 0.839, 0.1, -0.95,0.05, -1,   2);
    line(0.129, 0.412, 0.839,0.95, -0.25,0.9, -0.3,  2 );
    line(0.129, 0.412, 0.839,0.5, -0.7,0.45, -0.75,  2 );
    line(0.129, 0.412, 0.839,0.35, -0.85, 0.3, -0.9, 2);
    line(0.129, 0.412, 0.839,0.95, -0.45,0.9, -0.5,  2 );
    line(0.129, 0.412, 0.839,0.65, -0.55, 0.6, -0.6, 2);
    line(0.129, 0.412, 0.839,0.7, -0.35,0.65, -0.4,  2 );
    line(0.129, 0.412, 0.839,0.8, -0.6, 0.75, -0.65, 2);
    line(0.129, 0.412, 0.839,0.5, -0.9,0.45, -0.95,  2 );
    line(0.129, 0.412, 0.839,0.8, -0.4, 0.75, -0.45, 2);
    line(0.129, 0.412, 0.839,0.8, -0.8,0.75, -0.85,  2 );
    line(0.129, 0.412, 0.839,0.65, -0.75,0.6, -0.8,  2 );
    line(0.129, 0.412, 0.839,0.65, -0.95, 0.6, -1,   2);
    line(0.129, 0.412, 0.839,1, -0.75, 0.95, -0.8,   2);
    line(0.129, 0.412, 0.839,0.95, -0.95,0.9, -1,    2 );
    line(0.129, 0.412, 0.839,0.95, -0.64,0.9, -0.69, 2 );
    line(0.129, 0.412, 0.839,0.85, -0.9,0.8, -0.95,  2 );
    line(0.129, 0.412, 0.839,-0.5, 0.5,-0.55, 0.45,  2 );
    line(0.129, 0.412, 0.839,-0.55, 0.65,-0.6, 0.6,  2 );
    line(0.129, 0.412, 0.839,-0.7, 0.7,-0.75, 0.65,  2 );
    line(0.129, 0.412, 0.839,-0.9, 0.65,-0.95, 0.6,  2 );
    line(0.129, 0.412, 0.839,-0.85, 0.85,-0.9, 0.8,  2 );
    line(0.129, 0.412, 0.839,-0.85, 1, -0.8, 1.05,   2);
    line(0.129, 0.412, 0.839,-1, 0.85,-1.05, 0.8,    2 );
    line(0.129, 0.412, 0.839, -1.05, 0.65,-1.1, 0.6, 2);
    line(0.129, 0.412, 0.839,-1.05, 0.5, -1.1, 0.45, 2);
    line(0.129, 0.412, 0.839,-1, 0.2,-1.05, 0.15,    2 );
    line(0.129, 0.412, 0.839,-1.05, -0.05,-1.1, -0.1,2 );
    line(0.129, 0.412, 0.839,-1, -0.35, -1.05, -0.4, 2);
    line(0.129, 0.412, 0.839,-1.05, -0.8,-1.1, -0.85,2 );
    line(0.129, 0.412, 0.839,1.05, -0.6,1.1, -0.55,  2 );
    line(0.129, 0.412, 0.839,1.05, -0.85, 1.1, -0.8, 2);
    line(0.129, 0.412, 0.839,1.05, -0.7,1.1, -0.65,  2 );
    line(0.129, 0.412, 0.839,1.05, -0.35, 1.1, -0.3, 2);
    line(0.129, 0.412, 0.839,1.05, -0.15,1.1, -0.1,  2 );
    line(0.129, 0.412, 0.839,1.05, 0,1.1, 0.05,      2 );
    line(0.129, 0.412, 0.839,1, 0.45,1.05, 0.5,      2 );
    line(0.129, 0.412, 0.839,1, 0.6,1.05, 0.65,      2 );
    line(0.129, 0.412, 0.839,1, 0.75,1.05, 0.8,      2 );
    line(0.129, 0.412, 0.839,1.05, 1,1.1, 1.05,      2 );
    line(0.129, 0.412, 0.839,0.8, 1.05,0.85, 1.1,    2 );
    line(0.129, 0.412, 0.839,0.95, 1.05,1, 1.1,      2 );
    line(0.129, 0.412, 0.839, 0.55, 1,0.6, 1.05,     2);
    line(0.129, 0.412, 0.839,0.35, 1,0.4, 1.05,      2 );
    line(0.129, 0.412, 0.839,0.1, 0.9,0.15, 0.95,    2 );
    line(0.129, 0.412, 0.839,0.2, 1,0.25, 1.05,      2 );
    line(0.129, 0.412, 0.839,-0.05, 0.95,0, 1,       2 );
    line(0.129, 0.412, 0.839,-0.2, 1,-0.15, 1.05,    2);
    line(0.129, 0.412, 0.839,-0.35, 1.05,-0.3, 1.1,  2 );
    line(0.129, 0.412, 0.839,-0.5, 1.05,-0.45, 1.1,  2 );
    line(0.129, 0.412, 0.839,-0.75, 0.95, -0.7, 1,   2);
    line(0.129, 0.412, 0.839,-0.65, 1.05,-0.6, 1.1,  2 );
    line(0.129, 0.412, 0.839,-1.1, 0.9, -1.05, 0.95, 2);
    line(0.129, 0.412, 0.839, -1, 1,-0.95, 1.05,     2);
    line(0.129, 0.412, 0.839,-1.1, 1.05,-1.05, 1.1,  2 );
    line(0.129, 0.412, 0.839,0.05, 1.05,0.1, 1.1,    2 );

    glPopMatrix();


}






void DisplayRainyDay() //#####################################################################################
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    skyRainyMorning();
    riverNight();



    rainCloud1();
    rainCloud2();
    rainCloud3();
    rainCloud4();
    rainCloud5();
    rainCloud6();
    rainCloud7();
    rainCloud8();
    rainCloud9();
    rainCloud10();
    rainCloud11();
    rainCloud12();
    rainCloud13();
    rainCloud14();
    rainCloud15();
    rainCloud16();
    rainCloud17();

    thunderStormDay();

    riverNight();



    landNight();



    SummerAutumnNightHill2(); // in the back of hill 1 and 3
    SummerAutumnNightHill1();
    SummerAutumnNightHill3();

    SummerAutumnNightHill4();
    SummerAutumnNightHill6(); // behind hill 5
    SummerAutumnNightHill5();

    SummerAutumnNightHill8(); // behind hill 9
    SummerAutumnNightHill7();

    SummerAutumnNightHill11(); // behind hill 10
    SummerAutumnNightHill10(); // behind hill 9

    SummerAutumnNightHill9();









    NightchrisTree1();
    NightchrisTree2();
    NightchrisTree3();
    NightchrisTree4();



    NightcocoTree1();
    NightcocoTree2();
    NightcocoTree3();


   NightpineTree1();
   NightpineTree2();
   NightpineTree3();



    Nightboat2();
    Nightboat1();


    buildingBack();



    buildingNight7(); // behind building 1 and 2
    buildingNight1();
    buildingNight2();
    buildingNight3();

    buildingNight8(); // behind building 5
    buildingNight5();

    buildingNight9(); // behind building 6
    buildingNight10(); //behind building 6
    buildingNight6();

    buildingNight11();
    buildingNight12();

    buildingNight16(); //behind building 15 and 17
    buildingNight15();
    buildingNight17();




    NightRoad();

    // car Right to Left
    NightCar1();
    NightCar2();
    NightCar3();
    NightCar4();




    // car Left to Right
     NightCar5();
     NightCar6();
     NightCar7();
     NightCar8();


     NightRoadside();


     NightRoadsideGrass();

    rain();


    glFlush();  // Render now

    glPopMatrix();
}




void DisplayRainyNight() //#####################################################################################
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    skyRainyNight();
    riverNight();



    rainCloud1();
    rainCloud2();
    rainCloud3();
    rainCloud4();
    rainCloud5();
    rainCloud6();
    rainCloud7();
    rainCloud8();
    rainCloud9();
    rainCloud10();
    rainCloud11();
    rainCloud12();
    rainCloud13();
    rainCloud14();
    rainCloud15();
    rainCloud16();
    rainCloud17();

    thunderStormNight();


    riverNight();



    landNight();



    SummerAutumnNightHill2(); // in the back of hill 1 and 3
    SummerAutumnNightHill1();
    SummerAutumnNightHill3();

    SummerAutumnNightHill4();
    SummerAutumnNightHill6(); // behind hill 5
    SummerAutumnNightHill5();

    SummerAutumnNightHill8(); // behind hill 9
    SummerAutumnNightHill7();

    SummerAutumnNightHill11(); // behind hill 10
    SummerAutumnNightHill10(); // behind hill 9

    SummerAutumnNightHill9();









    NightchrisTree1();
    NightchrisTree2();
    NightchrisTree3();
    NightchrisTree4();



    NightcocoTree1();
    NightcocoTree2();
    NightcocoTree3();


   NightpineTree1();
   NightpineTree2();
   NightpineTree3();



    Nightboat2();
    Nightboat1();


    buildingBack();



    buildingNight7(); // behind building 1 and 2
    buildingNight1();
    buildingNight2();
    buildingNight3();

    buildingNight8(); // behind building 5
    buildingNight5();

    buildingNight9(); // behind building 6
    buildingNight10(); //behind building 6
    buildingNight6();

    buildingNight11();
    buildingNight12();

    buildingNight16(); //behind building 15 and 17
    buildingNight15();
    buildingNight17();




    NightRoad();

    // car Right to Left
    NightCar1();
    NightCar2();
    NightCar3();
    NightCar4();




    // car Left to Right
     NightCar5();
     NightCar6();
     NightCar7();
     NightCar8();


     NightRoadside();


     NightRoadsideGrass();
     rain();



    glFlush();  // Render now

    glPopMatrix();
}




//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



void LAChrisTree1()
{
    //leafs
    triangle(0.871, 1, 0, -0.9, 0.5 , -0.82, 0.5, -0.86, 0.54);
    quads(0.706, 0.78, 0.216,    -0.9, 0.48, -0.82, 0.48, -0.84, 0.5, -0.88, 0.5);
    quads(0.761, 0.749, 0.212,  -0.9, 0.46, -0.82, 0.46, -0.84, 0.48, -0.88, 0.48);

    //treelog
    quads(0.533, 0.361, 0.212, -0.87, 0.41, -0.85, 0.41,  -0.855, 0.46, -0.865, 0.46 );
    quads(0.533, 0.361, 0.212,  -0.88, 0.4, -0.84, 0.4,-0.85, 0.41 , -0.87, 0.41 );

}





void LAChrisTree2()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.77f, 0.0f, 0.0f);

        //leafs
    triangle(0.871, 1, 0, -0.9, 0.5 , -0.82, 0.5, -0.86, 0.54);
    quads(0.706, 0.78, 0.216,    -0.9, 0.48, -0.82, 0.48, -0.84, 0.5, -0.88, 0.5);
    quads(0.761, 0.749, 0.212,  -0.9, 0.46, -0.82, 0.46, -0.84, 0.48, -0.88, 0.48);

    //treelog
    quads(0.533, 0.361, 0.212, -0.87, 0.41, -0.85, 0.41,  -0.855, 0.46, -0.865, 0.46 );
    quads(0.533, 0.361, 0.212,  -0.88, 0.4, -0.84, 0.4,-0.85, 0.41 , -0.87, 0.41 );

    glPopMatrix();

}





void LAChrisTree3()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.4f, 0.0f, 0.0f);

        //leafs
    triangle(0.871, 1, 0, -0.9, 0.5 , -0.82, 0.5, -0.86, 0.54);
    quads(0.706, 0.78, 0.216,    -0.9, 0.48, -0.82, 0.48, -0.84, 0.5, -0.88, 0.5);
    quads(0.761, 0.749, 0.212,  -0.9, 0.46, -0.82, 0.46, -0.84, 0.48, -0.88, 0.48);

    //treelog
    quads(0.533, 0.361, 0.212, -0.87, 0.41, -0.85, 0.41,  -0.855, 0.46, -0.865, 0.46 );
    quads(0.533, 0.361, 0.212,  -0.88, 0.4, -0.84, 0.4,-0.85, 0.41 , -0.87, 0.41 );
    glPopMatrix();

}





void LAChrisTree4()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.5f, 0.0f, 0.0f);

        //leafs
    triangle(0.871, 1, 0, -0.9, 0.5 , -0.82, 0.5, -0.86, 0.54);
    quads(0.706, 0.78, 0.216,    -0.9, 0.48, -0.82, 0.48, -0.84, 0.5, -0.88, 0.5);
    quads(0.761, 0.749, 0.212,  -0.9, 0.46, -0.82, 0.46, -0.84, 0.48, -0.88, 0.48);

    //treelog
    quads(0.533, 0.361, 0.212, -0.87, 0.41, -0.85, 0.41,  -0.855, 0.46, -0.865, 0.46 );
    quads(0.533, 0.361, 0.212,  -0.88, 0.4, -0.84, 0.4,-0.85, 0.41 , -0.87, 0.41 );
    glPopMatrix();

}













void LACocoTree1()
{
    //leafs
     triangle(0.78, 0.922, 0.506, -0.74, 0.48 , -0.69, 0.5, -0.68, 0.52);
     quads   (0.78, 0.922, 0.506, -0.69, 0.5, -0.67, 0.5, -0.62, 0.48, -0.68, 0.52);

     triangle(0.529, 0.588, 0.129, -0.76, 0.5,  -0.68, 0.52, -0.68, 0.54);
     triangle(0.529, 0.588, 0.129, -0.68, 0.52,  -0.6, 0.5,  -0.68, 0.54);


     triangle(0.78, 0.922, 0.506, -0.7, 0.53, -0.68, 0.54, -0.74, 0.56);
     triangle(0.78, 0.922, 0.506, -0.68, 0.54, -0.66, 0.53, -0.62, 0.56);

     //treelogs
     quads(0.682, 0.337, 0.071, -0.7, 0.4, -0.66, 0.4, -0.67, 0.5, -0.69, 0.5 );

}





void LACocoTree2()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.8f, 0.0f, 0.0f);

//leafs
     triangle(0.78, 0.922, 0.506, -0.74, 0.48 , -0.69, 0.5, -0.68, 0.52);
     quads   (0.78, 0.922, 0.506, -0.69, 0.5, -0.67, 0.5, -0.62, 0.48, -0.68, 0.52);

     triangle(0.529, 0.588, 0.129, -0.76, 0.5,  -0.68, 0.52, -0.68, 0.54);
     triangle(0.529, 0.588, 0.129, -0.68, 0.52,  -0.6, 0.5,  -0.68, 0.54);


     triangle(0.78, 0.922, 0.506, -0.7, 0.53, -0.68, 0.54, -0.74, 0.56);
     triangle(0.78, 0.922, 0.506, -0.68, 0.54, -0.66, 0.53, -0.62, 0.56);

     //treelogs
     quads(0.682, 0.337, 0.071, -0.7, 0.4, -0.66, 0.4, -0.67, 0.5, -0.69, 0.5 );
     glPopMatrix();

}





void LACocoTree3()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.6f, 0.0f, 0.0f);

    //leafs
     triangle(0.78, 0.922, 0.506, -0.74, 0.48 , -0.69, 0.5, -0.68, 0.52);
     quads   (0.78, 0.922, 0.506, -0.69, 0.5, -0.67, 0.5, -0.62, 0.48, -0.68, 0.52);

     triangle(0.529, 0.588, 0.129, -0.76, 0.5,  -0.68, 0.52, -0.68, 0.54);
     triangle(0.529, 0.588, 0.129, -0.68, 0.52,  -0.6, 0.5,  -0.68, 0.54);


     triangle(0.78, 0.922, 0.506, -0.7, 0.53, -0.68, 0.54, -0.74, 0.56);
     triangle(0.78, 0.922, 0.506, -0.68, 0.54, -0.66, 0.53, -0.62, 0.56);

     //treelogs
     quads(0.682, 0.337, 0.071, -0.7, 0.4, -0.66, 0.4, -0.67, 0.5, -0.69, 0.5 );
     glPopMatrix();

}






void LAPineTree1()
{
    triangle (0.882, 0.663, 0.286, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   ); //leafs

    quads(0.78, 0.533, 0.306, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  ); //log

}






void LAPineTree2()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.12f, 0.0f, 0.0f);


    triangle (0, 0.6, 0, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   ); //leafs
    quads(0.78, 0.533, 0.306, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  ); //log

    glPopMatrix();

}






void LAPineTree3()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.6f, 0.0f, 0.0f);


    triangle (0.882, 0.663, 0.286, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   ); //leafs
    quads(0.78, 0.533, 0.306, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  ); //log

    glPopMatrix();


}







void MorningRoadsideLA ()
{
    quads(0.918, 0.922, 0.506, -1, -1,  1, -1,  1, -0.8,  -1, -0.8 );

}





void MorningRoadsideGrassLA ()
{
   // 1
    circle(0.298, 0.549, 0.275,   0.11  ,  -1.02, -0.98);


    //2
    circle(0, 0.3, 0,   0.1  ,  -0.8, -1);

    //3
    circle(0.698, 0.655, 0.275, 0.06  ,  -0.9, -1);

    //4
    circle(1, 0.62, 0.227 ,   0.02  ,  -0.68, -0.97 );
    circle(1, 0.62, 0.227 ,   0.03  ,  -0.7, -1);
    circle(1, 0.62, 0.227 ,   0.03  ,  -0.65, -1);


    //5
    polygon(0.698, 0.655, 0.275,   -0.62, -1 , -0.45, -1 ,  -0.4, -0.9  , -0.5, -0.95  , -0.5, -0.9);


   //-----------------------------------------------------------------------

   //Grass layer1
    polygon(0.816, 0.831, 0.282,    0.3, -1 , 0.5, -1 , 0.53, -0.87 , 0.45, -0.99 ,  0.46, -0.87);
    polygon(0.816, 0.831, 0.282,    0.5, -1 ,0.7, -1  , 0.73, -0.89 , 0.65, -0.94 ,0.64, -0.89  );
    polygon(0.816, 0.831, 0.282,    0.7, -1 , 0.9, -1 ,0.95, -0.9   ,0.86, -0.94  ,0.86, -0.87  );
    polygon(0.816, 0.831, 0.282,    0.9, -1 , 1, -1, 1.05, -0.9 , 0.98, -0.95 , 0.99, -0.89 );

    //Grass layer2
    polygon(0.471, 0.478, 0.02,    0.46, -1 , 0.58, -1 , 0.63, -0.91 , 0.55, -0.94 ,0.56, -0.87  );
    polygon(0.471, 0.478, 0.02,    0.66, -1 , 0.78, -1 , 0.82, -0.91 , 0.75, -0.97 ,0.75, -0.91  );



   //--------------------------------------------------------------------------

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.7, 0.0f, 0.0f);

    //Grass layer1
    polygon(0.816, 0.831, 0.282,    0.3, -1 , 0.5, -1 , 0.53, -0.87 , 0.45, -0.99 ,  0.46, -0.87);
    polygon(0.816, 0.831, 0.282,    0.5, -1 ,0.7, -1  , 0.73, -0.89 , 0.65, -0.94 ,0.64, -0.89  );
    polygon(0.816, 0.831, 0.282,    0.7, -1 , 0.9, -1 ,0.95, -0.9   ,0.86, -0.94  ,0.86, -0.87  );
    polygon(0.816, 0.831, 0.282,    0.9, -1 , 1, -1, 1.05, -0.9 , 0.98, -0.95 , 0.99, -0.89 );

    //Grass layer2
    polygon(0.471, 0.478, 0.02,    0.46, -1 , 0.58, -1 , 0.63, -0.91 , 0.55, -0.94 ,0.56, -0.87  );
    polygon(0.471, 0.478, 0.02,    0.66, -1 , 0.78, -1 , 0.82, -0.91 , 0.75, -0.97 ,0.75, -0.91  );


    glPopMatrix();




}






void LAHill1()
{
    polygon (0.549, 0.686, 0.271,  -1, 0.48,-1,0.4,-.58,0.4,-.7,0.53,-0.92,0.52);
    triangle(0.549, 0.686, 0.271,  -0.92, 0.52,-0.68, 0.52,-0.83, 0.57);
}






void LAHill2()
{
    quads   (0.361, 0.588, 0.239,   -0.8, 0.5,-0.49, 0.45,-0.62, 0.6,-0.72, 0.6);
    triangle(0.361, 0.588, 0.239,   -0.72, 0.6,-0.62, 0.6,-0.67, 0.65);
}





void LAHill3()
{
    triangle(0.286, 0.376, 0.224,   -0.57, 0.54,-0.45, 0.54,-0.5, 0.57);
    polygon (0.286, 0.376, 0.224,   -0.67, 0.49, -0.58, 0.4,-0.25, 0.4,-0.45, 0.54,-0.57,0.54);
}







void LAHill4()
{
    quads(0, 0.118, 0.149,  -0.28, 0.55,-0.4, 0.5,-0.25, 0.4,-0.19, 0.52);
}





void LAHill5()
{
    quads(0.549, 0.69, 0.29,   -0.11, 0.52,-0.31, 0.44,-0.25, 0.4,0.12, 0.4);
}






void LAHill6()
{
    quads(0.396, 0.439, 0.098,   0.09, 0.61,-0.19, 0.52,-0.25, 0.4,0.3, 0.4);
}





void LAHill7()
{
    quads(0.247, 0.467, 0.22,  0.28, 0.69, 0.13, 0.57, 0.27, 0.43, 0.37, 0.53);
}






void LAHill8()
{
    triangle(0.271, 0.294, 0.051,  0.39, 0.68, 0.28, 0.54, 0.5, 0.48);
}







void LAHill9()
{
    quads(0.671, 0.702, 0.329,   0.52, 0.7, 0.27, 0.43, 0.3, 0.4, 0.61, 0.4);
}






void LAHill10()
{
    polygon(0.31, 0.451, 0.027, 0.64, 0.67,  0.5, 0.5,  0.61, 0.4, 1, 0.4, 1, 0.46);
}



void LAHill11()
{
    quads(0.286, 0.251, 0.153,  0.95, 0.64, 0.76, 0.59, 1, 0.46, 1, 0.6);

}




void skyLAMorning()
{

    quadsgrad(0.929, 0.859, 0.549, -1, 0.4, 1, 0.4,  1, 1, -1, 1, 0.788, 0.914, 0.98);

}


void skyLANight()
{

    quadsgrad(0.635, 0.588, 0.573, -1, 0.4, 1, 0.4,  1, 1, -1, 1, 0.322, 0.322, 0.357);

}







void DisplayLateAutumnDay() //#####################################################################################
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    skyLAMorning();
    riverMorning();

    sun();


    rainCloud1();
    rainCloud2();
    rainCloud3();
    rainCloud4();
    rainCloud5();
    rainCloud6();
    rainCloud7();
    rainCloud8();
    rainCloud9();
    rainCloud10();
    rainCloud11();
    rainCloud12();
    rainCloud13();
    rainCloud14();
    rainCloud15();
    rainCloud16();
    rainCloud17();



    landMorning();



    LAHill2(); // in the back of hill 1 and 3
    LAHill1();
    LAHill3();

    LAHill4();
    LAHill6(); // behind hill 5
    LAHill5();

    LAHill8(); // behind hill 9
    LAHill7();

    LAHill11(); // behind hill 10
    LAHill10(); // behind hill 9

    LAHill9();









    LAChrisTree1();
    LAChrisTree2();
    LAChrisTree3();
    LAChrisTree4();



    LACocoTree1();
    LACocoTree2();
    LACocoTree3();


    LAPineTree1();
    LAPineTree2();
    LAPineTree3();



    boat2();
    boat1();


    buildingBack();



    building7(); // behind building 1 and 2
    building1();
    building2();
    building3();

    building8(); // behind building 5
    building5();

    building9(); // behind building 6
    building10(); //behind building 6
    building6();

    building11();
    building12();

    building16(); //behind building 15 and 17
    building15();
    building17();




    MorningRoad();

    // car Right to Left
    MorningCar1();
    MorningCar2();
    MorningCar3();
    MorningCar4();




    // car Left to Right
     MorningCar5();
     MorningCar6();
     MorningCar7();
     MorningCar8();


    MorningRoadsideLA();
     MorningRoadsideGrassLA();




    glFlush();  // Render now

    glPopMatrix();
}







void DisplayLateAutumnNight() //#####################################################################################
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    skyLANight();
    riverNight();



    rainCloud1();
    rainCloud2();
    rainCloud3();
    rainCloud4();
    rainCloud5();
    rainCloud6();
    rainCloud7();
    rainCloud8();
    rainCloud9();
    rainCloud10();
    rainCloud11();
    rainCloud12();
    rainCloud13();
    rainCloud14();
    rainCloud15();
    rainCloud16();
    rainCloud17();








    landNight();


    LAHill2(); // in the back of hill 1 and 3
    LAHill1();
    LAHill3();

    LAHill4();
    LAHill6(); // behind hill 5
    LAHill5();

    LAHill8(); // behind hill 9
    LAHill7();

    LAHill11(); // behind hill 10
    LAHill10(); // behind hill 9

    LAHill9();









    LAChrisTree1();
    LAChrisTree2();
    LAChrisTree3();
    LAChrisTree4();



    LACocoTree1();
    LACocoTree2();
    LACocoTree3();


    LAPineTree1();
    LAPineTree2();
    LAPineTree3();


    Nightboat2();
    Nightboat1();


    buildingBack();



    buildingNight7(); // behind building 1 and 2
    buildingNight1();
    buildingNight2();
    buildingNight3();

    buildingNight8(); // behind building 5
    buildingNight5();

    buildingNight9(); // behind building 6
    buildingNight10(); //behind building 6
    buildingNight6();

    buildingNight11();
    buildingNight12();

    buildingNight16(); //behind building 15 and 17
    buildingNight15();
    buildingNight17();




    NightRoad();

    // car Right to Left
    NightCar1();
    NightCar2();
    NightCar3();
    NightCar4();




    // car Left to Right
     NightCar5();
     NightCar6();
     NightCar7();
     NightCar8();


     MorningRoadsideLA();


     MorningRoadsideGrassLA();




    glFlush();  // Render now

    glPopMatrix();
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////



void snow()
{



    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    //Translation Animation
    glTranslatef(Pos_snow_X, Pos_snow_Y , 0.0f);

    circle(1, 1, 1, 0.012 , -1.4, 1.4);
    circle(1, 1, 1, 0.012 ,-1.3, 1.4 );
    circle(1, 1, 1, 0.012 ,-1.2, 1.4 );
    circle(1, 1, 1, 0.012 , -1.1, 1.4);
    circle(1, 1, 1, 0.012 , -1, 1.4);
    circle(1, 1, 1, 0.012 , -0.9, 1.4);
    circle(1, 1, 1, 0.012 , -0.8, 1.4);
    circle(1, 1, 1, 0.012 , -0.7, 1.4);

    circle(1, 1, 1, 0.012 , -0.6, 1.4); //A1
    circle(1, 1, 1, 0.012 , -0.5, 1.4);
    circle(1, 1, 1, 0.012 , -0.4, 1.4);
    circle(1, 1, 1, 0.012 , -0.3, 1.4);
    circle(1, 1, 1, 0.012 , -0.2, 1.4);
    circle(1, 1, 1, 0.012 , -0.1, 1.4);
    circle(1, 1, 1, 0.012 , 0, 1.4);
    circle(1, 1, 1, 0.012 , 0.1, 1.4);
    circle(1, 1, 1, 0.012 , 0.2, 1.4);
    circle(1, 1, 1, 0.012 , 0.3, 1.4);
    circle(1, 1, 1, 0.012 , 0.4, 1.4);
    circle(1, 1, 1, 0.012 , 0.5, 1.4);
    circle(1, 1, 1, 0.012 ,0.6, 1.4 );
    circle(1, 1, 1, 0.012 , 0.7, 1.4);
    circle(1, 1, 1, 0.012 , 0.8, 1.4);
    circle(1, 1, 1, 0.012 , 0.9, 1.4);
    circle(1, 1, 1, 0.012 , 1.01, 1.39);
    circle(1, 1, 1, 0.012 , 1.1, 1.4);
    circle(1, 1, 1, 0.012 , 1.2, 1.4);
    circle(1, 1, 1, 0.012 , 1.3, 1.4);
    circle(1, 1, 1, 0.012 , 1.4, 1.4);
    circle(1, 1, 1, 0.012 ,-1.45, 1.3 );
    circle(1, 1, 1, 0.012 , -1.35, 1.3);
    circle(1, 1, 1, 0.012 , -1.25, 1.3);
    circle(1, 1, 1, 0.012 , -1.15, 1.3);
    circle(1, 1, 1, 0.012 , -1.05, 1.3);
    circle(1, 1, 1, 0.012 , -0.95, 1.3);
    circle(1, 1, 1, 0.012 , -0.85, 1.3);
    circle(1, 1, 1, 0.012 , -0.75, 1.3);
    circle(1, 1, 1, 0.012 , -0.65, 1.3);
    circle(1, 1, 1, 0.012 , -0.55, 1.3);
    circle(1, 1, 1, 0.012 , -0.45, 1.3);
    circle(1, 1, 1, 0.012 ,-0.35, 1.3 );
    circle(1, 1, 1, 0.012 , -0.26, 1.3);
    circle(1, 1, 1, 0.012 , -0.15, 1.3);
    circle(1, 1, 1, 0.012 , -0.15, 1.3);
    circle(1, 1, 1, 0.012 , -0.05, 1.3);

    circle(1, 1, 1, 0.012 , 0.05, 1.3);  //A2
    circle(1, 1, 1, 0.012 , 0.15, 1.3);
    circle(1, 1, 1, 0.012 , 0.25, 1.3);
    circle(1, 1, 1, 0.012 , 0.35, 1.3);
    circle(1, 1, 1, 0.012 , 0.45, 1.3);
    circle(1, 1, 1, 0.012 , 0.55, 1.3);
    circle(1, 1, 1, 0.012 , 0.65, 1.3);
    circle(1, 1, 1, 0.012 , 0.75, 1.3);
    circle(1, 1, 1, 0.012 , 0.85, 1.3);
    circle(1, 1, 1, 0.012 , 0.95, 1.3);
    circle(1, 1, 1, 0.012 , 1.05, 1.3);
    circle(1, 1, 1, 0.012 , 1.15, 1.3);
    circle(1, 1, 1, 0.012 , 1.25, 1.3);
    circle(1, 1, 1, 0.012 ,1.35, 1.3 );
    circle(1, 1, 1, 0.012 , 1.45, 1.3);
    circle(1, 1, 1, 0.012 , -1.4, 1.2);
    circle(1, 1, 1, 0.012 , -1.3, 1.2);
    circle(1, 1, 1, 0.012 , -1.2, 1.2);
    circle(1, 1, 1, 0.012 , -1.1, 1.2);
    circle(1, 1, 1, 0.012 , -1, 1.2);
    circle(1, 1, 1, 0.012 ,-0.9, 1.2 );
    circle(1, 1, 1, 0.012 , -0.8, 1.2);
    circle(1, 1, 1, 0.012 ,-0.7, 1.2 );
    circle(1, 1, 1, 0.012 , -0.6, 1.2);

    circle(1, 1, 1, 0.012 , -0.5, 1.2); //A3
    circle(1, 1, 1, 0.012 , -0.4, 1.2);
    circle(1, 1, 1, 0.012 , -0.3, 1.2);
    circle(1, 1, 1, 0.012 , -0.2, 1.2);
    circle(1, 1, 1, 0.012 , -0.1, 1.2);
    circle(1, 1, 1, 0.012 , 0, 1.2);
    circle(1, 1, 1, 0.012 , 0.1, 1.2);
    circle(1, 1, 1, 0.012 , 0.2, 1.2);
    circle(1, 1, 1, 0.012 ,0.3, 1.2 );
    circle(1, 1, 1, 0.012 ,0.4, 1.2 );
    circle(1, 1, 1, 0.012 , 0.5, 1.2);
    circle(1, 1, 1, 0.012 , 0.6, 1.2);
    circle(1, 1, 1, 0.012 , 0.7, 1.2);
    circle(1, 1, 1, 0.012 , 0.8, 1.2);
    circle(1, 1, 1, 0.012 , 0.9, 1.2);
    circle(1, 1, 1, 0.012 , 1, 1.2);
    circle(1, 1, 1, 0.012 , 1.1, 1.2);
    circle(1, 1, 1, 0.012 , 1.2, 1.2);
    circle(1, 1, 1, 0.012 ,1.3, 1.2 );
    circle(1, 1, 1, 0.012 , 1.4, 1.2);
    circle(1, 1, 1, 0.012 , -1.45, 1.1);
    circle(1, 1, 1, 0.012 , -1.35, 1.1);
    circle(1, 1, 1, 0.012 , -1.25, 1.1);
    circle(1, 1, 1, 0.012 , -1.15, 1.1);

    circle(1, 1, 1, 0.012 , -1.05, 1.1); //A4
    circle(1, 1, 1, 0.012 , -0.95, 1.1);
    circle(1, 1, 1, 0.012 , -0.85, 1.1);
    circle(1, 1, 1, 0.012 , -0.75, 1.1);
    circle(1, 1, 1, 0.012 , -0.65, 1.1);
    circle(1, 1, 1, 0.012 , -0.55, 1.1);
    circle(1, 1, 1, 0.012 , -0.45, 1.1);
    circle(1, 1, 1, 0.012 , -0.35, 1.1);
    circle(1, 1, 1, 0.012 , -0.25, 1.1);
    circle(1, 1, 1, 0.012 , -0.15, 1.1);
    circle(1, 1, 1, 0.012 , -0.05, 1.1);
    circle(1, 1, 1, 0.012 , 0.05, 1.1);
    circle(1, 1, 1, 0.012 , 0.15, 1.1);
    circle(1, 1, 1, 0.012 , 0.25, 1.1);
    circle(1, 1, 1, 0.012 , 0.35, 1.1);
    circle(1, 1, 1, 0.012 , 0.45, 1.1);
    circle(1, 1, 1, 0.012 , 0.55, 1.1);
    circle(1, 1, 1, 0.012 , 0.65, 1.1);
    circle(1, 1, 1, 0.012 , 0.75, 1.1);
    circle(1, 1, 1, 0.012 , 0.85, 1.1);
    circle(1, 1, 1, 0.012 , 0.95, 1.1);
    circle(1, 1, 1, 0.012 , 1.05, 1.1);
    circle(1, 1, 1, 0.012 , 1.15, 1.1);
    circle(1, 1, 1, 0.012 , 1.25, 1.1);

    circle(1, 1, 1, 0.012 , 1.35, 1.1); //A5
    circle(1, 1, 1, 0.012 , 1.45, 1.1);
    circle(1, 1, 1, 0.012 , -1.4, 1);
    circle(1, 1, 1, 0.012 , -1.3, 1);
    circle(1, 1, 1, 0.012 , -1.2, 1);
    circle(1, 1, 1, 0.012 , -1.1, 1);
    circle(1, 1, 1, 0.012 , -1, 1);
    circle(1, 1, 1, 0.012 , -0.9, 1);
    circle(1, 1, 1, 0.012 , -0.8, 1);
    circle(1, 1, 1, 0.012 , -0.7, 1);
    circle(1, 1, 1, 0.012 , -0.6, 1);
    circle(1, 1, 1, 0.012 , -0.5, 1);
    circle(1, 1, 1, 0.012 , -0.4, 1);
    circle(1, 1, 1, 0.012 , -0.3, 1);
    circle(1, 1, 1, 0.012 , -0.2, 1);
    circle(1, 1, 1, 0.012 , -0.1, 1);
    circle(1, 1, 1, 0.012 , 0, 1);
    circle(1, 1, 1, 0.012 , 0.1, 1);
    circle(1, 1, 1, 0.012 , 0.2, 1);
    circle(1, 1, 1, 0.012 , 0.3, 1);
    circle(1, 1, 1, 0.012 , 0.4, 1);
    circle(1, 1, 1, 0.012 , 0.5, 1);
    circle(1, 1, 1, 0.012 , 0.6, 1);
    circle(1, 1, 1, 0.012 ,0.7, 1 );

    circle(1, 1, 1, 0.012 , 0.8, 1); //A6
	circle(1, 1, 1, 0.012 , 1, 1);
	circle(1, 1, 1, 0.012 , 1.1, 1);
	circle(1, 1, 1, 0.012 , 1.2, 1);
	circle(1, 1, 1, 0.012 , 1.3, 1);
	circle(1, 1, 1, 0.012 , 1.4, 1);
	circle(1, 1, 1, 0.012 , 1.5, 1.05);
 	circle(1, 1, 1, 0.012 , -1.45, 0.9);
 	circle(1, 1, 1, 0.012 , -1.35, 0.9);
 	circle(1, 1, 1, 0.012 , -1.25, 0.9);
 	circle(1, 1, 1, 0.012 , -1.15, 0.9);
 	circle(1, 1, 1, 0.012 , -1.05, 0.9);
 	circle(1, 1, 1, 0.012 , -0.95, 0.9);
 	circle(1, 1, 1, 0.012 , -0.85, 0.9);
 	circle(1, 1, 1, 0.012 , -0.75, 0.9);
 	circle(1, 1, 1, 0.012 , -0.65, 0.9);
 	circle(1, 1, 1, 0.012 , -0.56, 0.9);
 	circle(1, 1, 1, 0.012 , -0.45, 0.9);
 	circle(1, 1, 1, 0.012 , -0.35, 0.9);
 	circle(1, 1, 1, 0.012 , -0.45, 0.9);
 	circle(1, 1, 1, 0.012 , -0.45, 0.9);
 	circle(1, 1, 1, 0.012 , -0.25, 0.9);
 	circle(1, 1, 1, 0.012 , -0.15, 0.9);
 	circle(1, 1, 1, 0.012 , -0.05, 0.9);
	circle(1, 1, 1, 0.012 , 0.06, 0.9);

	circle(1, 1, 1, 0.012 , 0.14, 0.9); //A7
	circle(1, 1, 1, 0.012 , 0.25, 0.9);
	circle(1, 1, 1, 0.012 , 0.35, 0.9);
	circle(1, 1, 1, 0.012 , 0.45, 0.9);
	circle(1, 1, 1, 0.012 , 0.55, 0.9);
	circle(1, 1, 1, 0.012 , 0.65, 0.9);
	circle(1, 1, 1, 0.012 , 0.75, 0.9);
	circle(1, 1, 1, 0.012 , 0.85, 0.9);
	circle(1, 1, 1, 0.012 , 0.96, 0.9);
	circle(1, 1, 1, 0.012 , 1.05, 0.9);
	circle(1, 1, 1, 0.012 , 1.15, 0.9);
	circle(1, 1, 1, 0.012 , 1.25, 0.9);
	circle(1, 1, 1, 0.012 , 1.35, 0.9);
	circle(1, 1, 1, 0.012 , 1.45, 0.9);
	circle(1, 1, 1, 0.012 , -1.4, 0.8);
	circle(1, 1, 1, 0.012 , -1.3, 0.8);
	circle(1, 1, 1, 0.012 , -1.2, 0.8);
	circle(1, 1, 1, 0.012 , -1.1, 0.8);
	circle(1, 1, 1, 0.012 , -1, 0.8);
	circle(1, 1, 1, 0.012 , -0.9, 0.8);
	circle(1, 1, 1, 0.012 , -0.8, 0.8);
	circle(1, 1, 1, 0.012 , -0.7, 0.8);
	circle(1, 1, 1, 0.012 , -0.6, 0.8);
	circle(1, 1, 1, 0.012 , -0.5, 0.8);

	circle(1, 1, 1, 0.012 , -0.4, 0.8); //A8
	circle(1, 1, 1, 0.012 , -0.3, 0.8);
	circle(1, 1, 1, 0.012 , -0.2, 0.8);
	circle(1, 1, 1, 0.012 , -0.1, 0.8);
	circle(1, 1, 1, 0.012 , 0, 0.8);
	circle(1, 1, 1, 0.012 , 0.1, 0.8);
	circle(1, 1, 1, 0.012 , 0.2, 0.8);
	circle(1, 1, 1, 0.012 , 0.3, 0.8);
	circle(1, 1, 1, 0.012 , 0.4, 0.8);
	circle(1, 1, 1, 0.012 , 0.5, 0.8);
	circle(1, 1, 1, 0.012 , 0.6, 0.8);
	circle(1, 1, 1, 0.012 , 0.7, 0.8);
	circle(1, 1, 1, 0.012 , 0.8, 0.8);
	circle(1, 1, 1, 0.012 , 0.9, 0.8);
	circle(1, 1, 1, 0.012 , 1, 0.8);
	circle(1, 1, 1, 0.012 , 1.1, 0.8);
	circle(1, 1, 1, 0.012 , 1.2, 0.8);
	circle(1, 1, 1, 0.012 , 1.3, 0.8);
	circle(1, 1, 1, 0.012 , 1.4, 0.8);
	circle(1, 1, 1, 0.012 , 1.5, 0.8);
 	circle(1, 1, 1, 0.012 , -1.45, 0.7);
 	circle(1, 1, 1, 0.012 , -1.35, 0.7);
 	circle(1, 1, 1, 0.012 , -1.25, 0.7);
 	circle(1, 1, 1, 0.012 , -1.15, 0.7);

 	circle(1, 1, 1, 0.012 , -1.05, 0.7); //A9
 	circle(1, 1, 1, 0.012 , -0.95, 0.7);
 	circle(1, 1, 1, 0.012 , -0.85, 0.7);
 	circle(1, 1, 1, 0.012 , -0.75, 0.7);
 	circle(1, 1, 1, 0.012 , -0.65, 0.7);
 	circle(1, 1, 1, 0.012 , -0.55, 0.69);
 	circle(1, 1, 1, 0.012 , -0.45, 0.7);
 	circle(1, 1, 1, 0.012 , -0.35, 0.7);
 	circle(1, 1, 1, 0.012 , -0.25, 0.7);
 	circle(1, 1, 1, 0.012 , -0.15, 0.7);
 	circle(1, 1, 1, 0.012 , -0.05, 0.7);
	circle(1, 1, 1, 0.012 , 0.05, 0.7);
	circle(1, 1, 1, 0.012 , 0.15, 0.7);
	circle(1, 1, 1, 0.012 , 0.26, 0.7);
	circle(1, 1, 1, 0.012 , 0.36, 0.7);
	circle(1, 1, 1, 0.012 , 0.45, 0.7);
	circle(1, 1, 1, 0.012 , 0.55, 0.7);
	circle(1, 1, 1, 0.012 , 0.65, 0.7);
	circle(1, 1, 1, 0.012 , 0.75, 0.7);
	circle(1, 1, 1, 0.012 , 0.85, 0.7);
	circle(1, 1, 1, 0.012 , 0.95, 0.7);
	circle(1, 1, 1, 0.012 , 1.05, 0.7);
	circle(1, 1, 1, 0.012 , 1.14, 0.7);
	circle(1, 1, 1, 0.012 , 1.26, 0.7);

 	 circle(1, 1, 1, 0.012 , 1.35, 0.7); //A10
 	 circle(1, 1, 1, 0.012 , 1.45, 0.7);
 	 circle(1, 1, 1, 0.012 , -1.4, 0.6);
 	 circle(1, 1, 1, 0.012 , -1.3, 0.6);
 	 circle(1, 1, 1, 0.012 , -1.2, 0.6);
 	 circle(1, 1, 1, 0.012 , -1.1, 0.6);
	 circle(1, 1, 1, 0.012 , -1, 0.6);
 	 circle(1, 1, 1, 0.012 , -0.9, 0.6);
 	 circle(1, 1, 1, 0.012 , -0.8, 0.6);
 	 circle(1, 1, 1, 0.012 , -0.7, 0.6);
 	 circle(1, 1, 1, 0.012 , -0.6, 0.6);
 	 circle(1, 1, 1, 0.012 , -0.5, 0.6);
 	 circle(1, 1, 1, 0.012 , -0.4, 0.6);
 	 circle(1, 1, 1, 0.012 , -0.3, 0.6);
 	 circle(1, 1, 1, 0.012 , -0.2, 0.6);
 	 circle(1, 1, 1, 0.012 , -0.1, 0.6);
	 circle(1, 1, 1, 0.012 , 0, 0.6);
	 circle(1, 1, 1, 0.012 , 0.1, 0.6);
	 circle(1, 1, 1, 0.012 , 0.2, 0.6);
	 circle(1, 1, 1, 0.012 , 0.3, 0.6);
	 circle(1, 1, 1, 0.012 , 0.4, 0.6);
	 circle(1, 1, 1, 0.012 , 0.5, 0.6);
	 circle(1, 1, 1, 0.012 , 0.6, 0.6);
	 circle(1, 1, 1, 0.012 , 0.7, 0.6);

	 circle(1, 1, 1, 0.012 , 0.8, 0.6); //A11
	 circle(1, 1, 1, 0.012 , 0.9, 0.6);
	 circle(1, 1, 1, 0.012 , 1, 0.6);
	 circle(1, 1, 1, 0.012 , 1.1, 0.6);
	 circle(1, 1, 1, 0.012 , 1.2, 0.6);
	 circle(1, 1, 1, 0.012 , 1.3, 0.6);
	 circle(1, 1, 1, 0.012 , 1.4, 0.6);
	 circle(1, 1, 1, 0.012 , 1.5, 0.69);
 	 circle(1, 1, 1, 0.012 , -1.45, 0.5);
 	 circle(1, 1, 1, 0.012 , -1.35, 0.5);
 	 circle(1, 1, 1, 0.012 , -1.25, 0.5);
 	 circle(1, 1, 1, 0.012 , -1.15, 0.5);
 	 circle(1, 1, 1, 0.012 , -1.05, 0.5);
 	 circle(1, 1, 1, 0.012 , -0.95, 0.5);
 	 circle(1, 1, 1, 0.012 , -0.85, 0.5);
 	 circle(1, 1, 1, 0.012 , -0.75, 0.5);
 	 circle(1, 1, 1, 0.012 , -0.65, 0.5);
 	 circle(1, 1, 1, 0.012 , -0.55, 0.5);
 	 circle(1, 1, 1, 0.012 , -0.45, 0.5);
 	 circle(1, 1, 1, 0.012 , -0.35, 0.5);
 	 circle(1, 1, 1, 0.012 , -0.25, 0.5);
 	 circle(1, 1, 1, 0.012 , -0.14, 0.5);
 	 circle(1, 1, 1, 0.012 , -0.05, 0.5);
 	 circle(1, 1, 1, 0.012 , 0.06, 0.5);

 	 circle(1, 1, 1, 0.012 , 0.16, 0.5); //A12
 	 circle(1, 1, 1, 0.012 , 0.26, 0.5);
 	 circle(1, 1, 1, 0.012 , 0.36, 0.5);
 	 circle(1, 1, 1, 0.012 , 0.45, 0.5);
 	 circle(1, 1, 1, 0.012 , 0.55, 0.5);
 	 circle(1, 1, 1, 0.012 , 0.66, 0.5);
 	 circle(1, 1, 1, 0.012 , 0.75, 0.5);
 	 circle(1, 1, 1, 0.012 , 0.85, 0.5);
 	 circle(1, 1, 1, 0.012 , 0.95, 0.5);
 	 circle(1, 1, 1, 0.012 , 1.05, 0.5);
 	 circle(1, 1, 1, 0.012 , 1.15, 0.5);
 	 circle(1, 1, 1, 0.012 , 1.25, 0.5);
 	 circle(1, 1, 1, 0.012 , 1.35, 0.5);
 	 circle(1, 1, 1, 0.012 , 1.45, 0.5);
 	 circle(1, 1, 1, 0.012 , -1.4, 0.4);
 	 circle(1, 1, 1, 0.012 , -1.3, 0.4);
 	 circle(1, 1, 1, 0.012 , -1.2, 0.4);
 	 circle(1, 1, 1, 0.012 , -1.1, 0.4);
	 circle(1, 1, 1, 0.012 , -1, 0.4);
 	 circle(1, 1, 1, 0.012 , -0.9, 0.4);
 	 circle(1, 1, 1, 0.012 , -0.8, 0.4);
 	 circle(1, 1, 1, 0.012 , -0.7, 0.4);
 	 circle(1, 1, 1, 0.012 , -0.6, 0.4);
 	 circle(1, 1, 1, 0.012 , -0.5, 0.4);

 	 circle(1, 1, 1, 0.012 , -0.4, 0.4); //A13
 	 circle(1, 1, 1, 0.012 , -0.3, 0.4);
 	 circle(1, 1, 1, 0.012 , -0.2, 0.4);
 	 circle(1, 1, 1, 0.012 , -0.1, 0.4);
	 circle(1, 1, 1, 0.012 , 0, 0.4);
	 circle(1, 1, 1, 0.012 , 0.1, 0.4);
	 circle(1, 1, 1, 0.012 , 0.2, 0.4);
	 circle(1, 1, 1, 0.012 , 0.3, 0.4);
	 circle(1, 1, 1, 0.012 , 0.4, 0.4);
	 circle(1, 1, 1, 0.012 , 0.5, 0.4);
	 circle(1, 1, 1, 0.012 , 0.6, 0.4);
	 circle(1, 1, 1, 0.012 , 0.7, 0.4);
	 circle(1, 1, 1, 0.012 , 0.8, 0.4);
	 circle(1, 1, 1, 0.012 , 0.9, 0.4);
	 circle(1, 1, 1, 0.012 , 1, 0.4);
	 circle(1, 1, 1, 0.012 , 1.1, 0.4);
	 circle(1, 1, 1, 0.012 , 1.2, 0.4);
	 circle(1, 1, 1, 0.012 , 1.3, 0.4);
	 circle(1, 1, 1, 0.012 , 1.4, 0.4);
	 circle(1, 1, 1, 0.012 , 1.5, 0.51);
 	 circle(1, 1, 1, 0.012 , -1.45, 0.3);
 	 circle(1, 1, 1, 0.012 , -1.35, 0.3);
 	 circle(1, 1, 1, 0.012 , -1.25, 0.3);
 	 circle(1, 1, 1, 0.012 , -1.15, 0.3);

 	 circle(1, 1, 1, 0.012 , -1.05, 0.3); //A14
 	 circle(1, 1, 1, 0.012 , -0.96, 0.3);
 	 circle(1, 1, 1, 0.012 , -0.85, 0.3);
 	 circle(1, 1, 1, 0.012 , -0.75, 0.3);
 	 circle(1, 1, 1, 0.012 , -0.64, 0.3);
 	 circle(1, 1, 1, 0.012 , -0.55, 0.3);
 	 circle(1, 1, 1, 0.012 , -0.45, 0.3);
 	 circle(1, 1, 1, 0.012 , -0.35, 0.3);
 	 circle(1, 1, 1, 0.012 , -0.25, 0.3);
 	 circle(1, 1, 1, 0.012 , -0.15, 0.3);
 	 circle(1, 1, 1, 0.012 , -0.04, 0.3);
 	 circle(1, 1, 1, 0.012 , 0.06, 0.3);
 	 circle(1, 1, 1, 0.012 , 0.15, 0.3);
 	 circle(1, 1, 1, 0.012 , 0.26, 0.3);
 	 circle(1, 1, 1, 0.012 , 0.34, 0.3);
 	 circle(1, 1, 1, 0.012 , 0.45, 0.3);
 	 circle(1, 1, 1, 0.012 , 0.56, 0.3);
 	 circle(1, 1, 1, 0.012 , 0.65, 0.3);
 	 circle(1, 1, 1, 0.012 , 0.73, 0.31);
 	 circle(1, 1, 1, 0.012 , 0.84, 0.3);
 	 circle(1, 1, 1, 0.012 , 0.95, 0.3);
 	 circle(1, 1, 1, 0.012 , 1.04, 0.3);
 	 circle(1, 1, 1, 0.012 , 1.14, 0.3);
 	 circle(1, 1, 1, 0.012 , 1.25, 0.31);

 	 circle(1, 1, 1, 0.012 , 1.34, 0.3); //A15
 	 circle(1, 1, 1, 0.012 , 1.45, 0.3);
 	 circle(1, 1, 1, 0.012 , -1.4, 0.2);
 	 circle(1, 1, 1, 0.012 , -1.3, 0.2);
 	 circle(1, 1, 1, 0.012 , -1.2, 0.2);
 	 circle(1, 1, 1, 0.012 , -1.1, 0.2);
	 circle(1, 1, 1, 0.012 , -1, 0.2);
 	 circle(1, 1, 1, 0.012 , -0.9, 0.2);
 	 circle(1, 1, 1, 0.012 , -0.8, 0.2);
 	 circle(1, 1, 1, 0.012 , -0.7, 0.2);
 	 circle(1, 1, 1, 0.012 , -0.6, 0.2);
 	 circle(1, 1, 1, 0.012 , -0.5, 0.2);
 	 circle(1, 1, 1, 0.012 , -0.4, 0.2);
 	 circle(1, 1, 1, 0.012 , -0.3, 0.2);
 	 circle(1, 1, 1, 0.012 , -0.2, 0.2);
 	 circle(1, 1, 1, 0.012 , -0.1, 0.2);
	 circle(1, 1, 1, 0.012 , 0, 0.2);
	 circle(1, 1, 1, 0.012 , 0.1, 0.2);
	 circle(1, 1, 1, 0.012 , 0.2, 0.2);
	 circle(1, 1, 1, 0.012 , 0.3, 0.2);
	 circle(1, 1, 1, 0.012 , 0.4, 0.2);
	 circle(1, 1, 1, 0.012 , 0.5, 0.2);
	 circle(1, 1, 1, 0.012 , 0.6, 0.2);
	 circle(1, 1, 1, 0.012 , 0.7, 0.2);

	 circle(1, 1, 1, 0.012 , 0.8, 0.2); //A16
	 circle(1, 1, 1, 0.012 , 0.9, 0.2);
	 circle(1, 1, 1, 0.012 , 1, 0.2);
	 circle(1, 1, 1, 0.012 , 1.1, 0.2);
	 circle(1, 1, 1, 0.012 , 1.2, 0.2);
	 circle(1, 1, 1, 0.012 , 1.3, 0.2);
	 circle(1, 1, 1, 0.012 , 1.4, 0.2);
	 circle(1, 1, 1, 0.012 , 1.5, 0.33);
 	 circle(1, 1, 1, 0.012 , -1.45, 0.1);
 	 circle(1, 1, 1, 0.012 , -1.35, 0.1);
 	 circle(1, 1, 1, 0.012 , -1.25, 0.1);
 	 circle(1, 1, 1, 0.012 , -1.15, 0.1);
 	 circle(1, 1, 1, 0.012 , -1.06, 0.1);
 	 circle(1, 1, 1, 0.012 , -0.96, 0.1);
 	 circle(1, 1, 1, 0.012 , -0.85, 0.1);
 	 circle(1, 1, 1, 0.012 , -0.75, 0.1);
 	 circle(1, 1, 1, 0.012 , -0.65, 0.1);
 	 circle(1, 1, 1, 0.012 , -0.54, 0.1);
 	 circle(1, 1, 1, 0.012 , -0.44, 0.1);
 	 circle(1, 1, 1, 0.012 , -0.35, 0.1);
 	 circle(1, 1, 1, 0.012 , -0.24, 0.1);
 	 circle(1, 1, 1, 0.012 , -0.15, 0.1);
 	 circle(1, 1, 1, 0.012 , -0.04, 0.1);
 	 circle(1, 1, 1, 0.012 , 0.06, 0.1);

 	 circle(1, 1, 1, 0.012 , 0.15, 0.1); //A17
 	 circle(1, 1, 1, 0.012 , 0.24, 0.1);
 	 circle(1, 1, 1, 0.012 , 0.35, 0.1);
 	 circle(1, 1, 1, 0.012 , 0.45, 0.1);
 	 circle(1, 1, 1, 0.012 , 0.55, 0.1);
 	 circle(1, 1, 1, 0.012 , 0.65, 0.1);
 	 circle(1, 1, 1, 0.012 , 0.75, 0.1);
 	 circle(1, 1, 1, 0.012 , 0.85, 0.1);
 	 circle(1, 1, 1, 0.012 , 0.95, 0.1);
 	 circle(1, 1, 1, 0.012 , 1.05, 0.1);
 	 circle(1, 1, 1, 0.012 , 1.15, 0.1);
 	 circle(1, 1, 1, 0.012 , 1.25, 0.1);
 	 circle(1, 1, 1, 0.012 , 1.34, 0.1);
 	 circle(1, 1, 1, 0.012 , 1.45, 0.1);
	 circle(1, 1, 1, 0.012 , -1.4, 0);
	 circle(1, 1, 1, 0.012 , -1.3, 0);
	 circle(1, 1, 1, 0.012 , -1.2, 0);
	 circle(1, 1, 1, 0.012 , -1.1, 0);
	 circle(1, 1, 1, 0.012 , -1, 0);
	 circle(1, 1, 1, 0.012 , -0.9, 0);
	 circle(1, 1, 1, 0.012 , -0.8, 0);
	 circle(1, 1, 1, 0.012 , -0.7, 0);
	 circle(1, 1, 1, 0.012 , -0.6, 0);
	 circle(1, 1, 1, 0.012 , -0.5, 0);

	 circle(1, 1, 1, 0.012 , -0.4, 0); //A18
	 circle(1, 1, 1, 0.012 , -0.3, 0);
	 circle(1, 1, 1, 0.012 , -0.2, 0);
	 circle(1, 1, 1, 0.012 , -0.1, 0);
	 circle(1, 1, 1, 0.012 , 0, 0);
	 circle(1, 1, 1, 0.012 , 0.1, 0);
	 circle(1, 1, 1, 0.012 , 0.2, 0);
	 circle(1, 1, 1, 0.012 , 0.3, 0);
	 circle(1, 1, 1, 0.012 , 0.4, 0);
	 circle(1, 1, 1, 0.012 , 0.5, 0);
	 circle(1, 1, 1, 0.012 , 0.6, 0);
	 circle(1, 1, 1, 0.012 , 0.7, 0);
	 circle(1, 1, 1, 0.012 , 0.8, 0);
	 circle(1, 1, 1, 0.012 , 0.9, 0);
	 circle(1, 1, 1, 0.012 , 1, 0);
	 circle(1, 1, 1, 0.012 , 1.1, 0);
	 circle(1, 1, 1, 0.012 , 1.2, 0);
	 circle(1, 1, 1, 0.012 , 1.3, 0);
	 circle(1, 1, 1, 0.012 , 1.4, 0);
	 circle(1, 1, 1, 0.012 , 1.5, 0);
 	 circle(1, 1, 1, 0.012 , -1.45, -0.1);
 	 circle(1, 1, 1, 0.012 , -1.34, -0.1);
 	 circle(1, 1, 1, 0.012 , -1.25, -0.1);
 	 circle(1, 1, 1, 0.012 , -1.16, -0.11);

 	 circle(1, 1, 1, 0.012 , -1.04, -0.1); //A19
 	 circle(1, 1, 1, 0.012 , -0.94, -0.1);
 	 circle(1, 1, 1, 0.012 , -0.87, -0.1);
 	 circle(1, 1, 1, 0.012 , -0.76, -0.1);
 	 circle(1, 1, 1, 0.012 , -0.65, -0.1);
 	 circle(1, 1, 1, 0.012 , -0.56, -0.1);
 	 circle(1, 1, 1, 0.012 , -0.46, -0.1);
 	 circle(1, 1, 1, 0.012 , -0.35, -0.1);
 	 circle(1, 1, 1, 0.012 , -0.26, -0.1);
 	 circle(1, 1, 1, 0.012 , -0.16, -0.1);
 	 circle(1, 1, 1, 0.012 , -0.05, -0.1);
 	 circle(1, 1, 1, 0.012 , 0.05, -0.1);
 	 circle(1, 1, 1, 0.012 , 0.15, -0.1);
 	 circle(1, 1, 1, 0.012 , 0.25, -0.1);
 	 circle(1, 1, 1, 0.012 , 0.34, -0.1);
 	 circle(1, 1, 1, 0.012 , 0.46, -0.1);
 	 circle(1, 1, 1, 0.012 , 0.55, -0.1);
 	 circle(1, 1, 1, 0.012 , 0.65, -0.1);
 	 circle(1, 1, 1, 0.012 , 0.75, -0.1);
 	 circle(1, 1, 1, 0.012 , 0.85, -0.1);
 	 circle(1, 1, 1, 0.012 , 0.95, -0.1);
 	 circle(1, 1, 1, 0.012 , 1.05, -0.1);
 	 circle(1, 1, 1, 0.012 , 1.15, -0.1);
 	 circle(1, 1, 1, 0.012 , 1.25, -0.1);

 	 circle(1, 1, 1, 0.012 , 1.35, -0.1); //A20
 	 circle(1, 1, 1, 0.012 , 1.45, -0.1);
 	 circle(1, 1, 1, 0.012 , -1.4, -0.2);
 	 circle(1, 1, 1, 0.012 , -1.3, -0.2);
 	 circle(1, 1, 1, 0.012 , -1.2, -0.2);
 	 circle(1, 1, 1, 0.012 , -1.1, -0.2);
	 circle(1, 1, 1, 0.012 , -1, -0.2);
 	 circle(1, 1, 1, 0.012 , -0.9, -0.2);
 	 circle(1, 1, 1, 0.012 , -0.8, -0.2);
 	 circle(1, 1, 1, 0.012 , -0.7, -0.2);
 	 circle(1, 1, 1, 0.012 , -0.6, -0.2);
 	 circle(1, 1, 1, 0.012 , -0.5, -0.2);
 	 circle(1, 1, 1, 0.012 , -0.4, -0.2);
 	 circle(1, 1, 1, 0.012 , -0.3, -0.2);
 	 circle(1, 1, 1, 0.012 , -0.2, -0.2);
 	 circle(1, 1, 1, 0.012 , -0.1, -0.2);
	 circle(1, 1, 1, 0.012 , 0, -0.2);
 	 circle(1, 1, 1, 0.012 , 0.1, -0.2);
 	 circle(1, 1, 1, 0.012 , 0.2, -0.2);
 	 circle(1, 1, 1, 0.012 , 0.3, -0.2);
 	 circle(1, 1, 1, 0.012 , 0.4, -0.2);
 	 circle(1, 1, 1, 0.012 , 0.5, -0.2);
 	 circle(1, 1, 1, 0.012 , 0.6, -0.2);
 	 circle(1, 1, 1, 0.012 , 0.7, -0.2);

 	 circle(1, 1, 1, 0.012 , 0.8, -0.2); //A21
 	 circle(1, 1, 1, 0.012 , 0.9, -0.2);
	 circle(1, 1, 1, 0.012 , 1, -0.2);
 	 circle(1, 1, 1, 0.012 , 1.1, -0.2);
 	 circle(1, 1, 1, 0.012 , 1.2, -0.2);
 	 circle(1, 1, 1, 0.012 , 1.3, -0.2);
 	 circle(1, 1, 1, 0.012 , 1.4, -0.2);
	 circle(1, 1, 1, 0.012 , 1.5, -0.2);
 	 circle(1, 1, 1, 0.012 , -1.45, -0.3);
 	 circle(1, 1, 1, 0.012 , -1.35, -0.3);
 	 circle(1, 1, 1, 0.012 , -1.25, -0.3);
 	 circle(1, 1, 1, 0.012 , -1.15, -0.3);
 	 circle(1, 1, 1, 0.012 , -1.05, -0.3);
 	 circle(1, 1, 1, 0.012 , -0.95, -0.3);
 	 circle(1, 1, 1, 0.012 , -0.85, -0.3);
 	 circle(1, 1, 1, 0.012 , -0.75, -0.3);
 	 circle(1, 1, 1, 0.012 , -0.65, -0.3);
 	 circle(1, 1, 1, 0.012 , -0.55, -0.3);
 	 circle(1, 1, 1, 0.012 , -0.45, -0.3);
 	 circle(1, 1, 1, 0.012 , -0.35, -0.3);
 	 circle(1, 1, 1, 0.012 , -0.25, -0.3);
 	 circle(1, 1, 1, 0.012 , -0.15, -0.3);
 	 circle(1, 1, 1, 0.012 , -0.05, -0.3);
 	 circle(1, 1, 1, 0.012 , 0.05, -0.3);

 	 circle(1, 1, 1, 0.012 , 0.15, -0.3); //A22
 	 circle(1, 1, 1, 0.012 , 0.25, -0.3);
 	 circle(1, 1, 1, 0.012 , 0.35, -0.3);
 	 circle(1, 1, 1, 0.012 , 0.45, -0.3);
 	 circle(1, 1, 1, 0.012 , 0.55, -0.3);
 	 circle(1, 1, 1, 0.012 , 0.65, -0.3);
 	 circle(1, 1, 1, 0.012 , 0.75, -0.3);
 	 circle(1, 1, 1, 0.012 , 0.85, -0.3);
 	 circle(1, 1, 1, 0.012 , 0.95, -0.3);
 	 circle(1, 1, 1, 0.012 , 1.05, -0.3);
 	 circle(1, 1, 1, 0.012 , 1.15, -0.3);
 	 circle(1, 1, 1, 0.012 , 1.25, -0.3);
 	 circle(1, 1, 1, 0.012 , 1.35, -0.3);
 	 circle(1, 1, 1, 0.012 , 1.45, -0.3);
 	 circle(1, 1, 1, 0.012 , -1.4, -0.4);
 	 circle(1, 1, 1, 0.012 , -1.3, -0.4);
 	 circle(1, 1, 1, 0.012 , -1.2, -0.4);
 	 circle(1, 1, 1, 0.012 , -1.1, -0.4);
	 circle(1, 1, 1, 0.012 , -1, -0.4);
 	 circle(1, 1, 1, 0.012 , -0.9, -0.4);
 	 circle(1, 1, 1, 0.012 , -0.8, -0.4);
 	 circle(1, 1, 1, 0.012 , -0.7, -0.4);
 	 circle(1, 1, 1, 0.012 , -0.6, -0.4);
 	 circle(1, 1, 1, 0.012 , -0.5, -0.4);

 	 circle(1, 1, 1, 0.012 , -0.4, -0.4); //A23
 	 circle(1, 1, 1, 0.012 , -0.3, -0.4);
 	 circle(1, 1, 1, 0.012 , -0.2, -0.4);
 	 circle(1, 1, 1, 0.012 , -0.1, -0.4);
	 circle(1, 1, 1, 0.012 , 0, -0.4);
 	 circle(1, 1, 1, 0.012 , 0.1, -0.4);
 	 circle(1, 1, 1, 0.012 , 0.2, -0.4);
 	 circle(1, 1, 1, 0.012 , 0.3, -0.4);
 	 circle(1, 1, 1, 0.012 , 0.4, -0.4);
 	 circle(1, 1, 1, 0.012 , 0.5, -0.4);
 	 circle(1, 1, 1, 0.012 , 0.6, -0.4);
 	 circle(1, 1, 1, 0.012 , 0.7, -0.4);
 	 circle(1, 1, 1, 0.012 , 0.8, -0.4);
 	 circle(1, 1, 1, 0.012 , 0.9, -0.4);
	 circle(1, 1, 1, 0.012 , 1, -0.4);
 	 circle(1, 1, 1, 0.012 , 1.1, -0.4);
 	 circle(1, 1, 1, 0.012 , 1.2, -0.4);
 	 circle(1, 1, 1, 0.012 , 1.3, -0.4);
 	 circle(1, 1, 1, 0.012 , 1.4, -0.4);
	 circle(1, 1, 1, 0.012 , 1.5, -0.4);
 	 circle(1, 1, 1, 0.012 , -1.45, -0.5);
 	 circle(1, 1, 1, 0.012 , -1.35, -0.5);
 	 circle(1, 1, 1, 0.012 , -1.25, -0.5);
 	 circle(1, 1, 1, 0.012 , -1.15, -0.5);

 	 circle(1, 1, 1, 0.012 , -1.05, -0.5); //A24
 	 circle(1, 1, 1, 0.012 , -0.95, -0.5);
 	 circle(1, 1, 1, 0.012 , -0.85, -0.5);
 	 circle(1, 1, 1, 0.012 , -0.75, -0.5);
 	 circle(1, 1, 1, 0.012 , -0.65, -0.5);
 	 circle(1, 1, 1, 0.012 , -0.55, -0.5);
 	 circle(1, 1, 1, 0.012 , -0.45, -0.5);
 	 circle(1, 1, 1, 0.012 , -0.35, -0.5);
 	 circle(1, 1, 1, 0.012 , -0.25, -0.5);
 	 circle(1, 1, 1, 0.012 , -0.15, -0.5);
 	 circle(1, 1, 1, 0.012 , -0.05, -0.5);
 	 circle(1, 1, 1, 0.012 , 0.05, -0.5);
 	 circle(1, 1, 1, 0.012 , 0.15, -0.5);
 	 circle(1, 1, 1, 0.012 , 0.25, -0.5);
 	 circle(1, 1, 1, 0.012 , 0.35, -0.5);
 	 circle(1, 1, 1, 0.012 , 0.45, -0.5);
 	 circle(1, 1, 1, 0.012 , 0.55, -0.5);
 	 circle(1, 1, 1, 0.012 , 0.65, -0.5);
 	 circle(1, 1, 1, 0.012 , 0.75, -0.5);
 	 circle(1, 1, 1, 0.012 , 0.85, -0.5);
 	 circle(1, 1, 1, 0.012 , 0.95, -0.5);
 	 circle(1, 1, 1, 0.012 , 1.05, -0.5);
 	 circle(1, 1, 1, 0.012 , 1.15, -0.5);
 	 circle(1, 1, 1, 0.012 , 1.25, -0.5);

 	 circle(1, 1, 1, 0.012 , 1.35, -0.5); //A25
 	 circle(1, 1, 1, 0.012 , 1.45, -0.5);
 	 circle(1, 1, 1, 0.012 , -1.4, -0.6);
 	 circle(1, 1, 1, 0.012 , -1.3, -0.6);
 	 circle(1, 1, 1, 0.012 , -1.2, -0.6);
 	 circle(1, 1, 1, 0.012 , -1.1, -0.6);
	 circle(1, 1, 1, 0.012 , -1, -0.6);
 	 circle(1, 1, 1, 0.012 , -0.9, -0.6);
 	 circle(1, 1, 1, 0.012 , -0.81, -0.6);
 	 circle(1, 1, 1, 0.012 , -0.7, -0.6);
 	 circle(1, 1, 1, 0.012 , -0.6, -0.6);
 	 circle(1, 1, 1, 0.012 , -0.5, -0.6);
 	 circle(1, 1, 1, 0.012 , -0.4, -0.6);
 	 circle(1, 1, 1, 0.012 , -0.3, -0.6);
 	 circle(1, 1, 1, 0.012 , -0.2, -0.6);
 	 circle(1, 1, 1, 0.012 , -0.1, -0.6);
	 circle(1, 1, 1, 0.012 , 0, -0.6);
 	 circle(1, 1, 1, 0.012 , 0.1, -0.6);
 	 circle(1, 1, 1, 0.012 , 0.2, -0.6);
 	 circle(1, 1, 1, 0.012 , 0.3, -0.6);
 	 circle(1, 1, 1, 0.012 , 0.4, -0.6);
 	 circle(1, 1, 1, 0.012 , 0.5, -0.6);
 	 circle(1, 1, 1, 0.012 , 0.6, -0.6);
 	 circle(1, 1, 1, 0.012 , 0.7, -0.6);

 	 circle(1, 1, 1, 0.012 , 0.8, -0.6); //A26
 	 circle(1, 1, 1, 0.012 , 0.9, -0.6);
	 circle(1, 1, 1, 0.012 , 1, -0.6);
 	 circle(1, 1, 1, 0.012 , 1.1, -0.6);
 	 circle(1, 1, 1, 0.012 , 1.2, -0.6);
 	 circle(1, 1, 1, 0.012 , 1.3, -0.6);
 	 circle(1, 1, 1, 0.012 , 1.4, -0.6);
	 circle(1, 1, 1, 0.012 , 1.5, -0.6);
 	 circle(1, 1, 1, 0.012 , -1.45, -0.7);
 	 circle(1, 1, 1, 0.012 , -1.35, -0.7);
 	 circle(1, 1, 1, 0.012 , -1.25, -0.7);
 	 circle(1, 1, 1, 0.012 , -1.15, -0.7);
 	 circle(1, 1, 1, 0.012 , -1.05, -0.7);
 	 circle(1, 1, 1, 0.012 , -0.95, -0.7);
 	 circle(1, 1, 1, 0.012 , -0.85, -0.7);
 	 circle(1, 1, 1, 0.012 , -0.75, -0.7);
 	 circle(1, 1, 1, 0.012 , -0.65, -0.7);
 	 circle(1, 1, 1, 0.012 , -0.55, -0.7);
 	 circle(1, 1, 1, 0.012 , -0.45, -0.7);
 	 circle(1, 1, 1, 0.012 , -0.35, -0.7);
 	 circle(1, 1, 1, 0.012 , -0.25, -0.7);
 	 circle(1, 1, 1, 0.012 , -0.15, -0.7);
 	 circle(1, 1, 1, 0.012 , -0.05, -0.7);
 	 circle(1, 1, 1, 0.012 , 0.05, -0.7);

 	 circle(1, 1, 1, 0.012 , 0.15, -0.7); //A27
 	 circle(1, 1, 1, 0.012 , 0.25, -0.7);
 	 circle(1, 1, 1, 0.012 , 0.35, -0.7);
 	 circle(1, 1, 1, 0.012 , 0.45, -0.7);
 	 circle(1, 1, 1, 0.012 , 0.55, -0.7);
 	 circle(1, 1, 1, 0.012 , 0.65, -0.7);
 	 circle(1, 1, 1, 0.012 , 0.75, -0.7);
 	 circle(1, 1, 1, 0.012 , 0.85, -0.7);
 	 circle(1, 1, 1, 0.012 , 0.95, -0.7);
 	 circle(1, 1, 1, 0.012 , 1.05, -0.7);
 	 circle(1, 1, 1, 0.012 , 1.15, -0.7);
 	 circle(1, 1, 1, 0.012 , 1.25, -0.7);
 	 circle(1, 1, 1, 0.012 , 1.35, -0.7);
 	 circle(1, 1, 1, 0.012 , 1.45, -0.7);
 	 circle(1, 1, 1, 0.012 , -1.4, -0.8);
 	 circle(1, 1, 1, 0.012 , -1.3, -0.8);
 	 circle(1, 1, 1, 0.012 , -1.2, -0.8);
 	 circle(1, 1, 1, 0.012 , -1.1, -0.8);
	 circle(1, 1, 1, 0.012 , -1, -0.8);
 	 circle(1, 1, 1, 0.012 , -0.9, -0.8);
 	 circle(1, 1, 1, 0.012 , -0.8, -0.8);
 	 circle(1, 1, 1, 0.012 , -0.7, -0.8);
 	 circle(1, 1, 1, 0.012 , -0.6, -0.8);
 	 circle(1, 1, 1, 0.012 , -0.5, -0.8);

 	 circle(1, 1, 1, 0.012 , -0.4, -0.8); //A28
 	 circle(1, 1, 1, 0.012 , -0.3, -0.8);
 	 circle(1, 1, 1, 0.012 , -0.2, -0.8);
 	 circle(1, 1, 1, 0.012 , -0.1, -0.8);
	 circle(1, 1, 1, 0.012 , 0, -0.8);
 	 circle(1, 1, 1, 0.012 , 0.1, -0.8);
 	 circle(1, 1, 1, 0.012 , 0.2, -0.8);
 	 circle(1, 1, 1, 0.012 , 0.3, -0.8);
 	 circle(1, 1, 1, 0.012 , 0.4, -0.8);
 	 circle(1, 1, 1, 0.012 , 0.51, -0.8);
 	 circle(1, 1, 1, 0.012 , 0.6, -0.8);
 	 circle(1, 1, 1, 0.012 , 0.7, -0.8);
 	 circle(1, 1, 1, 0.012 , 0.8, -0.8);
 	 circle(1, 1, 1, 0.012 , 0.9, -0.8);
	 circle(1, 1, 1, 0.012 , 1, -0.8);
 	 circle(1, 1, 1, 0.012 , 1.1, -0.8);
 	 circle(1, 1, 1, 0.012 , 1.2, -0.8);
 	 circle(1, 1, 1, 0.012 , 1.3, -0.8);
 	 circle(1, 1, 1, 0.012 , 1.4, -0.8);
 	 circle(1, 1, 1, 0.012 , -1.45, -0.9);
 	 circle(1, 1, 1, 0.012 , -1.35, -0.9);
 	 circle(1, 1, 1, 0.012 , -1.25, -0.9);
 	 circle(1, 1, 1, 0.012 , -1.15, -0.9);
 	 circle(1, 1, 1, 0.012 , -1.05, -0.9);

 	 circle(1, 1, 1, 0.012 , -0.95, -0.9); //A29
 	 circle(1, 1, 1, 0.012 , -0.85, -0.9);
 	 circle(1, 1, 1, 0.012 , -0.75, -0.9);
 	 circle(1, 1, 1, 0.012 , -0.65, -0.9);
 	 circle(1, 1, 1, 0.012 , -0.55, -0.9);
 	 circle(1, 1, 1, 0.012 , -0.45, -0.9);
 	 circle(1, 1, 1, 0.012 , -0.35, -0.9);
 	 circle(1, 1, 1, 0.012 , -0.25, -0.9);
 	 circle(1, 1, 1, 0.012 , -0.15, -0.9);
 	 circle(1, 1, 1, 0.012 , -0.05, -0.9);
 	 circle(1, 1, 1, 0.012 , 0.05, -0.9);
 	 circle(1, 1, 1, 0.012 , 0.15, -0.9);
 	 circle(1, 1, 1, 0.012 , 0.25, -0.9);
 	 circle(1, 1, 1, 0.012 , 0.35, -0.9);
 	 circle(1, 1, 1, 0.012 , 0.45, -0.9);
 	 circle(1, 1, 1, 0.012 , 0.55, -0.9);
 	 circle(1, 1, 1, 0.012 , 0.65, -0.9);
 	 circle(1, 1, 1, 0.012 , 0.75, -0.9);
 	 circle(1, 1, 1, 0.012 , 0.85, -0.9);
 	 circle(1, 1, 1, 0.012 , 0.95, -0.9);
 	 circle(1, 1, 1, 0.012 , 1.05, -0.9);
 	 circle(1, 1, 1, 0.012 , 1.15, -0.9);
 	 circle(1, 1, 1, 0.012 , 1.25, -0.9);
 	 circle(1, 1, 1, 0.012 , 1.35, -0.9);

 	 circle(1, 1, 1, 0.012 , 1.45, -0.9); //A30
	 circle(1, 1, 1, 0.012 , -1.4, -1);
	 circle(1, 1, 1, 0.012 , -1.3, -1);
	 circle(1, 1, 1, 0.012 , -1.2, -1);
	 circle(1, 1, 1, 0.012 , -1.1, -1);
	 circle(1, 1, 1, 0.012 , -1, -1);
	 circle(1, 1, 1, 0.012 , -0.9, -1);
	 circle(1, 1, 1, 0.012 , -0.8, -1);
	 circle(1, 1, 1, 0.012 , -0.7, -1);
	 circle(1, 1, 1, 0.012 , -0.6, -1);
	 circle(1, 1, 1, 0.012 , -0.5, -1);
	 circle(1, 1, 1, 0.012 , -0.4, -1);
	 circle(1, 1, 1, 0.012 , -0.3, -1);
	 circle(1, 1, 1, 0.012 , -0.2, -1);
	 circle(1, 1, 1, 0.012 , -0.1, -1);
	 circle(1, 1, 1, 0.012 , 0, -1);
	 circle(1, 1, 1, 0.012 , 0.1, -1);
	 circle(1, 1, 1, 0.012 , 0.2, -1);
	 circle(1, 1, 1, 0.012 , 0.3, -1);
	 circle(1, 1, 1, 0.012 , 0.4, -1);
	 circle(1, 1, 1, 0.012 , 0.5, -1);
	 circle(1, 1, 1, 0.012 , 0.6, -1);
	 circle(1, 1, 1, 0.012 , 0.7, -1);
	 circle(1, 1, 1, 0.012 , 0.8, -1);

	 circle(1, 1, 1, 0.012 , 0.9, -1); //A31
	 circle(1, 1, 1, 0.012 , 1, -1);
	 circle(1, 1, 1, 0.012 , 1.1, -1);
	 circle(1, 1, 1, 0.012 , 1.2, -1);
	 circle(1, 1, 1, 0.012 , 1.3, -1);
	 circle(1, 1, 1, 0.012 , 1.4, -1);
	 circle(1, 1, 1, 0.012 , 1.5, -1);
 	 circle(1, 1, 1, 0.012 , -1.45, -1.1);
 	 circle(1, 1, 1, 0.012 , -1.35, -1.1);
 	 circle(1, 1, 1, 0.012 , -1.25, -1.1);
 	 circle(1, 1, 1, 0.012 , -1.15, -1.1);
 	 circle(1, 1, 1, 0.012 , -1.05, -1.1);
 	 circle(1, 1, 1, 0.012 , -0.95, -1.1);
 	 circle(1, 1, 1, 0.012 , -0.85, -1.1);
 	 circle(1, 1, 1, 0.012 , -0.75, -1.1);
 	 circle(1, 1, 1, 0.012 , -0.65, -1.1);
 	 circle(1, 1, 1, 0.012 , -0.55, -1.1);
 	 circle(1, 1, 1, 0.012 , -0.45, -1.1);
 	 circle(1, 1, 1, 0.012 , -0.35, -1.1);
 	 circle(1, 1, 1, 0.012 , -0.25, -1.1);
 	 circle(1, 1, 1, 0.012 , -0.15, -1.1);
 	 circle(1, 1, 1, 0.012 , -0.05, -1.1);
 	 circle(1, 1, 1, 0.012 , 0.05, -1.1);
 	 circle(1, 1, 1, 0.012 , 0.15, -1.1);

 	 circle(1, 1, 1, 0.012 , 0.25, -1.1); //A32
 	 circle(1, 1, 1, 0.012 , 0.35, -1.1);
 	 circle(1, 1, 1, 0.012 , 0.45, -1.1);
 	 circle(1, 1, 1, 0.012 , 0.55, -1.1);
 	 circle(1, 1, 1, 0.012 , 0.65, -1.1);
 	 circle(1, 1, 1, 0.012 , 0.75, -1.1);
 	 circle(1, 1, 1, 0.012 , 0.85, -1.1);
 	 circle(1, 1, 1, 0.012 , 0.95, -1.1);
 	 circle(1, 1, 1, 0.012 , 1.05, -1.1);
 	 circle(1, 1, 1, 0.012 , 1.15, -1.1);
 	 circle(1, 1, 1, 0.012 , 1.25, -1.1);
 	 circle(1, 1, 1, 0.012 , 1.35, -1.1);
 	 circle(1, 1, 1, 0.012 , 1.45, -1.1);
  	 circle(1, 1, 1, 0.012 , -1.4, -1.2);
  	 circle(1, 1, 1, 0.012 , -1.3, -1.2);
 	 circle(1, 1, 1, 0.012 , -1.2, -1.2);
 	 circle(1, 1, 1, 0.012 , -1.1, -1.2);
	 circle(1, 1, 1, 0.012 , -1, -1.2);
  	 circle(1, 1, 1, 0.012 , -0.9, -1.2);
 	 circle(1, 1, 1, 0.012 , -0.8, -1.2);
  	 circle(1, 1, 1, 0.012 , -0.7, -1.2);
  	 circle(1, 1, 1, 0.012 , -0.6, -1.2);
  	 circle(1, 1, 1, 0.012 , -0.5, -1.2);
  	 circle(1, 1, 1, 0.012 , -0.4, -1.2);

  	 circle(1, 1, 1, 0.012 , -0.3, -1.2); //A33
 	 circle(1, 1, 1, 0.012 , -0.2, -1.2);
 	 circle(1, 1, 1, 0.012 , -0.1, -1.2);
	 circle(1, 1, 1, 0.012 , 0, -1.2);
  	 circle(1, 1, 1, 0.012 , 0.1, -1.2);
 	 circle(1, 1, 1, 0.012 , 0.2, -1.2);
 	 circle(1, 1, 1, 0.012 , 0.3, -1.2);
  	 circle(1, 1, 1, 0.012 , 0.4, -1.2);
  	 circle(1, 1, 1, 0.012 , 0.5, -1.2);
  	 circle(1, 1, 1, 0.012 , 0.6, -1.2);
  	 circle(1, 1, 1, 0.012 , 0.7, -1.2);
  	 circle(1, 1, 1, 0.012 , 0.8, -1.2);
  	 circle(1, 1, 1, 0.012 , 0.9, -1.2);
	 circle(1, 1, 1, 0.012 , 1, -1.2);
 	 circle(1, 1, 1, 0.012 , 1.1, -1.2);
  	 circle(1, 1, 1, 0.012 , 1.2, -1.2);
 	 circle(1, 1, 1, 0.012 , 1.3, -1.2);
  	 circle(1, 1, 1, 0.012 , 1.4, -1.2);

  	 glPopMatrix();

}



void aurora()
{
    //cyan
    quadsgradTransparent (0.467, 0.839, 0.694, 0.6 , 0.7, 0.79 ,  0.92, 0.85  , 0.88, 1.02   ,  0.65, 0.94 , 0.467, 0.839, 0.694, 0.01);
    quadsgradTransparent (0.467, 0.839, 0.694, 0.6, 0.7, 0.79  , 0.75, 0.74  ,  0.71, 0.92   , 0.65, 0.94, 0.467, 0.839, 0.694, 0.01);
    quadsgradTransparent(0.467, 0.839, 0.694, 0.6, 0.05, 0.63 ,  0.75, 0.74 , 0.71, 0.92  , 0.01, 0.79 ,0.467, 0.839, 0.694, 0.01);
    triangle(0.467, 0.839, 0.694, 0.03, 0.59  , 0.05, 0.63  , 0.022, 0.74  );


    //cyan
    quadsgradTransparent(0.627, 0.851, 0.624, 0.6,  0.26, 0.65 , 0.92, 0.67  ,0.92, 0.79   , 0.26, 0.77 , 0.627, 0.851, 0.624, 0.01 );


    //green
    quadsgradTransparent(0.737, 0.929, 0.58, 0.6, 0.25, 0.94  , 0.39, 0.98  , 0.36, 1.08  , 0.21, 1.05, 0.737, 0.929, 0.58, 0.01 );
    quadsgradTransparent(0.737, 0.929, 0.58, 0.6, 0.25, 0.94 , 0.3, 0.88  , 0.28, 1.01  , 0.21, 1.05, 0.737, 0.929, 0.58, 0.01 );
    quadsgradTransparent(0.737, 0.929, 0.58, 0.6,-0.49, 0.75  ,0.3, 0.88  ,0.28, 1.01  , -0.53, 0.88, 0.737, 0.929, 0.58, 0.01 );
    triangle(0.737, 0.929, 0.58, -0.52, 0.71 , -0.47, 0.71 ,-0.53, 0.88 );


    //blue
    quadsgradTransparent(0.494, 0.71, 0.859, 0.6,  -0.91, 0.56 , -0.53, 0.63  , -0.56, 0.75  ,-0.96, 0.68 , 0.494, 0.71, 0.859, 0.01 );
    quadsgradTransparent(0.494, 0.71, 0.859, 0.6 , -0.6, 0.56   ,-0.53, 0.63   , -0.56, 0.75  , -0.63, 0.67, 0.494, 0.71, 0.859, 0.01 );
    quadsgradTransparent(0.494, 0.71, 0.859, 0.6,  -0.6, 0.56  ,-0.03, 0.66   , -0.06, 0.78  , -0.63, 0.67, 0.494, 0.71, 0.859, 0.01 );


}





void skyWinterMorning()
{

    quadsgrad(0.682, 0.749, 0.886, -1, 0.4, 1, 0.4,  1, 1, -1, 1, 0.518, 0.855, 0.984);

}


void skyWinterNight()
{

    quadsgrad(0.722, 0.925, 0.973, -1, 0.4, 1, 0.4,  1, 1, -1, 1, 0.18, 0.196, 0.329);

}








void WinterHill1()
{
    polygon (0.792, 0.961, 1,  -1, 0.48,-1,0.4,-.58,0.4,-.7,0.53,-0.92,0.52);
    triangle(0.792, 0.961, 1,  -0.92, 0.52,-0.68, 0.52,-0.83, 0.57);
}






void WinterHill2()
{
    quads   (0.122, 0.216, 0.596,   -0.8, 0.5,-0.49, 0.45,-0.62, 0.6,-0.72, 0.6);
    triangle(0.122, 0.216, 0.596,   -0.72, 0.6,-0.62, 0.6,-0.67, 0.65);
}





void WinterHill3()
{
    triangle(0.431, 0.698, 0.827,   -0.57, 0.54,-0.45, 0.54,-0.5, 0.57);
    polygon (0.431, 0.698, 0.827,   -0.67, 0.49, -0.58, 0.4,-0.25, 0.4,-0.45, 0.54,-0.57,0.54);
}







void WinterHill4()
{
    quads(0.941, 0.969, 0.992,  -0.28, 0.55,-0.4, 0.5,-0.25, 0.4,-0.19, 0.52);
}





void WinterHill5()
{
    quads(0.608, 0.855, 0.933,   -0.11, 0.52,-0.31, 0.44,-0.25, 0.4,0.12, 0.4);
}






void WinterHill6()
{
    quads(0.247, 0.435, 0.647,   0.09, 0.61,-0.19, 0.52,-0.25, 0.4,0.3, 0.4);
}





void WinterHill7()
{
    quads(0.404, 0.675, 0.804,  0.28, 0.69, 0.13, 0.57, 0.27, 0.43, 0.37, 0.53);
}






void WinterHill8()
{
    triangle(0.682, 0.898, 0.941,  0.39, 0.68, 0.28, 0.54, 0.5, 0.48);
}







void WinterHill9()
{
    quads(0.949, 0.973, 0.988,   0.52, 0.7, 0.27, 0.43, 0.3, 0.4, 0.61, 0.4);
}






void WinterHill10()
{
    polygon(0.384, 0.851, 0.965, 0.64, 0.67,  0.5, 0.5,  0.61, 0.4, 1, 0.4, 1, 0.46);
}



void WinterHill11()
{
    quads(0.212, 0.212, 0.706,  0.95, 0.64, 0.76, 0.59, 1, 0.46, 1, 0.6);

}





void landWinterMorning()
{

    quads(  0.71, 0.824, 1,  -1, 0.35, -0.5, 0.38, -0.5, 0.4, -1, 0.4);
    quads(  0.71, 0.824, 1, -0.5, 0.38,0, 0.36,   0, 0.4, -0.5, 0.4);
    quads(  0.71, 0.824, 1,  0, 0.36, 0.4, 0.38, 0.4, 0.4, 0, 0.4);
triangle(0.71, 0.824, 1,  0.4, 0.38,  0.65, 0.4,  0.4, 0.4  );
    quads(  0.71, 0.824, 1, 0.65, 0.4, 0.62, 0.4,  1, 0.38,  1, 0.4);


}



void landWinterNight()
{

    quads(   0.424, 0.49, 0.773,  -1, 0.35, -0.5, 0.38, -0.5, 0.4, -1, 0.4);
    quads(   0.424, 0.49, 0.773,  -0.5, 0.38,0, 0.36,   0, 0.4, -0.5, 0.4);
    quads(   0.424, 0.49, 0.773,  0, 0.36, 0.4, 0.38, 0.4, 0.4, 0, 0.4);
    triangle(0.424, 0.49, 0.773,  0.4, 0.38,  0.65, 0.4,  0.4, 0.4  );
    quads(   0.424, 0.49, 0.773,  0.65, 0.4, 0.62, 0.4,  1, 0.38,  1, 0.4);


}




void MorningRoadsideWinter ()
{
    quadsgrad(0.812, 0.925, 0.984, -1, -1,  1, -1,  1, -0.8,  -1, -0.8, 1,1, 1 );

}































void DisplayWinterDay() //#####################################################################################
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    skyWinterMorning();
    riverMorning();



    rainCloud1();
    rainCloud2();
    rainCloud3();
    rainCloud4();
    rainCloud5();
    rainCloud6();
    rainCloud7();
    rainCloud8();
    rainCloud9();
    rainCloud10();
    rainCloud11();
    rainCloud12();
    rainCloud13();
    rainCloud14();
    rainCloud15();
    rainCloud16();
    rainCloud17();



    landWinterMorning();



    WinterHill2(); // in the back of hill 1 and 3
    WinterHill1();
    WinterHill3();

    WinterHill4();
    WinterHill6(); // behind hill 5
    WinterHill5();

    WinterHill8(); // behind hill 9
    WinterHill7();

    WinterHill11(); // behind hill 10
    WinterHill10(); // behind hill 9

    WinterHill9();









    LAChrisTree1();
    LAChrisTree2();
    LAChrisTree3();
    LAChrisTree4();



    LACocoTree1();
    LACocoTree2();
    LACocoTree3();


    LAPineTree1();
    LAPineTree2();
    LAPineTree3();



    boat2();
    boat1();


    buildingBack();



    building7(); // behind building 1 and 2
    building1();
    building2();
    building3();

    building8(); // behind building 5
    building5();

    building9(); // behind building 6
    building10(); //behind building 6
    building6();

    building11();
    building12();

    building16(); //behind building 15 and 17
    building15();
    building17();




    MorningRoad();

    // car Right to Left
    MorningCar1();
    MorningCar2();
    MorningCar3();
    MorningCar4();




    // car Left to Right
     MorningCar5();
     MorningCar6();
     MorningCar7();
     MorningCar8();


    MorningRoadsideWinter();
     MorningRoadsideGrassLA();

     snow();



    glFlush();  // Render now

    glPopMatrix();
}







void DisplayWinterNight() //#####################################################################################
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    skyWinterNight();
    riverNight();



    rainCloud1();
    rainCloud2();
    rainCloud3();
    rainCloud4();
    rainCloud5();
    rainCloud6();
    rainCloud7();
    rainCloud8();
    rainCloud9();
    rainCloud10();
    rainCloud11();
    rainCloud12();
    rainCloud13();
    rainCloud14();
    rainCloud15();
    rainCloud16();
    rainCloud17();


    aurora();





    landWinterNight();


    WinterHill2(); // in the back of hill 1 and 3
    WinterHill1();
    WinterHill3();

    WinterHill4();
    WinterHill6(); // behind hill 5
    WinterHill5();

    WinterHill8(); // behind hill 9
    WinterHill7();

    WinterHill11(); // behind hill 10
    WinterHill10(); // behind hill 9

    WinterHill9();









    LAChrisTree1();
    LAChrisTree2();
    LAChrisTree3();
    LAChrisTree4();



    LACocoTree1();
    LACocoTree2();
    LACocoTree3();


    LAPineTree1();
    LAPineTree2();
    LAPineTree3();


    Nightboat2();
    Nightboat1();


    buildingBack();



    buildingNight7(); // behind building 1 and 2
    buildingNight1();
    buildingNight2();
    buildingNight3();

    buildingNight8(); // behind building 5
    buildingNight5();

    buildingNight9(); // behind building 6
    buildingNight10(); //behind building 6
    buildingNight6();

    buildingNight11();
    buildingNight12();

    buildingNight16(); //behind building 15 and 17
    buildingNight15();
    buildingNight17();




    NightRoad();

    // car Right to Left
    NightCar1();
    NightCar2();
    NightCar3();
    NightCar4();




    // car Left to Right
     NightCar5();
     NightCar6();
     NightCar7();
     NightCar8();


     MorningRoadsideWinter();


     MorningRoadsideGrassLA();

    snow();


    glFlush();  // Render now

    glPopMatrix();
}





//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////






void skySpringMorning()
{

    quadsgrad(0.686, 0.871, 0.98, -1, 0.4, 1, 0.4,  1, 1, -1, 1, 0.463, 0.737, 0.922);

}


void skySpringNight()
{

    quadsgrad(0.812, 0.541, 0.953, -1, 0.4, 1, 0.4,  1, 1, -1, 1, 0.251, 0.251, 0.694);

}







void RoadsideGrassSpring ()
{
   // 1
    circle(0.298, 0.549, 0.275,   0.11  ,  -1.02, -0.98);


    //2
    circle(0.953, 0.557, 0.514,   0.1  ,  -0.8, -1);

    //3
    circle(1, 0.467, 0.451, 0.06  ,  -0.9, -1);

    //4
    circle(0.953, 0.557, 0.514 ,   0.02  ,  -0.68, -0.97 );
    circle(0.953, 0.557, 0.514 ,   0.03  ,  -0.7, -1);
    circle(0.953, 0.557, 0.514 ,   0.03  ,  -0.65, -1);


    //5
    polygon(0.776, 0.91, 0.753,   -0.62, -1 , -0.45, -1 ,  -0.4, -0.9  , -0.5, -0.95  , -0.5, -0.9);


   //-----------------------------------------------------------------------

   //Grass layer1
    polygon(0.376, 0.929, 0.282,    0.3, -1 , 0.5, -1 , 0.53, -0.87 , 0.45, -0.99 ,  0.46, -0.87);
    polygon(0.376, 0.929, 0.282,    0.5, -1 ,0.7, -1  , 0.73, -0.89 , 0.65, -0.94 ,0.64, -0.89  );
    polygon(0.376, 0.929, 0.282,    0.7, -1 , 0.9, -1 ,0.95, -0.9   ,0.86, -0.94  ,0.86, -0.87  );
    polygon(0.376, 0.929, 0.282,    0.9, -1 , 1, -1, 1.05, -0.9 , 0.98, -0.95 , 0.99, -0.89 );

    //Grass layer2
    polygon(0.776, 0.91, 0.753,    0.46, -1 , 0.58, -1 , 0.63, -0.91 , 0.55, -0.94 ,0.56, -0.87  );
    polygon(0.776, 0.91, 0.753,    0.66, -1 , 0.78, -1 , 0.82, -0.91 , 0.75, -0.97 ,0.75, -0.91  );



   //--------------------------------------------------------------------------

    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.7, 0.0f, 0.0f);

    //Grass layer1
    polygon(0.376, 0.929, 0.282,    0.3, -1 , 0.5, -1 , 0.53, -0.87 , 0.45, -0.99 ,  0.46, -0.87);
    polygon(0.376, 0.929, 0.282,    0.5, -1 ,0.7, -1  , 0.73, -0.89 , 0.65, -0.94 ,0.64, -0.89  );
    polygon(0.376, 0.929, 0.282,    0.7, -1 , 0.9, -1 ,0.95, -0.9   ,0.86, -0.94  ,0.86, -0.87  );
    polygon(0.376, 0.929, 0.282,    0.9, -1 , 1, -1, 1.05, -0.9 , 0.98, -0.95 , 0.99, -0.89 );

    //Grass layer2
    polygon(0.776, 0.91, 0.753,    0.46, -1 , 0.58, -1 , 0.63, -0.91 , 0.55, -0.94 ,0.56, -0.87  );
    polygon(0.776, 0.91, 0.753,    0.66, -1 , 0.78, -1 , 0.82, -0.91 , 0.75, -0.97 ,0.75, -0.91  );


    glPopMatrix();




}











void SpringPineTree1()
{
    triangle (0.902, 0.792, 0.812, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   ); //leafs

    quads(0.78, 0.533, 0.306, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  ); //log

}






void SpringPineTree2()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.12f, 0.0f, 0.0f);


    triangle (0.902, 0.792, 0.812, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   ); //leafs
    quads(0.78, 0.533, 0.306, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  ); //log

    glPopMatrix();

}






void SpringPineTree3()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.6f, 0.0f, 0.0f);


    triangle (0.902, 0.792, 0.812, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   ); //leafs
    quads(0.78, 0.533, 0.306, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  ); //log

    glPopMatrix();


}






void SpringNightPineTree1()
{
    triangle (0.788, 0.412, 0.478, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   ); //leafs

    quads(0.78, 0.533, 0.306, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  ); //log

}






void SpringNightPineTree2()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.12f, 0.0f, 0.0f);


    triangle (0.788, 0.412, 0.478, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   ); //leafs
    quads(0.78, 0.533, 0.306, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  ); //log

    glPopMatrix();

}






void SpringNightPineTree3()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.6f, 0.0f, 0.0f);


    triangle (0.788, 0.412, 0.478, -0.38, 0.44, -0.3, 0.44, -0.34, 0.54   ); //leafs
    quads(0.78, 0.533, 0.306, -0.35, 0.4,  -0.33, 0.4,  -0.335, 0.44,  -0.345, 0.44  ); //log

    glPopMatrix();


}






void FlowerRed1()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.0f, 0.1f, 0.0f);


    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();


}



void FlowerRed2()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.1f, 0.1f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed3()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.2f, 0.1f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed4()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.3f, 0.1f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed5()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.8f, 0.1f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed6()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.9f, 0.1f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed7()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.0f, 0.1f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed8()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.1f, 0.1f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed9()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.5f, 0.1f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed10()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.6f, 0.1f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed11()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.7f, 0.1f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed12()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.8f, 0.1f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerRed1a()
{

    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.0f, 0.0f, 0.0f);


    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();


}



void FlowerRed2a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.1f, 0.0f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed3a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.2f, 0.0f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed4a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.3f, 0.0f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed5a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.8f, 0.0f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed6a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.9f, 0.0f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed7a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.0f, 0.0f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed8a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.1f, 0.0f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed9a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.5f, 0.0f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed10a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.6f, 0.0f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed11a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.7f, 0.0f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerRed12a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.8f, 0.0f, 0.0f);

    circle(1,0,  0,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(1, 0, 0, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(1, 0, 0, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(1, 0, 0, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(1, 0, 0, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}





void AllRedFlowers()
{





     FlowerRed1();
     FlowerRed2();
     FlowerRed3();
     FlowerRed4();
     FlowerRed5();
     FlowerRed6();
     FlowerRed7();
     FlowerRed8();
     FlowerRed9();
     FlowerRed10();
     FlowerRed11();
     FlowerRed12();

     FlowerRed1a();
     FlowerRed2a();
     FlowerRed3a();
     FlowerRed4a();
     FlowerRed5a();
     FlowerRed6a();
     FlowerRed7a();
     FlowerRed8a();
     FlowerRed9a();
     FlowerRed10a();
     FlowerRed11a();
     FlowerRed12a();






}



void FlowerBlue1()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.1f, 0.1f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue2()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.2f, 0.1f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue3()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.3f, 0.1f, 0.0f);

    circle(0.494, 0.69, 0.937 , 0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue4()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.4f, 0.1f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue5()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.4f, 0.1f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue6()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.5f, 0.1f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue7()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.6f, 0.1f, 0.0f);

    circle(0.494, 0.69, 0.937 , 0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue8()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.7f, 0.1f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerBlue9()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.2f, 0.1f, 0.0f);

    circle(0.494, 0.69, 0.937 , 0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue10()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.3f, 0.1f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue1a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.1f, 0.0f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue2a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.2f, 0.0f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue3a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.3f, 0.0f, 0.0f);

    circle(0.494, 0.69, 0.937 , 0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue4a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(-0.4f, 0.0f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue5a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.4f, 0.0f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue6a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.5f, 0.0f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue7a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.6f, 0.0f, 0.0f);

    circle(0.494, 0.69, 0.937 , 0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue8a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(0.7f, 0.0f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}



void FlowerBlue9a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.2f, 0.0f, 0.0f);

    circle(0.494, 0.69, 0.937 , 0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}




void FlowerBlue10a()
{
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glTranslatef(1.3f, 0.0f, 0.0f);

    circle(0.494, 0.69, 0.937,  0.02, -0.28, -0.9  );
    line(0, 0, 0, -0.28, -0.9, -0.32, -0.98  , 2);

    triangle(0.494, 0.69, 0.937, -0.32, -0.9 , -0.28, -0.92 , -0.28, -0.88 );
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.28, -0.94 , -0.26, -0.9  );
    triangle(0.494, 0.69, 0.937, -0.28, -0.92 ,-0.24, -0.9  ,  -0.28, -0.88);
    triangle(0.494, 0.69, 0.937, -0.3, -0.9 , -0.26, -0.9 ,  -0.28, -0.86);

    circle(1,1,  0,  0.01, -0.28, -0.9  );

    glPopMatrix();

}









void AllBlueFlowers ()
{


    FlowerBlue1();
    FlowerBlue2();
    FlowerBlue3();
    FlowerBlue4();
    FlowerBlue5();
    FlowerBlue6();
    FlowerBlue7();
    FlowerBlue8();
    FlowerBlue9();
    FlowerBlue10();


    FlowerBlue1a();
    FlowerBlue2a();
    FlowerBlue3a();
    FlowerBlue4a();
    FlowerBlue5a();
    FlowerBlue6a();
    FlowerBlue7a();
    FlowerBlue8a();
    FlowerBlue9a();
    FlowerBlue10a();






}









void DisplaySpringDay () //###################################################################################################
{


    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    skySpringMorning();
    sun();

    //Clouds
    SuAuSpMorningCloud1();
    SuAuSpMorningCloud2();
    SuAuSpMorningCloud3();
    SuAuSpMorningCloud4();
    SuAuSpMorningCloud5();
    SuAuSpMorningCloud6();



    riverMorning();
    landMorning();



    SummerAutumnMorningHill2(); // in the back of hill 1 and 3
    SummerAutumnMorningHill1();
    SummerAutumnMorningHill3();

    SummerAutumnMorningHill4();
    SummerAutumnMorningHill6(); // behind hill 5
    SummerAutumnMorningHill5();

    SummerAutumnMorningHill8(); // behind hill 9
    SummerAutumnMorningHill7();

    SummerAutumnMorningHill11(); // behind hill 10
    SummerAutumnMorningHill10(); // behind hill 9


    SummerAutumnMorningHill9();









    SuAuMorningChrisTree1();
    SuAuMorningChrisTree2();
    SuAuMorningChrisTree3();
    SuAuMorningChrisTree4();

    cocoTree1();
    cocoTree2();
    cocoTree3();

    SpringPineTree1();
    SpringPineTree2();
    SpringPineTree3();


    boat2();
    boat1();

    buildingBack();

    building7(); // behind building 1 and 2
    building1();
    building2();
    building3();



    building8(); // behind building 5
    building5();



    building9(); // behind building 6
    building10(); //behind building 6
    building6();

    building11();
    building12();



    building16(); //behind building 15 and 17
    building15();
    building17();







    MorningRoad();

    // car Right to Left
    MorningCar1();
    MorningCar2();
    MorningCar3();
    MorningCar4();




    // car Left to Right
     MorningCar5();
     MorningCar6();
     MorningCar7();
     MorningCar8();


     MorningRoadside();




     AllRedFlowers();
     AllBlueFlowers();

    RoadsideGrassSpring();


    glFlush();  // Render now

    glPopMatrix();



}




void DisplaySpringNight()   //####################################################################################################
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Set background color and opacity
    glClear(GL_COLOR_BUFFER_BIT);   // Clear the color buffer with current clearing color

    skySpringNight();
    riverNight();

    moonfull();

    AutumnSpringNightCloud1();
    AutumnSpringNightCloud2();
    AutumnSpringNightCloud3();
    AutumnSpringNightCloud4();
    AutumnSpringNightCloud5();
    AutumnSpringNightCloud6();



    riverNight();



    landNight();



    SummerAutumnNightHill2(); // in the back of hill 1 and 3
    SummerAutumnNightHill1();
    SummerAutumnNightHill3();

    SummerAutumnNightHill4();
    SummerAutumnNightHill6(); // behind hill 5
    SummerAutumnNightHill5();

    SummerAutumnNightHill8(); // behind hill 9
    SummerAutumnNightHill7();

    SummerAutumnNightHill11(); // behind hill 10
    SummerAutumnNightHill10(); // behind hill 9

    SummerAutumnNightHill9();









    NightchrisTree1();
    NightchrisTree2();
    NightchrisTree3();
    NightchrisTree4();



    NightcocoTree1();
    NightcocoTree2();
    NightcocoTree3();


   SpringNightPineTree1();
   SpringNightPineTree2();
   SpringNightPineTree3();



    Nightboat2();
    Nightboat1();


    buildingBack();



    buildingNight7(); // behind building 1 and 2
    buildingNight1();
    buildingNight2();
    buildingNight3();

    buildingNight8(); // behind building 5
    buildingNight5();

    buildingNight9(); // behind building 6
    buildingNight10(); //behind building 6
    buildingNight6();

    buildingNight11();
    buildingNight12();

    buildingNight16(); //behind building 15 and 17
    buildingNight15();
    buildingNight17();




    NightRoad();

    // car Right to Left
    NightCar1();
    NightCar2();
    NightCar3();
    NightCar4();




    // car Left to Right
     NightCar5();
     NightCar6();
     NightCar7();
     NightCar8();


     NightRoadside();
    AllRedFlowers();
     AllBlueFlowers();

     RoadsideGrassSpring();







    glFlush();  // Render now

    glPopMatrix();

}





















//***************************************************************************************



void update1(int value)
{  //storm animation
    if (stormIncrease == 0)
    {
        Scale_Thunderstorm = ScaleIncrease_Thunderstorm;
        stormIncrease += 1;
    }

    else
    {
        Scale_Thunderstorm = ScaleDecrease_Thunderstorm;

        stormIncrease = 0;
    }



    glutPostRedisplay(); //Notify GLUT that the display has changed

    glutTimerFunc(2000, update1, 0); //Notify GLUT to call update again in 25 milliseconds
}




void update(int value) {



    //Cloud Animation
    Pos_SuAuSpMorCloud1 += Speed_SuAuSpMorCloud;
    Pos_SuAuSpMorCloud2 += Speed_SuAuSpMorCloud;
    Pos_SuAuSpMorCloud3 += Speed_SuAuSpMorCloud;
    Pos_SuAuSpMorCloud4 += Speed_SuAuSpMorCloud;
    Pos_SuAuSpMorCloud5 += Speed_SuAuSpMorCloud;
    Pos_SuAuSpMorCloud6 += Speed_SuAuSpMorCloud;




    if (Pos_SuAuSpMorCloud1 > 2.2)
    {
        Pos_SuAuSpMorCloud1 -= 2.5;
    }


    if (Pos_SuAuSpMorCloud2 > 1.9)
    {
        Pos_SuAuSpMorCloud2 -= 3;
    }

    if (Pos_SuAuSpMorCloud3 > 1.5)
    {
        Pos_SuAuSpMorCloud3 -= 3.5;
    }

    if (Pos_SuAuSpMorCloud4 > 1.1)
    {
        Pos_SuAuSpMorCloud4 -= 4;
    }


    if (Pos_SuAuSpMorCloud5 > 0.8)
    {
        Pos_SuAuSpMorCloud5 -= 4.5;
    }

    if (Pos_SuAuSpMorCloud6 > 0.5)
    {
        Pos_SuAuSpMorCloud6 -= 5;
    }




    ///////////////////////////////////////////////////////////////////
    //Boat Animation
    Pos_Boat1 += Speed_Boat;
    Pos_Boat2 += Speed_Boat;




    if (Pos_Boat1 > 2)
    {
        Pos_Boat1 = -2.4;
    }


    if (Pos_Boat2 > 2)
    {
        Pos_Boat2 = -2.55;
    }




    //////////////////////////////////////////////////////////////////
    //Car Animation
    Pos_Car1 += Speed_Car;
    Pos_Car2 += Speed_Car;
    Pos_Car3 += Speed_Car;
    Pos_Car4 += Speed_Car;
    Pos_Car5 += Speed_Car;
    Pos_Car6 += Speed_Car;
    Pos_Car7 += Speed_Car;
    Pos_Car8 += Speed_Car;


    if (Pos_Car4 > 7.5)
    {
        Pos_Car1 = -2;
        Pos_Car2 = -2;
        Pos_Car3 = -2;
        Pos_Car4 = -2;


    }


    if (Pos_Car8 > 5)
    {
        Pos_Car5 = -2;
        Pos_Car6 = -2;
        Pos_Car7 = -2;
        Pos_Car8 = -2;

    }



    ////////////////////////////////////////////////////////////
    //rain Animation



    if (Pos_Rain > -0.1)
    {
        Pos_Rain -= Speed_Rain;
    }

    else
    {
       Pos_Rain = 0;
    }


    ////////////////////////////////////////////////////////////
    //snow Animation

    Pos_snow_X -= Speed_snow_X;
    Pos_snow_Y -= Speed_snow_Y;




    if(Pos_snow_Y < -0.4)
    {
        Pos_snow_X = 0;
        Pos_snow_Y = 0;
    }




	glutPostRedisplay();

	glutTimerFunc(20, update, 0);
}












void handleMouse(int button, int state, int x, int y)
{
	if (button == GLUT_LEFT_BUTTON)
        {
            Speed_SuAuSpMorCloud += 0.0001f;
            Speed_Boat     += 0.0001f;
            Speed_Car      += 0.0001f;
            Speed_Rain     += 0.0001f;
            Speed_snow_X   += 0.0001f;
            Speed_snow_Y   += 0.0001f;


        }





    if (button == GLUT_RIGHT_BUTTON)
        {
            Speed_SuAuSpMorCloud -= 0.001f;

            Speed_Boat     -= 0.0001f;
            Speed_Car      -= 0.0001f;
            Speed_Rain     -= 0.0001f;
            Speed_snow_X   -= 0.0001f;
            Speed_snow_Y   -= 0.0001f;



    }

    glutPostRedisplay();

}


void handleKeypress(unsigned char key, int x, int y)
{
	switch (key)
	{
    case 'S':
     glutDisplayFunc(DisplaySummerMorning);
    break;

    case 'A':
    glutDisplayFunc(DisplayAutumnMorning);
    break;

    case 's':
    glutDisplayFunc(DisplaySummerNight);
    break;

    case 'a':
    glutDisplayFunc(DisplayAutumnNight);
    break;

    case 'R':
    glutDisplayFunc(DisplayRainyDay);
    break;

    case 'r':
    glutDisplayFunc(DisplayRainyNight);
    break;

    case 'L':
    glutDisplayFunc(DisplayLateAutumnDay);
    break;

    case 'l':
    glutDisplayFunc(DisplayLateAutumnNight);
    break;

    case 'W':
    glutDisplayFunc(DisplayWinterDay);
    break;

    case 'w':
    glutDisplayFunc(DisplayWinterNight);
    break;

    case 'P':
    glutDisplayFunc(DisplaySpringDay);
    break;

    case 'p':
    glutDisplayFunc(DisplaySpringNight);
    break;

    case 'b':
    if(animationIsOn == true)
      {
            animationIsOn = false;

            Speed_SuAuSpMorCloud = 0.0f;
            Speed_Boat           = 0.0f;
            Speed_Car            = 0.0f;
            Speed_Rain           = 0.0f;
            Speed_snow_X         = 0.0f;
            Speed_snow_Y         = 0.0f;

            ScaleDecrease_Thunderstorm = 1.0;
            ScaleIncrease_Thunderstorm = 1.0;

      }

      else
      {
            animationIsOn = true;

            Speed_SuAuSpMorCloud = 0.0001f;
            Speed_Boat = 0.0005f;
            Speed_Car = 0.005f;
            Speed_Rain = 0.001f;
            Speed_snow_X =  0.00001;
            Speed_snow_Y =  0.005;

            ScaleDecrease_Thunderstorm = 0.01;
            ScaleIncrease_Thunderstorm = 1.0;

      }



    glutPostRedisplay();
	}
}



/* Main function: GLUT runs as a console application starting at main()  */
int main(int argc, char** argv)
{
    glutInit(&argc, argv);          // Initialize GLUT

    glutInitWindowSize(1070, 1070);  // Initializes window size

    glutInitWindowPosition(500, 10); // Position the window's initial top-left corner

    glutCreateWindow("SIX SEASONS OF BANGLADESH");  // Create window with the given title

    glutDisplayFunc(DisplaySummerMorning);       // Register callback handler for window re-paint event

    glutKeyboardFunc(handleKeypress);

    glutMouseFunc(handleMouse);

    glutTimerFunc(20, update, 0);
    glutTimerFunc(2000, update1, 0);

    glutMainLoop();                 // Enter the event-processing loop

    return 0;
}
